<?php
/**
 * Title: Services overview page
 * Slug: calder-rowe/page-services
 * Categories: calder-rowe-pages
 * Keywords: services, overview
 * Post Types: page
 * Description: Services index, the quote process and a renewal call to action.
 */
?>
<!-- wp:pattern {"slug":"calder-rowe/services-grid"} /-->

<!-- wp:pattern {"slug":"calder-rowe/process"} /-->

<!-- wp:pattern {"slug":"calder-rowe/faq"} /-->

<!-- wp:pattern {"slug":"calder-rowe/cta"} /-->
