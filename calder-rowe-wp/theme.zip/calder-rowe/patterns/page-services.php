<?php
/**
 * Title: Services overview page
 * Slug: calder-rowe/page-services
 * Categories: calder-rowe-pages
 * Keywords: services, overview, covers
 * Post Types: page
 * Description: The lines of cover index, how a quote works, common questions and a renewal call to action.
 */
?>
<!-- wp:pattern {"slug":"calder-rowe/lines-index"} /-->

<!-- wp:pattern {"slug":"calder-rowe/process"} /-->

<!-- wp:pattern {"slug":"calder-rowe/faq"} /-->

<!-- wp:pattern {"slug":"calder-rowe/cta"} /-->
