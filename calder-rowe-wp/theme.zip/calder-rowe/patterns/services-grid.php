<?php
/**
 * Title: Services index
 * Slug: calder-rowe/services-grid
 * Categories: calder-rowe, services
 * Keywords: services, cover, insurance types
 * Description: A ruled index of services: name, short description and a link to each service page.
 */
?>
<!-- wp:group {"align":"full","className":"cr-services","style":{"spacing":{"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|60"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull cr-services" style="padding-top:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--60)"><!-- wp:columns {"align":"wide","style":{"spacing":{"blockGap":{"top":"var:preset|spacing|30","left":"var:preset|spacing|60"},"margin":{"bottom":"var:preset|spacing|50"}}}} -->
<div class="wp-block-columns alignwide" style="margin-bottom:var(--wp--preset--spacing--50)"><!-- wp:column {"width":"42%"} -->
<div class="wp-block-column" style="flex-basis:42%"><!-- wp:heading -->
<h2 class="wp-block-heading">What we arrange</h2>
<!-- /wp:heading --></div>
<!-- /wp:column -->

<!-- wp:column {"verticalAlignment":"bottom","width":"58%"} -->
<div class="wp-block-column is-vertically-aligned-bottom" style="flex-basis:58%"><!-- wp:paragraph {"fontSize":"medium"} -->
<p class="has-medium-font-size">Three areas cover most of what a growing business needs. Each one starts with a conversation about how you actually operate, not a form.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->

<!-- wp:columns {"verticalAlignment":"top","align":"wide","className":"cr-service-row","style":{"spacing":{"padding":{"top":"var:preset|spacing|40","bottom":"var:preset|spacing|40"},"blockGap":{"top":"0.75rem","left":"var:preset|spacing|50"}}}} -->
<div class="wp-block-columns alignwide are-vertically-aligned-top cr-service-row" style="padding-top:var(--wp--preset--spacing--40);padding-bottom:var(--wp--preset--spacing--40)"><!-- wp:column {"verticalAlignment":"top","width":"42%"} -->
<div class="wp-block-column is-vertically-aligned-top" style="flex-basis:42%"><!-- wp:heading {"level":3,"fontSize":"x-large"} -->
<h3 class="wp-block-heading has-x-large-font-size"><a href="<?php echo esc_url( home_url( '/services/property-business-interruption/' ) ); ?>">Property and business interruption</a></h3>
<!-- /wp:heading --></div>
<!-- /wp:column -->

<!-- wp:column {"verticalAlignment":"top","width":"58%"} -->
<div class="wp-block-column is-vertically-aligned-top" style="flex-basis:58%"><!-- wp:paragraph -->
<p>Buildings, stock, machinery and the profit you would lose while they are repaired. We check rebuild values and indemnity periods so a claim is not cut short.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"className":"cr-more","style":{"typography":{"fontWeight":"600"}}} -->
<p class="cr-more" style="font-weight:600"><a href="<?php echo esc_url( home_url( '/services/property-business-interruption/' ) ); ?>">Property cover details</a></p>
<!-- /wp:paragraph --></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->

<!-- wp:columns {"verticalAlignment":"top","align":"wide","className":"cr-service-row","style":{"spacing":{"padding":{"top":"var:preset|spacing|40","bottom":"var:preset|spacing|40"},"blockGap":{"top":"0.75rem","left":"var:preset|spacing|50"}}}} -->
<div class="wp-block-columns alignwide are-vertically-aligned-top cr-service-row" style="padding-top:var(--wp--preset--spacing--40);padding-bottom:var(--wp--preset--spacing--40)"><!-- wp:column {"verticalAlignment":"top","width":"42%"} -->
<div class="wp-block-column is-vertically-aligned-top" style="flex-basis:42%"><!-- wp:heading {"level":3,"fontSize":"x-large"} -->
<h3 class="wp-block-heading has-x-large-font-size"><a href="<?php echo esc_url( home_url( '/services/liability-insurance/' ) ); ?>">Liability insurance</a></h3>
<!-- /wp:heading --></div>
<!-- /wp:column -->

<!-- wp:column {"verticalAlignment":"top","width":"58%"} -->
<div class="wp-block-column is-vertically-aligned-top" style="flex-basis:58%"><!-- wp:paragraph -->
<p>Employers', public and products liability, plus professional indemnity where you give advice or design. Cover that answers the contracts you sign.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"className":"cr-more","style":{"typography":{"fontWeight":"600"}}} -->
<p class="cr-more" style="font-weight:600"><a href="<?php echo esc_url( home_url( '/services/liability-insurance/' ) ); ?>">Liability cover details</a></p>
<!-- /wp:paragraph --></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->

<!-- wp:columns {"verticalAlignment":"top","align":"wide","className":"cr-service-row","style":{"spacing":{"padding":{"top":"var:preset|spacing|40","bottom":"var:preset|spacing|40"},"blockGap":{"top":"0.75rem","left":"var:preset|spacing|50"}}}} -->
<div class="wp-block-columns alignwide are-vertically-aligned-top cr-service-row" style="padding-top:var(--wp--preset--spacing--40);padding-bottom:var(--wp--preset--spacing--40)"><!-- wp:column {"verticalAlignment":"top","width":"42%"} -->
<div class="wp-block-column is-vertically-aligned-top" style="flex-basis:42%"><!-- wp:heading {"level":3,"fontSize":"x-large"} -->
<h3 class="wp-block-heading has-x-large-font-size"><a href="<?php echo esc_url( home_url( '/services/cyber-insurance/' ) ); ?>">Cyber insurance</a></h3>
<!-- /wp:heading --></div>
<!-- /wp:column -->

<!-- wp:column {"verticalAlignment":"top","width":"58%"} -->
<div class="wp-block-column is-vertically-aligned-top" style="flex-basis:58%"><!-- wp:paragraph -->
<p>Incident response, data restoration, lost income and payment fraud. We help you answer the security questions insurers now ask before they quote.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"className":"cr-more","style":{"typography":{"fontWeight":"600"}}} -->
<p class="cr-more" style="font-weight:600"><a href="<?php echo esc_url( home_url( '/services/cyber-insurance/' ) ); ?>">Cyber cover details</a></p>
<!-- /wp:paragraph --></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->
</div>
<!-- /wp:group -->
