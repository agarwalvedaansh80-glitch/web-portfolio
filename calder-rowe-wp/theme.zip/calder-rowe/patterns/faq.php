<?php
/**
 * Title: Questions we hear most
 * Slug: calder-rowe/faq
 * Categories: calder-rowe, text
 * Keywords: faq, questions, answers, details
 * Description: A short heading beside ruled, animated fold-out answers built from the core Details block.
 */
?>
<!-- wp:group {"tagName":"section","align":"full","className":"cr-faq","backgroundColor":"paper","textColor":"ink","layout":{"type":"constrained"}} -->
<section class="wp-block-group alignfull cr-faq has-ink-color has-paper-background-color has-text-color has-background"><!-- wp:columns {"align":"wide"} -->
<div class="wp-block-columns alignwide"><!-- wp:column {"width":"38%"} -->
<div class="wp-block-column" style="flex-basis:38%"><!-- wp:heading {"className":"is-style-kinetic"} -->
<h2 class="wp-block-heading is-style-kinetic">Questions we hear <em>most</em></h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>If yours is not here, ask a broker. A conversation costs nothing and commits you to nothing.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column {"width":"62%"} -->
<div class="wp-block-column" style="flex-basis:62%"><!-- wp:details {"className":"is-style-fold"} -->
<details class="wp-block-details is-style-fold"><summary>How are you paid?</summary><!-- wp:paragraph -->
<p>Usually by commission from the insurer, sometimes by a fee, occasionally both. We tell you which, and how much, before you buy anything.</p>
<!-- /wp:paragraph --></details>
<!-- /wp:details -->

<!-- wp:details {"className":"is-style-fold"} -->
<details class="wp-block-details is-style-fold"><summary>Will you only quote insurers who pay you most?</summary><!-- wp:paragraph -->
<p>No. We are independent, so no insurer owns us or sets our targets. Our written recommendation names every insurer we approached and why we chose the one we did.</p>
<!-- /wp:paragraph --></details>
<!-- /wp:details -->

<!-- wp:details {"className":"is-style-fold"} -->
<details class="wp-block-details is-style-fold"><summary>Can you take over a policy mid-term?</summary><!-- wp:paragraph -->
<p>Yes. We can become your broker of record at any point, which means you get our help on any claim from that day forward.</p>
<!-- /wp:paragraph --></details>
<!-- /wp:details -->

<!-- wp:details {"className":"is-style-fold"} -->
<details class="wp-block-details is-style-fold"><summary>Do you only work with firms in Leeds?</summary><!-- wp:paragraph -->
<p>Most clients are in Yorkshire and the North, but we place cover for businesses across the UK. The phone works the same everywhere.</p>
<!-- /wp:paragraph --></details>
<!-- /wp:details --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></section>
<!-- /wp:group -->
