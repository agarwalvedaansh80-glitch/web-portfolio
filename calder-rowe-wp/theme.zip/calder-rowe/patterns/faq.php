<?php
/**
 * Title: Frequently asked questions
 * Slug: calder-rowe/faq
 * Categories: calder-rowe, text
 * Keywords: faq, questions, accordion, details
 * Description: Heading and contact prompt beside five expandable questions built from the core Details block.
 */
$cr_faq = array(
	array( 'Does using a broker cost more than going direct?', 'Usually not. Insurers pay brokers a commission that is already built into the premium, and we tell you what it is before you buy. Where we charge a fee for complex work, we agree it with you in writing first.' ),
	array( 'Which insurers do you work with?', 'We place business with a panel of UK and Lloyd&#8217;s insurers. Your recommendation report names every insurer we approached and why we chose the one we did.' ),
	array( 'What happens when I need to claim?', 'Call the claims line. We log the claim with the insurer, help you gather evidence, meet the loss adjuster with you and keep chasing until the claim is settled.' ),
	array( 'Can you review cover I already have?', 'Yes. Send us your current schedule and policy wording. We will point out gaps and under-insurance, and tell you plainly if your existing cover is fine.' ),
	array( 'Are you regulated?', 'This is a demonstration site for a fictional firm. A real broker would show its Financial Conduct Authority firm reference number here and in the footer.' ),
);
?>
<!-- wp:group {"align":"full","className":"cr-faq","style":{"spacing":{"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|60"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull cr-faq" style="padding-top:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--60)"><!-- wp:columns {"align":"wide","style":{"spacing":{"blockGap":{"top":"var:preset|spacing|40","left":"var:preset|spacing|60"}}}} -->
<div class="wp-block-columns alignwide"><!-- wp:column {"width":"38%"} -->
<div class="wp-block-column" style="flex-basis:38%"><!-- wp:heading -->
<h2 class="wp-block-heading">Questions we hear most</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>If yours is not here, ask a broker. There is no charge for a conversation and no obligation to buy.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"className":"cr-more","style":{"typography":{"fontWeight":"600"}}} -->
<p class="cr-more" style="font-weight:600"><a href="<?php echo esc_url( home_url( '/contact/' ) ); ?>">Ask us a question</a></p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column {"width":"62%","className":"cr-faq__list"} -->
<div class="wp-block-column cr-faq__list" style="flex-basis:62%"><?php foreach ( $cr_faq as $cr_item ) : ?><!-- wp:details -->
<details class="wp-block-details"><summary><?php echo $cr_item[0]; ?></summary><!-- wp:paragraph -->
<p><?php echo $cr_item[1]; ?></p>
<!-- /wp:paragraph --></details>
<!-- /wp:details -->

<?php endforeach; ?></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group -->
