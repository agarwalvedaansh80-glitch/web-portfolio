<?php
/**
 * Title: Claims story: storm to calm
 * Slug: calder-rowe/claims-story
 * Categories: calder-rowe
 * Keywords: claims, process, steps, timeline, story, scroll
 * Description: "What happens after you call us" in five steps. On wide screens the section pins while you scroll: an illustrated storm clears to calm and a timeline draws itself. Edit the five step groups freely; without motion they read as a simple list.
 */
$cr_steps = array(
	array( '00:00', 'The call', 'A broker answers. Not a queue.', 'Ring 0113 496 0499 at any hour. A Calder &amp; Rowe broker picks up, usually inside three rings, and stays your named contact until the claim closes.' ),
	array( 'Hour 2', 'Logged', 'Your claim is with the insurer the same day.', 'We notify the insurer, send you the claim reference and arrange the emergency help your policy allows: boarding up, drying out, IT incident response.' ),
	array( 'Day 3', 'On site', 'We meet the loss adjuster with you.', 'We sit in on the visit, help you gather photos, invoices and figures, and make sure nothing you are owed is left off the list.' ),
	array( 'Week 2', 'Cash flow', 'We push for an interim payment.', 'Rebuilds take months. We negotiate payments on account so wages and suppliers are paid while the claim runs, and we update you every week, even when there is no news.' ),
	array( 'Week 9', 'Calm', 'Settled, line by line.', 'We check the final settlement against your schedule before you sign, then use what we learned to tighten your cover at renewal.' ),
);
?>
<!-- wp:group {"tagName":"section","align":"full","className":"cr-claims-story","backgroundColor":"ink","textColor":"paper","layout":{"type":"constrained"}} -->
<section class="wp-block-group alignfull cr-claims-story has-paper-color has-ink-background-color has-text-color has-background"><!-- wp:group {"align":"wide","className":"cr-story__intro","layout":{"type":"default"}} -->
<div class="wp-block-group alignwide cr-story__intro"><!-- wp:paragraph {"className":"cr-eyebrow"} -->
<p class="cr-eyebrow">Claims · what happens after you call us</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"className":"is-style-kinetic"} -->
<h2 class="wp-block-heading is-style-kinetic">Five steps from storm to <em>calm.</em></h2>
<!-- /wp:heading --></div>
<!-- /wp:group -->

<!-- wp:group {"align":"wide","className":"cr-story__steps","layout":{"type":"default"}} -->
<div class="wp-block-group alignwide cr-story__steps"><?php foreach ( $cr_steps as $cr_step ) : ?><!-- wp:group {"className":"cr-step","layout":{"type":"default"}} -->
<div class="wp-block-group cr-step"><!-- wp:paragraph {"className":"cr-step__time"} -->
<p class="cr-step__time"><strong><?php echo $cr_step[0]; ?></strong> <?php echo $cr_step[1]; ?></p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":3,"className":"cr-step__title"} -->
<h3 class="wp-block-heading cr-step__title"><?php echo $cr_step[2]; ?></h3>
<!-- /wp:heading -->

<!-- wp:paragraph {"className":"cr-step__body"} -->
<p class="cr-step__body"><?php echo $cr_step[3]; ?></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<?php endforeach; ?><!-- wp:paragraph {"className":"cr-story__note"} -->
<p class="cr-story__note">Typical timings for a mid-sized property claim. Every claim is different, and we will tell you honestly what to expect on yours.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></section>
<!-- /wp:group -->
