<?php
/**
 * Title: How a quote works
 * Slug: calder-rowe/process
 * Categories: calder-rowe, text
 * Keywords: process, steps, how it works
 * Description: Four numbered steps from first call to ongoing service.
 */
?>
<!-- wp:group {"align":"full","className":"cr-process","style":{"spacing":{"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|60"},"blockGap":"var:preset|spacing|50"}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull cr-process" style="padding-top:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--60)"><!-- wp:heading {"align":"wide"} -->
<h2 class="wp-block-heading alignwide">How a quote works</h2>
<!-- /wp:heading -->

<!-- wp:group {"align":"wide","className":"cr-steps","style":{"spacing":{"blockGap":"var:preset|spacing|40"}},"layout":{"type":"grid","columnCount":4,"minimumColumnWidth":"14rem"}} -->
<div class="wp-block-group alignwide cr-steps">
<!-- wp:group {"className":"cr-step","style":{"spacing":{"blockGap":"0.6rem"}},"layout":{"type":"default"}} -->
<div class="wp-block-group cr-step"><!-- wp:paragraph {"className":"cr-step__num"} -->
<p class="cr-step__num">1</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":3,"fontSize":"medium"} -->
<h3 class="wp-block-heading has-medium-font-size">Tell us about the business</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>A 20-minute call or the quote form. We ask how you operate, not just what you turnover.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group {"className":"cr-step","style":{"spacing":{"blockGap":"0.6rem"}},"layout":{"type":"default"}} -->
<div class="wp-block-group cr-step"><!-- wp:paragraph {"className":"cr-step__num"} -->
<p class="cr-step__num">2</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":3,"fontSize":"medium"} -->
<h3 class="wp-block-heading has-medium-font-size">We go to the market</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>We approach the insurers on our panel that suit your risk and negotiate terms, not only price.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group {"className":"cr-step","style":{"spacing":{"blockGap":"0.6rem"}},"layout":{"type":"default"}} -->
<div class="wp-block-group cr-step"><!-- wp:paragraph {"className":"cr-step__num"} -->
<p class="cr-step__num">3</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":3,"fontSize":"medium"} -->
<h3 class="wp-block-heading has-medium-font-size">You choose, with advice in writing</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>A short report compares the options, flags exclusions and says which we would pick and why.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group {"className":"cr-step","style":{"spacing":{"blockGap":"0.6rem"}},"layout":{"type":"default"}} -->
<div class="wp-block-group cr-step"><!-- wp:paragraph {"className":"cr-step__num"} -->
<p class="cr-step__num">4</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":3,"fontSize":"medium"} -->
<h3 class="wp-block-heading has-medium-font-size">We stay on the account</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Mid-term changes, certificates for contracts, renewals and, when it matters, the claim.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->
</div>
<!-- /wp:group --></div>
<!-- /wp:group -->
