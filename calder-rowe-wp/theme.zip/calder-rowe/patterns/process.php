<?php
/**
 * Title: How a quote works
 * Slug: calder-rowe/process
 * Categories: calder-rowe
 * Keywords: process, steps, quote, how it works
 * Description: Four numbered steps on a ruled grid, from the first call to staying on the account.
 */
?>
<!-- wp:group {"tagName":"section","align":"full","className":"cr-process","backgroundColor":"chart","textColor":"ink","layout":{"type":"constrained"}} -->
<section class="wp-block-group alignfull cr-process has-ink-color has-chart-background-color has-text-color has-background"><!-- wp:group {"align":"wide","className":"cr-process__inner","layout":{"type":"default"}} -->
<div class="wp-block-group alignwide cr-process__inner"><!-- wp:heading {"className":"is-style-kinetic"} -->
<h2 class="wp-block-heading is-style-kinetic">How a quote <em>works</em></h2>
<!-- /wp:heading -->

<!-- wp:list {"ordered":true,"className":"is-style-isobar cr-process__list"} -->
<ol class="wp-block-list is-style-isobar cr-process__list"><!-- wp:list-item -->
<li><strong>Tell us about the business.</strong> A 20-minute call or the quote form. We ask how you operate, not just what you turn over.</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><strong>We go to the market.</strong> We approach the insurers on our panel that suit your risk and negotiate terms, not only price.</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><strong>You choose, with advice in writing.</strong> A short report compares the options, flags exclusions and says which we would pick and why.</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><strong>We stay on the account.</strong> Mid-term changes, certificates for contracts, renewals and, when it matters, the claim.</li>
<!-- /wp:list-item --></ol>
<!-- /wp:list --></div>
<!-- /wp:group --></section>
<!-- /wp:group -->
