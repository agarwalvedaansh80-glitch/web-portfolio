<?php
/**
 * Title: Trust strip
 * Slug: calder-rowe/trust-strip
 * Categories: calder-rowe, text
 * Keywords: trust, reasons, independent
 * Description: Three plain statements about how the firm works. No ratings or logos.
 */
?>
<!-- wp:group {"align":"full","className":"cr-trust","style":{"spacing":{"padding":{"top":"var:preset|spacing|50","bottom":"var:preset|spacing|50"}}},"backgroundColor":"paper","layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull cr-trust has-paper-background-color has-background" style="padding-top:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--50)"><!-- wp:columns {"align":"wide","style":{"spacing":{"blockGap":{"top":"var:preset|spacing|40","left":"var:preset|spacing|50"}}}} -->
<div class="wp-block-columns alignwide"><!-- wp:column {"className":"cr-trust__item"} -->
<div class="wp-block-column cr-trust__item"><!-- wp:heading {"level":3,"fontSize":"medium"} -->
<h3 class="wp-block-heading has-medium-font-size">Independent</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>No insurer owns us, so our recommendation follows your risk, not a sales target.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column {"className":"cr-trust__item"} -->
<div class="wp-block-column cr-trust__item"><!-- wp:heading {"level":3,"fontSize":"medium"} -->
<h3 class="wp-block-heading has-medium-font-size">One named broker</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>The person who arranges your cover is the person who answers when you call.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column {"className":"cr-trust__item"} -->
<div class="wp-block-column cr-trust__item"><!-- wp:heading {"level":3,"fontSize":"medium"} -->
<h3 class="wp-block-heading has-medium-font-size">Claims handled with you</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>We prepare the claim, deal with the loss adjuster and chase the insurer until it is paid.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group -->
