<?php
/**
 * Title: Latest insights
 * Slug: calder-rowe/news-grid
 * Categories: calder-rowe, query
 * Keywords: news, blog, posts, insights, articles
 * Description: The three most recent posts as a ruled row, with category, title, excerpt and date.
 */
?>
<!-- wp:group {"align":"full","className":"cr-news","style":{"spacing":{"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|60"},"blockGap":"var:preset|spacing|50"}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull cr-news" style="padding-top:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--60)"><!-- wp:group {"align":"wide","style":{"spacing":{"blockGap":"var:preset|spacing|30"}},"layout":{"type":"flex","flexWrap":"wrap","justifyContent":"space-between","verticalAlignment":"bottom"}} -->
<div class="wp-block-group alignwide"><!-- wp:heading -->
<h2 class="wp-block-heading">Insights</h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"className":"cr-more","style":{"typography":{"fontWeight":"600"}}} -->
<p class="cr-more" style="font-weight:600"><a href="<?php echo esc_url( home_url( '/insights/' ) ); ?>">All guides and updates</a></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:query {"queryId":11,"query":{"perPage":3,"pages":0,"offset":0,"postType":"post","order":"desc","orderBy":"date","author":"","search":"","exclude":[],"sticky":"","inherit":false},"align":"wide"} -->
<div class="wp-block-query alignwide"><!-- wp:post-template {"style":{"spacing":{"blockGap":"var:preset|spacing|50"}},"layout":{"type":"grid","columnCount":3}} -->
<!-- wp:group {"className":"cr-news-item","style":{"spacing":{"blockGap":"0.7rem","padding":{"top":"1.25rem"}},"border":{"top":{"color":"var:preset|color|canal","width":"3px"}}},"layout":{"type":"default"}} -->
<div class="wp-block-group cr-news-item" style="border-top-color:var(--wp--preset--color--canal);border-top-width:3px;padding-top:1.25rem"><!-- wp:post-featured-image {"isLink":true,"aspectRatio":"16/10","sizeSlug":"medium_large"} /-->

<!-- wp:post-terms {"term":"category","textColor":"moss"} /-->

<!-- wp:post-title {"isLink":true,"fontSize":"large"} /-->

<!-- wp:post-excerpt {"excerptLength":24} /-->

<!-- wp:post-date /--></div>
<!-- /wp:group -->
<!-- /wp:post-template -->

<!-- wp:query-no-results -->
<!-- wp:paragraph -->
<p>New guides are on the way. In the meantime, call us with any question about your cover.</p>
<!-- /wp:paragraph -->
<!-- /wp:query-no-results --></div>
<!-- /wp:query --></div>
<!-- /wp:group -->
