<?php
/**
 * Title: Latest insights
 * Slug: calder-rowe/news-grid
 * Categories: calder-rowe, query
 * Keywords: news, blog, posts, insights, articles
 * Description: The three most recent posts as editorial cards with chart-style covers, category, title and date.
 */
?>
<!-- wp:group {"tagName":"section","align":"full","className":"cr-news","backgroundColor":"chart","textColor":"ink","layout":{"type":"constrained"}} -->
<section class="wp-block-group alignfull cr-news has-ink-color has-chart-background-color has-text-color has-background"><!-- wp:group {"align":"wide","className":"cr-news__head","layout":{"type":"flex","flexWrap":"wrap","justifyContent":"space-between","verticalAlignment":"bottom"}} -->
<div class="wp-block-group alignwide cr-news__head"><!-- wp:heading {"className":"is-style-kinetic"} -->
<h2 class="wp-block-heading is-style-kinetic">Notes from the <em>chart room</em></h2>
<!-- /wp:heading -->

<!-- wp:buttons -->
<div class="wp-block-buttons"><!-- wp:button {"className":"is-style-arrow"} -->
<div class="wp-block-button is-style-arrow"><a class="wp-block-button__link wp-element-button" href="<?php echo esc_url( home_url( '/insights/' ) ); ?>">All guides</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:group -->

<!-- wp:query {"queryId":11,"query":{"perPage":3,"pages":0,"offset":0,"postType":"post","order":"desc","orderBy":"date","author":"","search":"","exclude":[],"sticky":"","inherit":false},"align":"wide"} -->
<div class="wp-block-query alignwide"><!-- wp:post-template {"className":"cr-cards","layout":{"type":"grid","columnCount":3}} -->
<!-- wp:group {"className":"cr-card","layout":{"type":"default"}} -->
<div class="wp-block-group cr-card"><!-- wp:post-featured-image {"isLink":true,"aspectRatio":"16/10","sizeSlug":"medium_large"} /-->

<!-- wp:post-terms {"term":"category"} /-->

<!-- wp:post-title {"isLink":true,"fontSize":"large"} /-->

<!-- wp:post-date /--></div>
<!-- /wp:group -->
<!-- /wp:post-template -->

<!-- wp:query-no-results -->
<!-- wp:paragraph -->
<p>New guides are on the way. In the meantime, call a broker with any question about your cover.</p>
<!-- /wp:paragraph -->
<!-- /wp:query-no-results --></div>
<!-- /wp:query --></section>
<!-- /wp:group -->
