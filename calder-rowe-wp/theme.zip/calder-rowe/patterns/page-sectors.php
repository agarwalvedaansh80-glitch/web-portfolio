<?php
/**
 * Title: Sectors page
 * Slug: calder-rowe/page-sectors
 * Categories: calder-rowe-pages
 * Keywords: sectors, industries
 * Post Types: page
 * Description: Sector tiles followed by service standards and a call to action.
 */
?>
<!-- wp:pattern {"slug":"calder-rowe/sectors"} /-->

<!-- wp:pattern {"slug":"calder-rowe/stats-band"} /-->

<!-- wp:pattern {"slug":"calder-rowe/cta"} /-->
