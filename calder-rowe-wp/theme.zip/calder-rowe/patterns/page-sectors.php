<?php
/**
 * Title: Sectors page
 * Slug: calder-rowe/page-sectors
 * Categories: calder-rowe-pages
 * Keywords: sectors, industries
 * Post Types: page
 * Description: Sector cards, promise and targets, and a call to action.
 */
?>
<!-- wp:pattern {"slug":"calder-rowe/sectors"} /-->

<!-- wp:pattern {"slug":"calder-rowe/proof"} /-->

<!-- wp:pattern {"slug":"calder-rowe/cta"} /-->
