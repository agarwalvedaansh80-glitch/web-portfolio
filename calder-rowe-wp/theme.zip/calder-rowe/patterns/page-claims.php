<?php
/**
 * Title: Claims page
 * Slug: calder-rowe/page-claims
 * Categories: calder-rowe-pages
 * Keywords: claims, report, loss, emergency
 * Post Types: page
 * Description: The 24-hour claims number, what to have ready, the pinned storm-to-calm claims story and common questions.
 */
?>
<!-- wp:group {"tagName":"section","align":"full","className":"cr-hotline","backgroundColor":"paper","textColor":"ink","layout":{"type":"constrained"}} -->
<section class="wp-block-group alignfull cr-hotline has-ink-color has-paper-background-color has-text-color has-background"><!-- wp:columns {"align":"wide"} -->
<div class="wp-block-columns alignwide"><!-- wp:column {"width":"58%"} -->
<div class="wp-block-column" style="flex-basis:58%"><!-- wp:paragraph {"className":"cr-eyebrow"} -->
<p class="cr-eyebrow">Report a claim, day or night</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"className":"cr-bignum"} -->
<p class="cr-bignum"><a href="tel:+441134960499">0113 496 0499</a></p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"className":"cr-hotline__lead"} -->
<p class="cr-hotline__lead">Call as soon as you can, even if you are not sure the loss is covered. Late notification is one of the most common reasons a claim is reduced.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"className":"cr-warning"} -->
<p class="cr-warning">If anyone is hurt or a building is unsafe, call 999 first. Then call us.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column {"width":"42%"} -->
<div class="wp-block-column" style="flex-basis:42%"><!-- wp:group {"className":"is-style-card cr-ready","layout":{"type":"default"}} -->
<div class="wp-block-group is-style-card cr-ready"><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Useful to have ready</h3>
<!-- /wp:heading -->

<!-- wp:list {"ordered":true,"className":"is-style-isobar"} -->
<ol class="wp-block-list is-style-isobar"><!-- wp:list-item -->
<li>Your policy number, or just the business name</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>When and where it happened, and what was damaged or lost</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>Photos or video, taken before anything is cleared away</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>A crime reference number for theft or vandalism</li>
<!-- /wp:list-item --></ol>
<!-- /wp:list -->

<!-- wp:paragraph {"className":"cr-ready__note"} -->
<p class="cr-ready__note">Do not admit liability or agree a settlement with anyone before you speak to us.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></section>
<!-- /wp:group -->

<!-- wp:pattern {"slug":"calder-rowe/claims-story"} /-->

<!-- wp:group {"tagName":"section","align":"full","className":"cr-faq","backgroundColor":"paper","textColor":"ink","layout":{"type":"constrained"}} -->
<section class="wp-block-group alignfull cr-faq has-ink-color has-paper-background-color has-text-color has-background"><!-- wp:columns {"align":"wide"} -->
<div class="wp-block-columns alignwide"><!-- wp:column {"width":"38%"} -->
<div class="wp-block-column" style="flex-basis:38%"><!-- wp:heading {"className":"is-style-kinetic"} -->
<h2 class="wp-block-heading is-style-kinetic">Claims <em>questions</em></h2>
<!-- /wp:heading --></div>
<!-- /wp:column -->

<!-- wp:column {"width":"62%"} -->
<div class="wp-block-column" style="flex-basis:62%"><!-- wp:details {"className":"is-style-fold"} -->
<details class="wp-block-details is-style-fold"><summary>Will a claim increase my premium?</summary><!-- wp:paragraph -->
<p>It can, but not always. Insurers look at the cause and what you have done to stop it happening again. We present that case for you at renewal.</p>
<!-- /wp:paragraph --></details>
<!-- /wp:details -->

<!-- wp:details {"className":"is-style-fold"} -->
<details class="wp-block-details is-style-fold"><summary>I am not a client yet. Can you help with a claim?</summary><!-- wp:paragraph -->
<p>We can only act on policies we arrange or take over. If your renewal is coming up, we can move the policy to us so we can support future claims.</p>
<!-- /wp:paragraph --></details>
<!-- /wp:details -->

<!-- wp:details {"className":"is-style-fold"} -->
<details class="wp-block-details is-style-fold"><summary>How long does a claim take?</summary><!-- wp:paragraph -->
<p>Simple claims can settle in weeks. Larger property and business interruption claims can take months, which is why we agree interim payments with the insurer wherever we can.</p>
<!-- /wp:paragraph --></details>
<!-- /wp:details --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></section>
<!-- /wp:group -->
