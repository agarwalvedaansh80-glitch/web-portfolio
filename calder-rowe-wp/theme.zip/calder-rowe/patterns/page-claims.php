<?php
/**
 * Title: Claims page
 * Slug: calder-rowe/page-claims
 * Categories: calder-rowe-pages
 * Keywords: claims, report, loss
 * Post Types: page
 * Description: Claims line, what to have ready, the claim process in order, and common questions.
 */
?>
<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|60"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull" style="padding-top:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--60)"><!-- wp:columns {"align":"wide","style":{"spacing":{"blockGap":{"top":"var:preset|spacing|50","left":"var:preset|spacing|60"}}}} -->
<div class="wp-block-columns alignwide"><!-- wp:column {"width":"55%"} -->
<div class="wp-block-column" style="flex-basis:55%"><!-- wp:heading -->
<h2 class="wp-block-heading">Report a claim, day or night</h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"className":"cr-bignum"} -->
<p class="cr-bignum"><a href="tel:+441134960499">0113 496 0499</a></p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Call as soon as you can, even if you are not sure the loss is covered. Late notification is one of the most common reasons a claim is reduced.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"className":"cr-warning"} -->
<p class="cr-warning">If anyone is hurt or a building is unsafe, call 999 first. Then call us.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column {"width":"45%"} -->
<div class="wp-block-column" style="flex-basis:45%"><!-- wp:group {"className":"cr-panel","style":{"spacing":{"padding":{"top":"var:preset|spacing|40","bottom":"var:preset|spacing|40","left":"var:preset|spacing|40","right":"var:preset|spacing|40"},"blockGap":"var:preset|spacing|30"},"border":{"radius":"10px"}},"backgroundColor":"stone","layout":{"type":"default"}} -->
<div class="wp-block-group cr-panel has-stone-background-color has-background" style="border-radius:10px;padding-top:var(--wp--preset--spacing--40);padding-right:var(--wp--preset--spacing--40);padding-bottom:var(--wp--preset--spacing--40);padding-left:var(--wp--preset--spacing--40)"><!-- wp:heading {"level":3,"fontSize":"large"} -->
<h3 class="wp-block-heading has-large-font-size">Useful to have ready</h3>
<!-- /wp:heading -->

<!-- wp:list -->
<ul class="wp-block-list"><!-- wp:list-item -->
<li>Your policy number, or just the business name</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>When and where it happened, and what was damaged or lost</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>Photos or video, taken before anything is cleared away</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>A crime reference number for theft or vandalism</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>Any letter or email if someone is making a claim against you</li>
<!-- /wp:list-item --></ul>
<!-- /wp:list -->

<!-- wp:paragraph {"fontSize":"small"} -->
<p class="has-small-font-size">Do not admit liability or agree a settlement with anyone before you speak to us.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group -->

<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|60"},"blockGap":"var:preset|spacing|40"}},"backgroundColor":"stone","layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull has-stone-background-color has-background" style="padding-top:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--60)"><!-- wp:group {"align":"wide","layout":{"type":"constrained","contentSize":"760px","justifyContent":"left"}} -->
<div class="wp-block-group alignwide"><!-- wp:heading -->
<h2 class="wp-block-heading">What happens after you call</h2>
<!-- /wp:heading -->

<!-- wp:list {"ordered":true,"className":"cr-timeline"} -->
<ol class="wp-block-list cr-timeline"><!-- wp:list-item -->
<li><strong>We log the claim with your insurer</strong> the same day and send you the claim reference.</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><strong>We arrange emergency help</strong> where the policy allows, such as boarding up, drying out or IT incident response.</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><strong>We meet the loss adjuster with you</strong> and help you prepare the evidence and figures they ask for.</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><strong>We chase the insurer</strong> and update you every week until the claim is settled, even when there is no news.</li>
<!-- /wp:list-item --></ol>
<!-- /wp:list --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->

<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|60"},"blockGap":"var:preset|spacing|30"}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull" style="padding-top:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--60)"><!-- wp:group {"align":"wide","layout":{"type":"constrained","contentSize":"760px","justifyContent":"left"}} -->
<div class="wp-block-group alignwide"><!-- wp:heading -->
<h2 class="wp-block-heading">Claims questions</h2>
<!-- /wp:heading -->

<!-- wp:details -->
<details class="wp-block-details"><summary>Will a claim increase my premium?</summary><!-- wp:paragraph -->
<p>It can, but not always. Insurers look at the cause and what you have done to stop it happening again. We present that case for you at renewal.</p>
<!-- /wp:paragraph --></details>
<!-- /wp:details -->

<!-- wp:details -->
<details class="wp-block-details"><summary>I am not a client yet. Can you help with a claim?</summary><!-- wp:paragraph -->
<p>We can only act on policies we arrange or take over. If your renewal is coming up, we can move the policy to us so we can support future claims.</p>
<!-- /wp:paragraph --></details>
<!-- /wp:details -->

<!-- wp:details -->
<details class="wp-block-details"><summary>How long does a claim take?</summary><!-- wp:paragraph -->
<p>Simple claims can settle in weeks. Larger property and business interruption claims can take months, which is why we agree interim payments with the insurer wherever we can.</p>
<!-- /wp:paragraph --></details>
<!-- /wp:details --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->
