<?php
/**
 * Title: Footer
 * Slug: calder-rowe/footer
 * Categories: footer
 * Block Types: core/template-part/footer
 * Inserter: no
 * Description: Oversized wordmark over contour lines, link columns, contact details, and the mobile click-to-call bar.
 */
$cr_link = static function ( $path ) {
	return esc_url( home_url( $path ) );
};
?>
<!-- wp:group {"className":"cr-footer","backgroundColor":"ink","textColor":"mist","layout":{"type":"constrained"}} -->
<div class="wp-block-group cr-footer has-mist-color has-ink-background-color has-text-color has-background"><!-- wp:paragraph {"className":"cr-footer__mark"} -->
<p class="cr-footer__mark">Calder <em>&amp;</em> Rowe</p>
<!-- /wp:paragraph -->

<!-- wp:columns {"align":"wide","className":"cr-footer__cols"} -->
<div class="wp-block-columns alignwide cr-footer__cols"><!-- wp:column {"width":"34%"} -->
<div class="wp-block-column" style="flex-basis:34%"><!-- wp:paragraph {"className":"cr-footer__about"} -->
<p class="cr-footer__about">Independent business insurance brokers for owner-managed firms across Yorkshire and the North. We arrange the cover, and we stay for the claim.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"className":"cr-footer__addr"} -->
<p class="cr-footer__addr">4 Granary Wharf, Leeds LS1 4BR<br>Mon to Fri, 8.30am to 5.30pm</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column"><!-- wp:heading {"level":2,"className":"cr-footer__h"} -->
<h2 class="wp-block-heading cr-footer__h">Cover</h2>
<!-- /wp:heading -->

<!-- wp:list {"className":"cr-plain-list"} -->
<ul class="wp-block-list cr-plain-list"><!-- wp:list-item -->
<li><a href="<?php echo $cr_link( '/services/property-business-interruption/' ); ?>">Property &amp; interruption</a></li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><a href="<?php echo $cr_link( '/services/liability-insurance/' ); ?>">Liability</a></li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><a href="<?php echo $cr_link( '/services/cyber-insurance/' ); ?>">Cyber</a></li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><a href="<?php echo $cr_link( '/services/fleet-motor-insurance/' ); ?>">Fleet &amp; motor</a></li>
<!-- /wp:list-item --></ul>
<!-- /wp:list --></div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column"><!-- wp:heading {"level":2,"className":"cr-footer__h"} -->
<h2 class="wp-block-heading cr-footer__h">Company</h2>
<!-- /wp:heading -->

<!-- wp:list {"className":"cr-plain-list"} -->
<ul class="wp-block-list cr-plain-list"><!-- wp:list-item -->
<li><a href="<?php echo $cr_link( '/about/' ); ?>">About us</a></li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><a href="<?php echo $cr_link( '/sectors/' ); ?>">Sectors</a></li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><a href="<?php echo $cr_link( '/claims/' ); ?>">Make a claim</a></li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><a href="<?php echo $cr_link( '/insights/' ); ?>">Insights</a></li>
<!-- /wp:list-item --></ul>
<!-- /wp:list --></div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column"><!-- wp:heading {"level":2,"className":"cr-footer__h"} -->
<h2 class="wp-block-heading cr-footer__h">Talk to us</h2>
<!-- /wp:heading -->

<!-- wp:list {"className":"cr-plain-list"} -->
<ul class="wp-block-list cr-plain-list"><!-- wp:list-item -->
<li>Office <a href="tel:+441134960412">0113 496 0412</a></li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>Claims, 24h <a href="tel:+441134960499">0113 496 0499</a></li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><a href="mailto:hello@calderrowe.example">hello@calderrowe.example</a></li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><a href="<?php echo $cr_link( '/contact/' ); ?>">Quote request form</a></li>
<!-- /wp:list-item --></ul>
<!-- /wp:list --></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->

<!-- wp:group {"align":"wide","className":"cr-footer__legal","layout":{"type":"flex","flexWrap":"wrap","justifyContent":"space-between"}} -->
<div class="wp-block-group alignwide cr-footer__legal"><!-- wp:paragraph -->
<p>© 2026 Calder &amp; Rowe. All rights reserved.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"className":"cr-footer__coords"} -->
<p class="cr-footer__coords">53.7954° N · 1.5491° W</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->

<!-- wp:pattern {"slug":"calder-rowe/mobile-actions"} /-->
