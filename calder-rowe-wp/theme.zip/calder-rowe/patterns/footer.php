<?php
/**
 * Title: Footer
 * Slug: calder-rowe/footer
 * Categories: footer
 * Block Types: core/template-part/footer
 * Inserter: no
 * Description: Contact details, site links, demo disclaimer and the mobile call/WhatsApp bar.
 */
$cr_link = static function ( $path ) {
	return esc_url( home_url( $path ) );
};
?>
<!-- wp:group {"className":"cr-footer","style":{"spacing":{"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|40"},"blockGap":"var:preset|spacing|50"},"elements":{"link":{"color":{"text":"var:preset|color|paper"}}}},"backgroundColor":"deep","textColor":"mist","layout":{"type":"constrained"}} -->
<div class="wp-block-group cr-footer has-mist-color has-deep-background-color has-text-color has-background has-link-color" style="padding-top:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--40)"><!-- wp:columns {"align":"wide","style":{"spacing":{"blockGap":{"top":"var:preset|spacing|50","left":"var:preset|spacing|50"}}}} -->
<div class="wp-block-columns alignwide"><!-- wp:column {"width":"34%"} -->
<div class="wp-block-column" style="flex-basis:34%"><!-- wp:site-title {"level":0,"className":"cr-brand cr-brand--light","textColor":"paper"} /-->

<!-- wp:paragraph -->
<p>An independent business insurance and risk broker in Leeds. We arrange cover for firms across Yorkshire and the North, and we handle claims alongside our clients.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"fontSize":"small"} -->
<p class="has-small-font-size">Granary Wharf, Leeds (demo address)<br>Monday to Friday, 8.30am to 5.30pm</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column"><!-- wp:heading {"level":2,"textColor":"paper","fontSize":"medium"} -->
<h2 class="wp-block-heading has-paper-color has-text-color has-medium-font-size">Services</h2>
<!-- /wp:heading -->

<!-- wp:list {"className":"cr-plain-list"} -->
<ul class="wp-block-list cr-plain-list"><!-- wp:list-item -->
<li><a href="<?php echo $cr_link( '/services/property-business-interruption/' ); ?>">Property and business interruption</a></li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><a href="<?php echo $cr_link( '/services/liability-insurance/' ); ?>">Liability insurance</a></li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><a href="<?php echo $cr_link( '/services/cyber-insurance/' ); ?>">Cyber insurance</a></li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><a href="<?php echo $cr_link( '/services/' ); ?>">All services</a></li>
<!-- /wp:list-item --></ul>
<!-- /wp:list --></div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column"><!-- wp:heading {"level":2,"textColor":"paper","fontSize":"medium"} -->
<h2 class="wp-block-heading has-paper-color has-text-color has-medium-font-size">Company</h2>
<!-- /wp:heading -->

<!-- wp:list {"className":"cr-plain-list"} -->
<ul class="wp-block-list cr-plain-list"><!-- wp:list-item -->
<li><a href="<?php echo $cr_link( '/about/' ); ?>">About us</a></li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><a href="<?php echo $cr_link( '/sectors/' ); ?>">Sectors</a></li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><a href="<?php echo $cr_link( '/claims/' ); ?>">Make a claim</a></li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><a href="<?php echo $cr_link( '/insights/' ); ?>">Insights</a></li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><a href="<?php echo $cr_link( '/contact/' ); ?>">Contact and quotes</a></li>
<!-- /wp:list-item --></ul>
<!-- /wp:list --></div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column"><!-- wp:heading {"level":2,"textColor":"paper","fontSize":"medium"} -->
<h2 class="wp-block-heading has-paper-color has-text-color has-medium-font-size">Talk to us</h2>
<!-- /wp:heading -->

<!-- wp:list {"className":"cr-plain-list"} -->
<ul class="wp-block-list cr-plain-list"><!-- wp:list-item -->
<li>Office <a href="tel:+441134960412">0113 496 0412</a></li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>Claims, 24 hours <a href="tel:+441134960499">0113 496 0499</a></li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><a href="https://wa.me/447700900412">Message us on WhatsApp</a></li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><a href="mailto:hello@calderrowe.example">hello@calderrowe.example</a></li>
<!-- /wp:list-item --></ul>
<!-- /wp:list --></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->

<!-- wp:group {"align":"wide","className":"cr-footer__legal","style":{"spacing":{"padding":{"top":"var:preset|spacing|30"},"blockGap":"0.5rem 2rem"},"border":{"top":{"color":"#2b4d4a","width":"1px"}}},"fontSize":"small","layout":{"type":"flex","flexWrap":"wrap","justifyContent":"space-between","verticalAlignment":"top"}} -->
<div class="wp-block-group alignwide cr-footer__legal has-small-font-size" style="border-top-color:#2b4d4a;border-top-width:1px;padding-top:var(--wp--preset--spacing--30)"><!-- wp:paragraph {"className":"cr-demo-note"} -->
<p class="cr-demo-note">Demo site. Calder &amp; Rowe is a fictional brokerage created to show a WordPress block theme. It is not authorised or regulated and does not arrange insurance. Phone numbers use Ofcom's drama ranges.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>© 2026 Calder &amp; Rowe (demo)</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->

<!-- wp:pattern {"slug":"calder-rowe/mobile-actions"} /-->
