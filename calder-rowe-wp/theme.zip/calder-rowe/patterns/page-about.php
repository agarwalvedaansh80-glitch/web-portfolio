<?php
/**
 * Title: About page
 * Slug: calder-rowe/page-about
 * Categories: calder-rowe-pages
 * Keywords: about, company, story, principles
 * Post Types: page
 * Description: Firm story, three working principles on contour cards, promise and targets, and a call to action.
 */
?>
<!-- wp:group {"tagName":"section","align":"full","className":"cr-story-text","backgroundColor":"paper","textColor":"ink","layout":{"type":"constrained"}} -->
<section class="wp-block-group alignfull cr-story-text has-ink-color has-paper-background-color has-text-color has-background"><!-- wp:columns {"align":"wide"} -->
<div class="wp-block-columns alignwide"><!-- wp:column {"width":"42%"} -->
<div class="wp-block-column" style="flex-basis:42%"><!-- wp:heading {"className":"is-style-kinetic"} -->
<h2 class="wp-block-heading is-style-kinetic">Small enough to know you. <em>Independent</em> enough to say no.</h2>
<!-- /wp:heading --></div>
<!-- /wp:column -->

<!-- wp:column {"width":"58%","className":"cr-prose"} -->
<div class="wp-block-column cr-prose" style="flex-basis:58%"><!-- wp:paragraph {"className":"cr-lead"} -->
<p class="cr-lead">Calder &amp; Rowe was set up by brokers who wanted to work the way clients kept asking them to: one person who knows the account, advice in plain English, and real help when something goes wrong.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>We are independent, which means no insurer owns any part of the business and none sets our targets. Our job is to find the cover that fits how your business really runs, from a panel of insurers we re-test every year.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Most of our clients are owner-managed firms with between five and two hundred staff. Many came to us after a claim that did not go the way they expected. We would rather meet you before that happens.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></section>
<!-- /wp:group -->

<!-- wp:group {"tagName":"section","align":"full","className":"is-style-contour cr-principles","backgroundColor":"ink","textColor":"paper","layout":{"type":"constrained"}} -->
<section class="wp-block-group alignfull is-style-contour cr-principles has-paper-color has-ink-background-color has-text-color has-background"><!-- wp:heading {"className":"is-style-kinetic"} -->
<h2 class="wp-block-heading is-style-kinetic">How we <em>work</em></h2>
<!-- /wp:heading -->

<!-- wp:group {"align":"wide","className":"cr-principles__grid","layout":{"type":"grid","columnCount":3}} -->
<div class="wp-block-group alignwide cr-principles__grid"><!-- wp:group {"className":"cr-principle","layout":{"type":"default"}} -->
<div class="wp-block-group cr-principle"><!-- wp:paragraph {"className":"cr-principle__num"} -->
<p class="cr-principle__num">N</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Plain English first</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Every recommendation comes with a one-page summary of what is covered, what is not, and the conditions you must meet.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group {"className":"cr-principle","layout":{"type":"default"}} -->
<div class="wp-block-group cr-principle"><!-- wp:paragraph {"className":"cr-principle__num"} -->
<p class="cr-principle__num">E</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Advice in writing</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>We name the insurers we approached, show the options side by side and say which we would choose and why.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group {"className":"cr-principle","layout":{"type":"default"}} -->
<div class="wp-block-group cr-principle"><!-- wp:paragraph {"className":"cr-principle__num"} -->
<p class="cr-principle__num">S</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Costs agreed upfront</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>You will know how we are paid, by commission, fee or both, before you buy anything.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></section>
<!-- /wp:group -->

<!-- wp:pattern {"slug":"calder-rowe/proof"} /-->

<!-- wp:pattern {"slug":"calder-rowe/cta"} /-->
