<?php
/**
 * Title: About page
 * Slug: calder-rowe/page-about
 * Categories: calder-rowe-pages
 * Keywords: about, company, story, principles
 * Post Types: page
 * Description: Firm story, working principles, service standards and a call to action.
 */
?>
<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|60"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull" style="padding-top:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--60)"><!-- wp:columns {"align":"wide","style":{"spacing":{"blockGap":{"top":"var:preset|spacing|40","left":"var:preset|spacing|60"}}}} -->
<div class="wp-block-columns alignwide"><!-- wp:column {"width":"40%"} -->
<div class="wp-block-column" style="flex-basis:40%"><!-- wp:heading -->
<h2 class="wp-block-heading">Small enough to know you. Independent enough to say no.</h2>
<!-- /wp:heading --></div>
<!-- /wp:column -->

<!-- wp:column {"width":"60%","className":"cr-prose"} -->
<div class="wp-block-column cr-prose" style="flex-basis:60%"><!-- wp:paragraph {"fontSize":"medium"} -->
<p class="has-medium-font-size">Calder &amp; Rowe was set up by brokers who wanted to work the way clients kept asking them to: one person who knows the account, advice in plain English, and real help when something goes wrong.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>We are independent, which means no insurer owns any part of the business and none sets our targets. We work for you, and our job is to find the cover that fits how your business really runs, from a panel of insurers we review every year.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Most of our clients are owner-managed firms with between five and two hundred staff. Many came to us after a claim that did not go the way they expected. We would rather meet you before that happens.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group -->

<!-- wp:group {"align":"full","className":"cr-principles","style":{"spacing":{"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|60"},"blockGap":"var:preset|spacing|50"}},"backgroundColor":"canal","textColor":"paper","layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull cr-principles has-paper-color has-canal-background-color has-text-color has-background" style="padding-top:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--60)"><!-- wp:heading {"align":"wide"} -->
<h2 class="wp-block-heading alignwide">How we work</h2>
<!-- /wp:heading -->

<!-- wp:columns {"align":"wide","style":{"spacing":{"blockGap":{"top":"var:preset|spacing|40","left":"var:preset|spacing|50"}}}} -->
<div class="wp-block-columns alignwide"><!-- wp:column {"className":"cr-principle"} -->
<div class="wp-block-column cr-principle"><!-- wp:heading {"level":3,"fontSize":"large"} -->
<h3 class="wp-block-heading has-large-font-size">Plain English first</h3>
<!-- /wp:heading -->

<!-- wp:paragraph {"textColor":"mist"} -->
<p class="has-mist-color has-text-color">Every recommendation comes with a short summary of what is covered, what is not, and the conditions you must meet.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column {"className":"cr-principle"} -->
<div class="wp-block-column cr-principle"><!-- wp:heading {"level":3,"fontSize":"large"} -->
<h3 class="wp-block-heading has-large-font-size">Advice in writing</h3>
<!-- /wp:heading -->

<!-- wp:paragraph {"textColor":"mist"} -->
<p class="has-mist-color has-text-color">We name the insurers we approached, show the options side by side and say which we would choose and why.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column {"className":"cr-principle"} -->
<div class="wp-block-column cr-principle"><!-- wp:heading {"level":3,"fontSize":"large"} -->
<h3 class="wp-block-heading has-large-font-size">Costs agreed upfront</h3>
<!-- /wp:heading -->

<!-- wp:paragraph {"textColor":"mist"} -->
<p class="has-mist-color has-text-color">You will know how we are paid, by commission, fee or both, before you buy anything.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group -->

<!-- wp:pattern {"slug":"calder-rowe/stats-band"} /-->

<!-- wp:pattern {"slug":"calder-rowe/cta"} /-->
