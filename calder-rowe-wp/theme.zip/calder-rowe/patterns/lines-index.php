<?php
/**
 * Title: Lines of cover index
 * Slug: calder-rowe/lines-index
 * Categories: calder-rowe, services
 * Keywords: services, covers, lines, index, list
 * Description: An editorial numbered index of the insurance lines. Each row links to its service page; on desktop a contour preview follows the cursor.
 */
$cr_link = static function ( $path ) {
	return esc_url( home_url( $path ) );
};
$cr_lines = array(
	array( '01', 'Property &amp; business interruption', '/services/property-business-interruption/', 'Buildings, stock and machinery, plus the profit you lose while you rebuild.', 'Workshop cover from £48 a month' ),
	array( '02', 'Liability', '/services/liability-insurance/', 'Employers’, public, products and professional indemnity, matched to the contracts you sign.', 'Employers’ and public from £38 a month' ),
	array( '03', 'Cyber', '/services/cyber-insurance/', 'Incident response within hours, restored systems, and the income lost while you are offline.', '10-person office from £32 a month' ),
	array( '04', 'Fleet &amp; motor', '/services/fleet-motor-insurance/', 'Vans, cars and lorries on one policy, with breakdown cover and a replacement vehicle.', 'From £61 a month per van' ),
);
?>
<!-- wp:group {"tagName":"section","align":"full","className":"cr-lines","backgroundColor":"paper","textColor":"ink","layout":{"type":"constrained"}} -->
<section class="wp-block-group alignfull cr-lines has-ink-color has-paper-background-color has-text-color has-background"><!-- wp:columns {"align":"wide","className":"cr-lines__head"} -->
<div class="wp-block-columns alignwide cr-lines__head"><!-- wp:column {"width":"38%"} -->
<div class="wp-block-column" style="flex-basis:38%"><!-- wp:paragraph {"className":"cr-eyebrow"} -->
<p class="cr-eyebrow">Lines of cover</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column {"width":"62%"} -->
<div class="wp-block-column" style="flex-basis:62%"><!-- wp:heading {"className":"is-style-kinetic"} -->
<h2 class="wp-block-heading is-style-kinetic">Four lines of cover. <em>One broker</em> who knows them all.</h2>
<!-- /wp:heading --></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->

<!-- wp:group {"align":"wide","className":"cr-lines__list","layout":{"type":"default"}} -->
<div class="wp-block-group alignwide cr-lines__list"><?php foreach ( $cr_lines as $cr_line ) : ?><!-- wp:group {"className":"cr-line","layout":{"type":"default"}} -->
<div class="wp-block-group cr-line"><!-- wp:paragraph {"className":"cr-line__num"} -->
<p class="cr-line__num"><?php echo $cr_line[0]; ?></p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":3,"className":"cr-line__title"} -->
<h3 class="wp-block-heading cr-line__title"><a href="<?php echo $cr_link( $cr_line[2] ); ?>"><?php echo $cr_line[1]; ?></a></h3>
<!-- /wp:heading -->

<!-- wp:paragraph {"className":"cr-line__desc"} -->
<p class="cr-line__desc"><?php echo $cr_line[3]; ?></p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"className":"cr-line__meta"} -->
<p class="cr-line__meta"><?php echo $cr_line[4]; ?></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<?php endforeach; ?><!-- wp:paragraph {"className":"cr-lines__foot"} -->
<p class="cr-lines__foot">Need something else, such as directors’ and officers’ or marine cargo? <a href="<?php echo $cr_link( '/contact/' ); ?>">Ask a broker</a>. Premiums shown are illustrative starting points.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></section>
<!-- /wp:group -->
