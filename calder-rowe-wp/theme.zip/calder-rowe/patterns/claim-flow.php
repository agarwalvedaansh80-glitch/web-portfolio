<?php
/**
 * Title: How a claim works (pinned scroll scene)
 * Slug: calder-rowe/claim-flow
 * Categories: calder-rowe, text
 * Keywords: claims, process, steps, timeline, scroll
 * Description: The four stages of a claim (report, assess, settle, review). On wide screens the section pins while a progress line draws across the steps; elsewhere it is a plain ordered sequence.
 */
?>
<!-- wp:group {"align":"full","className":"cr-claimflow","style":{"spacing":{"padding":{"top":"var:preset|spacing|70","bottom":"var:preset|spacing|70"},"blockGap":"var:preset|spacing|60"},"elements":{"link":{"color":{"text":"var:preset|color|paper"}}}},"backgroundColor":"deep","textColor":"paper","layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull cr-claimflow has-paper-color has-deep-background-color has-text-color has-background has-link-color" style="padding-top:var(--wp--preset--spacing--70);padding-bottom:var(--wp--preset--spacing--70)"><!-- wp:columns {"verticalAlignment":"bottom","align":"wide","style":{"spacing":{"blockGap":{"top":"var:preset|spacing|30","left":"var:preset|spacing|60"}}}} -->
<div class="wp-block-columns alignwide are-vertically-aligned-bottom"><!-- wp:column {"verticalAlignment":"bottom","width":"50%"} -->
<div class="wp-block-column is-vertically-aligned-bottom" style="flex-basis:50%"><!-- wp:paragraph {"className":"cr-eyebrow","textColor":"marigold","fontSize":"small"} -->
<p class="cr-eyebrow has-marigold-color has-text-color has-small-font-size">When something goes wrong</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading">How a claim works</h2>
<!-- /wp:heading --></div>
<!-- /wp:column -->

<!-- wp:column {"verticalAlignment":"bottom","width":"50%"} -->
<div class="wp-block-column is-vertically-aligned-bottom" style="flex-basis:50%"><!-- wp:paragraph {"textColor":"mist","fontSize":"medium"} -->
<p class="has-mist-color has-text-color has-medium-font-size">Four stages, the same for every claim. The difference a broker makes is in who does the chasing.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->

<!-- wp:group {"align":"wide","className":"cr-claimflow__steps","style":{"spacing":{"blockGap":"var:preset|spacing|50"}},"layout":{"type":"grid","columnCount":4,"minimumColumnWidth":"14rem"}} -->
<div class="wp-block-group alignwide cr-claimflow__steps"><!-- wp:group {"className":"cr-cstep","style":{"spacing":{"blockGap":"0.6rem"}},"layout":{"type":"default"}} -->
<div class="wp-block-group cr-cstep"><!-- wp:paragraph {"className":"cr-cstep__num"} -->
<p class="cr-cstep__num">01</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"className":"cr-cstep__kicker"} -->
<p class="cr-cstep__kicker">Report</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":3,"fontSize":"large"} -->
<h3 class="wp-block-heading has-large-font-size">Tell us straight away</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Call the claims line or your broker as soon as you can, even if you are not sure the loss is covered. We log it with the insurer the same day and send you the reference.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"className":"cr-cstep__meta","fontSize":"small"} -->
<p class="cr-cstep__meta has-small-font-size">Day one</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group {"className":"cr-cstep","style":{"spacing":{"blockGap":"0.6rem"}},"layout":{"type":"default"}} -->
<div class="wp-block-group cr-cstep"><!-- wp:paragraph {"className":"cr-cstep__num"} -->
<p class="cr-cstep__num">02</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"className":"cr-cstep__kicker"} -->
<p class="cr-cstep__kicker">Assess</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":3,"fontSize":"large"} -->
<h3 class="wp-block-heading has-large-font-size">We work the evidence with you</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>The insurer may appoint a loss adjuster. We meet them with you, gather the photos, invoices and figures they ask for, and make sure nothing is missed.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"className":"cr-cstep__meta","fontSize":"small"} -->
<p class="cr-cstep__meta has-small-font-size">First weeks</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group {"className":"cr-cstep","style":{"spacing":{"blockGap":"0.6rem"}},"layout":{"type":"default"}} -->
<div class="wp-block-group cr-cstep"><!-- wp:paragraph {"className":"cr-cstep__num"} -->
<p class="cr-cstep__num">03</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"className":"cr-cstep__kicker"} -->
<p class="cr-cstep__kicker">Settle</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":3,"fontSize":"large"} -->
<h3 class="wp-block-heading has-large-font-size">We check the offer, then push</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>We test the settlement against your policy wording, challenge it where it falls short and ask for interim payments on larger claims.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"className":"cr-cstep__meta","fontSize":"small"} -->
<p class="cr-cstep__meta has-small-font-size">Weeks to months</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group {"className":"cr-cstep","style":{"spacing":{"blockGap":"0.6rem"}},"layout":{"type":"default"}} -->
<div class="wp-block-group cr-cstep"><!-- wp:paragraph {"className":"cr-cstep__num"} -->
<p class="cr-cstep__num">04</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"className":"cr-cstep__kicker"} -->
<p class="cr-cstep__kicker">Review</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":3,"fontSize":"large"} -->
<h3 class="wp-block-heading has-large-font-size">Fix the gap before renewal</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Once it is paid, we look at what happened, close any gaps in your cover and show insurers what has changed, so the claim weighs less at renewal.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"className":"cr-cstep__meta","fontSize":"small"} -->
<p class="cr-cstep__meta has-small-font-size">After settlement</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->

<!-- wp:group {"align":"wide","layout":{"type":"default"}} -->
<div class="wp-block-group alignwide"><!-- wp:paragraph {"className":"cr-claimflow__foot","textColor":"mist","fontSize":"small"} -->
<p class="cr-claimflow__foot has-mist-color has-text-color has-small-font-size">Timings vary by insurer and by the size of the loss. Illustrative content for a fictional broker.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->
