<?php
/**
 * Title: Lines of cover marquee
 * Slug: calder-rowe/marquee
 * Categories: calder-rowe
 * Keywords: marquee, ticker, kinetic, type
 * Description: A band of oversized italic type naming every line of cover. It drifts on its own and speeds up and reverses with your scroll.
 */
?>
<!-- wp:group {"align":"full","className":"cr-marquee","backgroundColor":"paper","textColor":"ink","layout":{"type":"default"}} -->
<div class="wp-block-group alignfull cr-marquee has-ink-color has-paper-background-color has-text-color has-background"><!-- wp:paragraph {"className":"cr-marquee__track"} -->
<p class="cr-marquee__track">Property <span>✦</span> Business interruption <span>✦</span> Employers’ liability <span>✦</span> Public liability <span>✦</span> Cyber <span>✦</span> Fleet &amp; motor <span>✦</span> Professional indemnity <span>✦</span> Directors &amp; officers <span>✦</span></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->
