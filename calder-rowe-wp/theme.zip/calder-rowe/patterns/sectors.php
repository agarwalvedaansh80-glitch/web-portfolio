<?php
/**
 * Title: Sectors grid
 * Slug: calder-rowe/sectors
 * Categories: calder-rowe
 * Keywords: sectors, industries, tiles, grid
 * Description: Six sector cards on a contour-lined grid, each with the covers that matter most in that trade.
 */
$cr_sectors = array(
	array( 'Manufacturing &amp; engineering', 'Machinery breakdown, product liability, goods in transit and the stock on your shelves.', 'Property · Products · Transit' ),
	array( 'Construction &amp; trades', 'Contract works, plant, employers’ liability and the insurance clauses in main contractor agreements.', 'Liability · Contract works · Plant' ),
	array( 'Hospitality &amp; leisure', 'Business interruption after a closure, food spoilage, licensing and public liability for busy premises.', 'Interruption · Public · Spoilage' ),
	array( 'Logistics &amp; distribution', 'Fleet, goods in transit, warehouse stock and the liability you accept under carriage terms.', 'Fleet · Transit · Warehouse' ),
	array( 'Professional services', 'Professional indemnity, cyber and management liability for firms that sell advice or design.', 'PI · Cyber · D&amp;O' ),
	array( 'Property owners', 'Let buildings, loss of rent, unoccupied property and terrorism cover for landlords and investors.', 'Buildings · Rent · Terrorism' ),
);
?>
<!-- wp:group {"tagName":"section","align":"full","className":"cr-sectors","backgroundColor":"paper","textColor":"ink","layout":{"type":"constrained"}} -->
<section class="wp-block-group alignfull cr-sectors has-ink-color has-paper-background-color has-text-color has-background"><!-- wp:group {"align":"wide","className":"cr-sectors__grid","layout":{"type":"grid","columnCount":3}} -->
<div class="wp-block-group alignwide cr-sectors__grid"><?php foreach ( $cr_sectors as $i => $cr_s ) : ?><!-- wp:group {"className":"cr-sector","layout":{"type":"default"}} -->
<div class="wp-block-group cr-sector"><!-- wp:paragraph {"className":"cr-sector__num"} -->
<p class="cr-sector__num"><?php echo sprintf( '%02d', $i + 1 ); ?></p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":3,"className":"cr-sector__title"} -->
<h3 class="wp-block-heading cr-sector__title"><?php echo $cr_s[0]; ?></h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p><?php echo $cr_s[1]; ?></p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"className":"cr-sector__tags"} -->
<p class="cr-sector__tags"><?php echo $cr_s[2]; ?></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<?php endforeach; ?></div>
<!-- /wp:group --></section>
<!-- /wp:group -->
