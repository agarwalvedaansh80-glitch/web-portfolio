<?php
/**
 * Title: Sectors
 * Slug: calder-rowe/sectors
 * Categories: calder-rowe, services
 * Keywords: sectors, industries, tiles
 * Description: Six sector tiles in a ruled grid. Each reveals the covers that matter most on hover or focus and links to the risk check with that sector chosen.
 */
$cr_icon  = static function ( $name ) {
	return esc_url( get_theme_file_uri( 'assets/icons/' . $name . '.svg' ) );
};
$cr_check = static function ( $sector ) {
	return esc_url( home_url( '/?sector=' . $sector . '#risk-check' ) );
};
?>
<!-- wp:group {"align":"full","className":"cr-sectors","style":{"spacing":{"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|60"},"blockGap":"var:preset|spacing|50"}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull cr-sectors" style="padding-top:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--60)"><!-- wp:group {"align":"wide","style":{"spacing":{"blockGap":"0.75rem"}},"layout":{"type":"constrained","contentSize":"640px","justifyContent":"left"}} -->
<div class="wp-block-group alignwide"><!-- wp:heading -->
<h2 class="wp-block-heading">Sectors we know well</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Every trade has its own pinch points. These are the sectors where our brokers spend most of their time, and the covers that usually matter most.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group {"align":"wide","className":"cr-tiles","style":{"spacing":{"blockGap":"0px"}},"layout":{"type":"grid","columnCount":3,"minimumColumnWidth":"16rem"}} -->
<div class="wp-block-group alignwide cr-tiles">
<!-- wp:group {"className":"cr-tile","style":{"spacing":{"padding":{"top":"var:preset|spacing|40","bottom":"var:preset|spacing|40","left":"var:preset|spacing|40","right":"var:preset|spacing|40"},"blockGap":"0.6rem"}},"layout":{"type":"default"}} -->
<div class="wp-block-group cr-tile" style="padding-top:var(--wp--preset--spacing--40);padding-right:var(--wp--preset--spacing--40);padding-bottom:var(--wp--preset--spacing--40);padding-left:var(--wp--preset--spacing--40)"><!-- wp:paragraph {"className":"cr-tile__num"} -->
<p class="cr-tile__num">01</p>
<!-- /wp:paragraph -->

<!-- wp:image {"width":"44px","height":"44px","sizeSlug":"full","linkDestination":"none","className":"cr-tile__icon"} -->
<figure class="wp-block-image size-full is-resized cr-tile__icon"><img src="<?php echo $cr_icon( 'manufacturing' ); ?>" alt="" style="width:44px;height:44px"/></figure>
<!-- /wp:image -->

<!-- wp:heading {"level":3,"className":"cr-tile__title","fontSize":"large"} -->
<h3 class="wp-block-heading cr-tile__title has-large-font-size"><a href="<?php echo $cr_check( 'manufacturing' ); ?>">Manufacturing and engineering</a></h3>
<!-- /wp:heading -->

<!-- wp:paragraph {"className":"cr-tile__text","fontSize":"small"} -->
<p class="cr-tile__text has-small-font-size">Machinery breakdown, product liability, goods in transit and the stock on your shelves.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"className":"cr-tile__cta","fontSize":"small"} -->
<p class="cr-tile__cta has-small-font-size">Check typical covers</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->


<!-- wp:group {"className":"cr-tile","style":{"spacing":{"padding":{"top":"var:preset|spacing|40","bottom":"var:preset|spacing|40","left":"var:preset|spacing|40","right":"var:preset|spacing|40"},"blockGap":"0.6rem"}},"layout":{"type":"default"}} -->
<div class="wp-block-group cr-tile" style="padding-top:var(--wp--preset--spacing--40);padding-right:var(--wp--preset--spacing--40);padding-bottom:var(--wp--preset--spacing--40);padding-left:var(--wp--preset--spacing--40)"><!-- wp:paragraph {"className":"cr-tile__num"} -->
<p class="cr-tile__num">02</p>
<!-- /wp:paragraph -->

<!-- wp:image {"width":"44px","height":"44px","sizeSlug":"full","linkDestination":"none","className":"cr-tile__icon"} -->
<figure class="wp-block-image size-full is-resized cr-tile__icon"><img src="<?php echo $cr_icon( 'construction' ); ?>" alt="" style="width:44px;height:44px"/></figure>
<!-- /wp:image -->

<!-- wp:heading {"level":3,"className":"cr-tile__title","fontSize":"large"} -->
<h3 class="wp-block-heading cr-tile__title has-large-font-size"><a href="<?php echo $cr_check( 'construction' ); ?>">Construction and trades</a></h3>
<!-- /wp:heading -->

<!-- wp:paragraph {"className":"cr-tile__text","fontSize":"small"} -->
<p class="cr-tile__text has-small-font-size">Contract works, plant, employers' liability and the insurance clauses in main contractor agreements.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"className":"cr-tile__cta","fontSize":"small"} -->
<p class="cr-tile__cta has-small-font-size">Check typical covers</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->


<!-- wp:group {"className":"cr-tile","style":{"spacing":{"padding":{"top":"var:preset|spacing|40","bottom":"var:preset|spacing|40","left":"var:preset|spacing|40","right":"var:preset|spacing|40"},"blockGap":"0.6rem"}},"layout":{"type":"default"}} -->
<div class="wp-block-group cr-tile" style="padding-top:var(--wp--preset--spacing--40);padding-right:var(--wp--preset--spacing--40);padding-bottom:var(--wp--preset--spacing--40);padding-left:var(--wp--preset--spacing--40)"><!-- wp:paragraph {"className":"cr-tile__num"} -->
<p class="cr-tile__num">03</p>
<!-- /wp:paragraph -->

<!-- wp:image {"width":"44px","height":"44px","sizeSlug":"full","linkDestination":"none","className":"cr-tile__icon"} -->
<figure class="wp-block-image size-full is-resized cr-tile__icon"><img src="<?php echo $cr_icon( 'hospitality' ); ?>" alt="" style="width:44px;height:44px"/></figure>
<!-- /wp:image -->

<!-- wp:heading {"level":3,"className":"cr-tile__title","fontSize":"large"} -->
<h3 class="wp-block-heading cr-tile__title has-large-font-size"><a href="<?php echo $cr_check( 'hospitality' ); ?>">Hospitality and leisure</a></h3>
<!-- /wp:heading -->

<!-- wp:paragraph {"className":"cr-tile__text","fontSize":"small"} -->
<p class="cr-tile__text has-small-font-size">Business interruption after a closure, food spoilage, licensing and public liability for busy premises.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"className":"cr-tile__cta","fontSize":"small"} -->
<p class="cr-tile__cta has-small-font-size">Check typical covers</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->


<!-- wp:group {"className":"cr-tile","style":{"spacing":{"padding":{"top":"var:preset|spacing|40","bottom":"var:preset|spacing|40","left":"var:preset|spacing|40","right":"var:preset|spacing|40"},"blockGap":"0.6rem"}},"layout":{"type":"default"}} -->
<div class="wp-block-group cr-tile" style="padding-top:var(--wp--preset--spacing--40);padding-right:var(--wp--preset--spacing--40);padding-bottom:var(--wp--preset--spacing--40);padding-left:var(--wp--preset--spacing--40)"><!-- wp:paragraph {"className":"cr-tile__num"} -->
<p class="cr-tile__num">04</p>
<!-- /wp:paragraph -->

<!-- wp:image {"width":"44px","height":"44px","sizeSlug":"full","linkDestination":"none","className":"cr-tile__icon"} -->
<figure class="wp-block-image size-full is-resized cr-tile__icon"><img src="<?php echo $cr_icon( 'logistics' ); ?>" alt="" style="width:44px;height:44px"/></figure>
<!-- /wp:image -->

<!-- wp:heading {"level":3,"className":"cr-tile__title","fontSize":"large"} -->
<h3 class="wp-block-heading cr-tile__title has-large-font-size"><a href="<?php echo $cr_check( 'logistics' ); ?>">Logistics and distribution</a></h3>
<!-- /wp:heading -->

<!-- wp:paragraph {"className":"cr-tile__text","fontSize":"small"} -->
<p class="cr-tile__text has-small-font-size">Fleet, goods in transit, warehouse stock and the liability you accept under carriage terms.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"className":"cr-tile__cta","fontSize":"small"} -->
<p class="cr-tile__cta has-small-font-size">Check typical covers</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->


<!-- wp:group {"className":"cr-tile","style":{"spacing":{"padding":{"top":"var:preset|spacing|40","bottom":"var:preset|spacing|40","left":"var:preset|spacing|40","right":"var:preset|spacing|40"},"blockGap":"0.6rem"}},"layout":{"type":"default"}} -->
<div class="wp-block-group cr-tile" style="padding-top:var(--wp--preset--spacing--40);padding-right:var(--wp--preset--spacing--40);padding-bottom:var(--wp--preset--spacing--40);padding-left:var(--wp--preset--spacing--40)"><!-- wp:paragraph {"className":"cr-tile__num"} -->
<p class="cr-tile__num">05</p>
<!-- /wp:paragraph -->

<!-- wp:image {"width":"44px","height":"44px","sizeSlug":"full","linkDestination":"none","className":"cr-tile__icon"} -->
<figure class="wp-block-image size-full is-resized cr-tile__icon"><img src="<?php echo $cr_icon( 'professional' ); ?>" alt="" style="width:44px;height:44px"/></figure>
<!-- /wp:image -->

<!-- wp:heading {"level":3,"className":"cr-tile__title","fontSize":"large"} -->
<h3 class="wp-block-heading cr-tile__title has-large-font-size"><a href="<?php echo $cr_check( 'professional' ); ?>">Professional services</a></h3>
<!-- /wp:heading -->

<!-- wp:paragraph {"className":"cr-tile__text","fontSize":"small"} -->
<p class="cr-tile__text has-small-font-size">Professional indemnity, cyber and management liability for firms that sell advice or design.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"className":"cr-tile__cta","fontSize":"small"} -->
<p class="cr-tile__cta has-small-font-size">Check typical covers</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->


<!-- wp:group {"className":"cr-tile","style":{"spacing":{"padding":{"top":"var:preset|spacing|40","bottom":"var:preset|spacing|40","left":"var:preset|spacing|40","right":"var:preset|spacing|40"},"blockGap":"0.6rem"}},"layout":{"type":"default"}} -->
<div class="wp-block-group cr-tile" style="padding-top:var(--wp--preset--spacing--40);padding-right:var(--wp--preset--spacing--40);padding-bottom:var(--wp--preset--spacing--40);padding-left:var(--wp--preset--spacing--40)"><!-- wp:paragraph {"className":"cr-tile__num"} -->
<p class="cr-tile__num">06</p>
<!-- /wp:paragraph -->

<!-- wp:image {"width":"44px","height":"44px","sizeSlug":"full","linkDestination":"none","className":"cr-tile__icon"} -->
<figure class="wp-block-image size-full is-resized cr-tile__icon"><img src="<?php echo $cr_icon( 'property' ); ?>" alt="" style="width:44px;height:44px"/></figure>
<!-- /wp:image -->

<!-- wp:heading {"level":3,"className":"cr-tile__title","fontSize":"large"} -->
<h3 class="wp-block-heading cr-tile__title has-large-font-size"><a href="<?php echo $cr_check( 'property' ); ?>">Property owners</a></h3>
<!-- /wp:heading -->

<!-- wp:paragraph {"className":"cr-tile__text","fontSize":"small"} -->
<p class="cr-tile__text has-small-font-size">Let buildings, loss of rent, unoccupied property and terrorism cover for landlords and investors.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"className":"cr-tile__cta","fontSize":"small"} -->
<p class="cr-tile__cta has-small-font-size">Check typical covers</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->

<!-- wp:group {"align":"wide","layout":{"type":"default"}} -->
<div class="wp-block-group alignwide"><!-- wp:paragraph {"className":"cr-more","style":{"typography":{"fontWeight":"600"}}} -->
<p class="cr-more" style="font-weight:600">Not on the list? <a href="<?php echo esc_url( home_url( '/contact/' ) ); ?>">Tell us what your business does</a> and we will tell you honestly whether we are the right broker.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->
