<?php
/**
 * Title: Service sidebar
 * Slug: calder-rowe/service-aside
 * Categories: calder-rowe
 * Inserter: no
 * Description: Sticky contact panel and links to the other services, used by the Service page template.
 */
$cr_link = static function ( $path ) {
	return esc_url( home_url( $path ) );
};
?>
<!-- wp:group {"className":"cr-aside","style":{"spacing":{"blockGap":"var:preset|spacing|40"}},"layout":{"type":"default"}} -->
<div class="wp-block-group cr-aside"><!-- wp:group {"className":"cr-panel","style":{"spacing":{"padding":{"top":"var:preset|spacing|40","bottom":"var:preset|spacing|40","left":"var:preset|spacing|40","right":"var:preset|spacing|40"},"blockGap":"0.9rem"},"border":{"radius":"10px"},"elements":{"link":{"color":{"text":"var:preset|color|paper"}}}},"backgroundColor":"canal","textColor":"paper","layout":{"type":"default"}} -->
<div class="wp-block-group cr-panel has-paper-color has-canal-background-color has-text-color has-background has-link-color" style="border-radius:10px;padding-top:var(--wp--preset--spacing--40);padding-right:var(--wp--preset--spacing--40);padding-bottom:var(--wp--preset--spacing--40);padding-left:var(--wp--preset--spacing--40)"><!-- wp:heading {"level":2,"fontSize":"large"} -->
<h2 class="wp-block-heading has-large-font-size">Talk it through with a broker</h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"textColor":"mist"} -->
<p class="has-mist-color has-text-color">Fifteen minutes on the phone usually tells us whether your current cover fits. No charge, no obligation.</p>
<!-- /wp:paragraph -->

<!-- wp:buttons {"layout":{"type":"flex","orientation":"vertical","justifyContent":"stretch"}} -->
<div class="wp-block-buttons"><!-- wp:button {"backgroundColor":"marigold","textColor":"ink","width":100} -->
<div class="wp-block-button has-custom-width wp-block-button__width-100"><a class="wp-block-button__link has-ink-color has-marigold-background-color has-text-color has-background wp-element-button" href="<?php echo $cr_link( '/contact/' ); ?>">Request a quote</a></div>
<!-- /wp:button -->

<!-- wp:button {"textColor":"paper","width":100,"className":"is-style-outline"} -->
<div class="wp-block-button has-custom-width wp-block-button__width-100 is-style-outline"><a class="wp-block-button__link has-paper-color has-text-color wp-element-button" href="tel:+441134960412">Call 0113 496 0412</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons -->

<!-- wp:paragraph {"fontSize":"small"} -->
<p class="has-small-font-size"><a href="https://wa.me/447700900412">Or message us on WhatsApp</a></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group {"className":"cr-aside__links","style":{"spacing":{"blockGap":"0.5rem","padding":{"left":"var:preset|spacing|40","right":"var:preset|spacing|40"}}},"layout":{"type":"default"}} -->
<div class="wp-block-group cr-aside__links" style="padding-right:var(--wp--preset--spacing--40);padding-left:var(--wp--preset--spacing--40)"><!-- wp:heading {"level":2,"fontSize":"medium"} -->
<h2 class="wp-block-heading has-medium-font-size">Other services</h2>
<!-- /wp:heading -->

<!-- wp:list {"className":"cr-plain-list"} -->
<ul class="wp-block-list cr-plain-list"><!-- wp:list-item -->
<li><a href="<?php echo $cr_link( '/services/property-business-interruption/' ); ?>">Property and business interruption</a></li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><a href="<?php echo $cr_link( '/services/liability-insurance/' ); ?>">Liability insurance</a></li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><a href="<?php echo $cr_link( '/services/cyber-insurance/' ); ?>">Cyber insurance</a></li>
<!-- /wp:list-item --></ul>
<!-- /wp:list --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->
