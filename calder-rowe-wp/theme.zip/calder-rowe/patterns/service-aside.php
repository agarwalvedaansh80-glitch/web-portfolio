<?php
/**
 * Title: Service call-back card
 * Slug: calder-rowe/service-aside
 * Categories: calder-rowe
 * Inserter: no
 * Description: Sticky call-back card and links to the other lines of cover, used by the Service page template.
 */
$cr_link = static function ( $path ) {
	return esc_url( home_url( $path ) );
};
?>
<!-- wp:group {"className":"cr-aside","layout":{"type":"default"}} -->
<div class="wp-block-group cr-aside"><!-- wp:group {"anchor":"svc-callback","className":"is-style-card cr-callback cr-callback--aside","layout":{"type":"default"}} -->
<div id="svc-callback" class="wp-block-group is-style-card cr-callback cr-callback--aside"><!-- wp:paragraph {"className":"cr-kicker"} -->
<p class="cr-kicker">Free 15-minute cover check</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"className":"cr-callback__title","fontSize":"x-large"} -->
<h2 class="wp-block-heading cr-callback__title has-x-large-font-size">Is your current cover right?</h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"className":"cr-callback__text"} -->
<p class="cr-callback__text">Leave a number. A broker who places this line every week will call you back within four office hours.</p>
<!-- /wp:paragraph -->

<!-- wp:html -->
<form class="cr-form cr-form--callback" action="<?php echo $cr_link( '/contact/' ); ?>" method="post" data-cr-form novalidate>
	<div class="cr-field">
		<label for="sa-name">Your name</label>
		<input id="sa-name" name="name" type="text" autocomplete="name" required aria-describedby="sa-name-err">
		<p class="cr-field__error" id="sa-name-err"></p>
	</div>
	<div class="cr-field">
		<label for="sa-phone">Phone number</label>
		<input id="sa-phone" name="phone" type="tel" autocomplete="tel" inputmode="tel" required pattern="[0-9 +]{10,}" aria-describedby="sa-phone-err">
		<p class="cr-field__error" id="sa-phone-err"></p>
	</div>
	<input type="hidden" name="topic" value="service">
	<button type="submit" class="cr-form__submit"><span class="cr-form__label">Call me back</span></button>
	<p class="cr-form__note">Or call <a href="tel:+441134960412">0113 496 0412</a></p>
	<p class="cr-form__status" role="status" aria-live="polite"></p>
</form>
<!-- /wp:html --></div>
<!-- /wp:group -->

<!-- wp:group {"className":"cr-aside__links","layout":{"type":"default"}} -->
<div class="wp-block-group cr-aside__links"><!-- wp:paragraph {"className":"cr-kicker"} -->
<p class="cr-kicker">Other lines</p>
<!-- /wp:paragraph -->

<!-- wp:list {"className":"cr-plain-list cr-aside__list"} -->
<ul class="wp-block-list cr-plain-list cr-aside__list"><!-- wp:list-item -->
<li><a href="<?php echo $cr_link( '/services/property-business-interruption/' ); ?>">Property &amp; business interruption</a></li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><a href="<?php echo $cr_link( '/services/liability-insurance/' ); ?>">Liability</a></li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><a href="<?php echo $cr_link( '/services/cyber-insurance/' ); ?>">Cyber</a></li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><a href="<?php echo $cr_link( '/services/fleet-motor-insurance/' ); ?>">Fleet &amp; motor</a></li>
<!-- /wp:list-item --></ul>
<!-- /wp:list --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->
