<?php
/**
 * Title: Service page
 * Slug: calder-rowe/service-page
 * Categories: calder-rowe-pages, services
 * Keywords: service, product, cover, insurance
 * Post Types: page
 * Block Types: core/post-content
 * Description: The reusable service page body: lead, what it covers, an animated cover comparison table, who it suits and what moves the price, an illustrative example and FAQs. Use with the Service page template, which adds the parallax hero and call-back card.
 */
?>
<!-- wp:paragraph {"className":"cr-lead"} -->
<p class="cr-lead">Describe in one or two sentences what this cover does and the problem it solves for the client.</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"className":"is-style-kinetic"} -->
<h2 class="wp-block-heading is-style-kinetic">What it <em>covers</em></h2>
<!-- /wp:heading -->

<!-- wp:list {"className":"is-style-isobar"} -->
<ul class="wp-block-list is-style-isobar"><!-- wp:list-item -->
<li><strong>Main cover</strong>, in plain words</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><strong>Second cover</strong>, and what it pays for</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><strong>Optional extras</strong> worth asking about</li>
<!-- /wp:list-item --></ul>
<!-- /wp:list -->

<!-- wp:heading {"className":"is-style-kinetic","anchor":"compare"} -->
<h2 class="wp-block-heading is-style-kinetic" id="compare">Compare the <em>levels</em></h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Three levels most clients choose between. Edit the table: use ✓ for included and — for not included.</p>
<!-- /wp:paragraph -->

<!-- wp:table {"className":"is-style-compare"} -->
<figure class="wp-block-table is-style-compare"><table class="has-fixed-layout"><thead><tr><th>What is included</th><th>Essential</th><th>Standard</th><th>Complete</th></tr></thead><tbody><tr><td>First cover</td><td>✓</td><td>✓</td><td>✓</td></tr><tr><td>Second cover</td><td>—</td><td>✓</td><td>✓</td></tr><tr><td>Third cover</td><td>—</td><td>Optional</td><td>✓</td></tr><tr><td>Typical monthly premium</td><td>£00</td><td>£00</td><td>£00</td></tr></tbody></table><figcaption class="wp-element-caption">✓ included · — not included. Illustrative levels and premiums for a typical small firm; your quote depends on your business.</figcaption></figure>
<!-- /wp:table -->

<!-- wp:group {"className":"is-style-contour cr-panel","backgroundColor":"ink","textColor":"paper","layout":{"type":"default"}} -->
<div class="wp-block-group is-style-contour cr-panel has-paper-color has-ink-background-color has-text-color has-background"><!-- wp:columns {"className":"cr-split"} -->
<div class="wp-block-columns cr-split"><!-- wp:column -->
<div class="wp-block-column"><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Who it suits</h3>
<!-- /wp:heading -->

<!-- wp:list -->
<ul class="wp-block-list"><!-- wp:list-item -->
<li>The kind of business that needs this</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>A second typical client</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>A third typical client</li>
<!-- /wp:list-item --></ul>
<!-- /wp:list --></div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column"><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">What moves the price</h3>
<!-- /wp:heading -->

<!-- wp:list -->
<ul class="wp-block-list"><!-- wp:list-item -->
<li>The biggest factor in the premium</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>A second rating factor</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>Something the client can improve</li>
<!-- /wp:list-item --></ul>
<!-- /wp:list --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group -->

<!-- wp:heading {"className":"is-style-kinetic"} -->
<h2 class="wp-block-heading is-style-kinetic">An illustrative <em>example</em></h2>
<!-- /wp:heading -->

<!-- wp:group {"className":"cr-example","layout":{"type":"default"}} -->
<div class="wp-block-group cr-example"><!-- wp:paragraph -->
<p>Describe a short hypothetical loss and what the policy paid for, step by step.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"className":"cr-example__note"} -->
<p class="cr-example__note">A hypothetical scenario to show how the cover works. Not a real client or claim.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:heading {"className":"is-style-kinetic"} -->
<h2 class="wp-block-heading is-style-kinetic">Common <em>questions</em></h2>
<!-- /wp:heading -->

<!-- wp:details {"className":"is-style-fold"} -->
<details class="wp-block-details is-style-fold"><summary>First common question?</summary><!-- wp:paragraph -->
<p>A short, plain answer.</p>
<!-- /wp:paragraph --></details>
<!-- /wp:details -->

<!-- wp:details {"className":"is-style-fold"} -->
<details class="wp-block-details is-style-fold"><summary>Second common question?</summary><!-- wp:paragraph -->
<p>A short, plain answer.</p>
<!-- /wp:paragraph --></details>
<!-- /wp:details -->

<!-- wp:details {"className":"is-style-fold"} -->
<details class="wp-block-details is-style-fold"><summary>Third common question?</summary><!-- wp:paragraph -->
<p>A short, plain answer.</p>
<!-- /wp:paragraph --></details>
<!-- /wp:details -->
