<?php
/**
 * Title: Service page
 * Slug: calder-rowe/service-page
 * Categories: calder-rowe-pages, services
 * Keywords: service, product, cover, insurance
 * Post Types: page
 * Block Types: core/post-content
 * Description: The reusable service page body: lead and actions, what it covers, who it suits, pricing factors, an illustrative example and FAQs. Use with the Service page template.
 */
?>
<!-- wp:paragraph {"className":"cr-lead"} -->
<p class="cr-lead">Describe in one or two sentences what this cover does and the problem it solves for the client.</p>
<!-- /wp:paragraph -->

<!-- wp:buttons -->
<div class="wp-block-buttons"><!-- wp:button -->
<div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="<?php echo esc_url( home_url( '/contact/' ) ); ?>">Request a quote</a></div>
<!-- /wp:button -->

<!-- wp:button {"textColor":"canal","className":"is-style-outline"} -->
<div class="wp-block-button is-style-outline"><a class="wp-block-button__link has-canal-color has-text-color wp-element-button" href="tel:+441134960412">Call a broker</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons -->

<!-- wp:heading -->
<h2 class="wp-block-heading">What it covers</h2>
<!-- /wp:heading -->

<!-- wp:list -->
<ul class="wp-block-list"><!-- wp:list-item -->
<li><strong>Main cover</strong>, in plain words</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><strong>Second cover</strong>, and what it pays for</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><strong>Optional extras</strong> worth asking about</li>
<!-- /wp:list-item --></ul>
<!-- /wp:list -->

<!-- wp:group {"className":"cr-panel","style":{"spacing":{"padding":{"top":"var:preset|spacing|40","bottom":"var:preset|spacing|40","left":"var:preset|spacing|40","right":"var:preset|spacing|40"},"blockGap":"var:preset|spacing|30"},"border":{"radius":"10px"}},"backgroundColor":"stone","layout":{"type":"default"}} -->
<div class="wp-block-group cr-panel has-stone-background-color has-background" style="border-radius:10px;padding-top:var(--wp--preset--spacing--40);padding-right:var(--wp--preset--spacing--40);padding-bottom:var(--wp--preset--spacing--40);padding-left:var(--wp--preset--spacing--40)"><!-- wp:columns {"className":"cr-split","style":{"spacing":{"blockGap":{"top":"var:preset|spacing|40","left":"var:preset|spacing|50"}}}} -->
<div class="wp-block-columns cr-split"><!-- wp:column -->
<div class="wp-block-column"><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Who it suits</h3>
<!-- /wp:heading -->

<!-- wp:list -->
<ul class="wp-block-list"><!-- wp:list-item -->
<li>The kind of business that needs this</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>A second typical client</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>A third typical client</li>
<!-- /wp:list-item --></ul>
<!-- /wp:list --></div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column"><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">What affects the price</h3>
<!-- /wp:heading -->

<!-- wp:list -->
<ul class="wp-block-list"><!-- wp:list-item -->
<li>The biggest factor in the premium</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>A second rating factor</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>Something the client can improve</li>
<!-- /wp:list-item --></ul>
<!-- /wp:list --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group -->

<!-- wp:heading -->
<h2 class="wp-block-heading">An illustrative example</h2>
<!-- /wp:heading -->

<!-- wp:group {"className":"cr-example","style":{"spacing":{"padding":{"left":"var:preset|spacing|40"},"blockGap":"0.6rem"}},"layout":{"type":"default"}} -->
<div class="wp-block-group cr-example" style="padding-left:var(--wp--preset--spacing--40)"><!-- wp:paragraph -->
<p>Describe a short hypothetical loss and what the policy paid for, step by step.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"className":"cr-example__note"} -->
<p class="cr-example__note">A hypothetical scenario to show how the cover works. Not a real client or claim.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:heading -->
<h2 class="wp-block-heading">Common questions</h2>
<!-- /wp:heading -->

<!-- wp:details -->
<details class="wp-block-details"><summary>First common question?</summary><!-- wp:paragraph -->
<p>A short, plain answer.</p>
<!-- /wp:paragraph --></details>
<!-- /wp:details -->

<!-- wp:details -->
<details class="wp-block-details"><summary>Second common question?</summary><!-- wp:paragraph -->
<p>A short, plain answer.</p>
<!-- /wp:paragraph --></details>
<!-- /wp:details -->

<!-- wp:details -->
<details class="wp-block-details"><summary>Third common question?</summary><!-- wp:paragraph -->
<p>A short, plain answer.</p>
<!-- /wp:paragraph --></details>
<!-- /wp:details -->
