<?php
/**
 * Title: Contact and quote page
 * Slug: calder-rowe/page-contact
 * Categories: calder-rowe-pages
 * Keywords: contact, quote, form
 * Post Types: page
 * Description: Quote request form with direct contact details.
 */
?>
<!-- wp:pattern {"slug":"calder-rowe/quote-form"} /-->
