<?php
/**
 * Title: Page not found
 * Slug: calder-rowe/not-found
 * Categories: calder-rowe
 * Inserter: no
 * Description: 404 message with search and the most useful links.
 */
?>
<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|70","bottom":"var:preset|spacing|70"},"blockGap":"var:preset|spacing|40"}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull" style="padding-top:var(--wp--preset--spacing--70);padding-bottom:var(--wp--preset--spacing--70)"><!-- wp:heading {"level":1} -->
<h1 class="wp-block-heading">We can't find that page</h1>
<!-- /wp:heading -->

<!-- wp:paragraph {"fontSize":"medium"} -->
<p class="has-medium-font-size">The link may be out of date, or the page has moved. Search the site, or go straight to what most people need.</p>
<!-- /wp:paragraph -->

<!-- wp:search {"label":"Search the site","buttonText":"Search","className":"cr-search"} /-->

<!-- wp:list {"className":"cr-plain-list cr-links"} -->
<ul class="wp-block-list cr-plain-list cr-links"><!-- wp:list-item -->
<li><a href="<?php echo esc_url( home_url( '/contact/' ) ); ?>">Request a quote</a></li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><a href="<?php echo esc_url( home_url( '/claims/' ) ); ?>">Report a claim</a></li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><a href="<?php echo esc_url( home_url( '/services/' ) ); ?>">Browse services</a></li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><a href="<?php echo esc_url( home_url( '/' ) ); ?>">Go to the home page</a></li>
<!-- /wp:list-item --></ul>
<!-- /wp:list --></div>
<!-- /wp:group -->
