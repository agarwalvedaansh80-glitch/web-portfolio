<?php
/**
 * Title: Page not found
 * Slug: calder-rowe/not-found
 * Categories: calder-rowe
 * Inserter: no
 * Description: Off-the-map 404 message with search and the most useful links.
 */
?>
<!-- wp:group {"tagName":"section","align":"full","className":"is-style-contour cr-404","backgroundColor":"ink","textColor":"paper","layout":{"type":"constrained"}} -->
<section class="wp-block-group alignfull is-style-contour cr-404 has-paper-color has-ink-background-color has-text-color has-background"><!-- wp:paragraph {"className":"cr-eyebrow"} -->
<p class="cr-eyebrow">Error 404 · off the chart</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":1,"className":"is-style-kinetic"} -->
<h1 class="wp-block-heading is-style-kinetic">This page has drifted <em>off the map.</em></h1>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>The link may be out of date, or the page has moved. Search the site, or head straight for what most people need.</p>
<!-- /wp:paragraph -->

<!-- wp:search {"label":"Search the site","buttonText":"Search","className":"cr-search"} /-->

<!-- wp:buttons -->
<div class="wp-block-buttons"><!-- wp:button {"className":"cr-magnetic"} -->
<div class="wp-block-button cr-magnetic"><a class="wp-block-button__link wp-element-button" href="<?php echo esc_url( home_url( '/contact/' ) ); ?>">Request a quote</a></div>
<!-- /wp:button -->

<!-- wp:button {"className":"is-style-ghost"} -->
<div class="wp-block-button is-style-ghost"><a class="wp-block-button__link wp-element-button" href="<?php echo esc_url( home_url( '/claims/' ) ); ?>">Report a claim</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></section>
<!-- /wp:group -->
