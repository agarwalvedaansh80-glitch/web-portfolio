<?php
/**
 * Title: Service standards band
 * Slug: calder-rowe/stats-band
 * Categories: calder-rowe, text
 * Keywords: stats, numbers, service levels, figures, counter
 * Description: Four service targets shown as figures that count up when scrolled into view. They are commitments, not results; edit them to match your client agreement.
 */
?>
<!-- wp:group {"align":"full","className":"cr-stats","style":{"spacing":{"padding":{"top":"var:preset|spacing|70","bottom":"var:preset|spacing|70"},"blockGap":"var:preset|spacing|60"}},"backgroundColor":"canal","textColor":"paper","layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull cr-stats has-paper-color has-canal-background-color has-text-color has-background" style="padding-top:var(--wp--preset--spacing--70);padding-bottom:var(--wp--preset--spacing--70)"><!-- wp:columns {"verticalAlignment":"bottom","align":"wide","style":{"spacing":{"blockGap":{"top":"var:preset|spacing|30","left":"var:preset|spacing|60"}}}} -->
<div class="wp-block-columns alignwide are-vertically-aligned-bottom"><!-- wp:column {"verticalAlignment":"bottom","width":"50%"} -->
<div class="wp-block-column is-vertically-aligned-bottom" style="flex-basis:50%"><!-- wp:heading -->
<h2 class="wp-block-heading">Service targets we put in writing</h2>
<!-- /wp:heading --></div>
<!-- /wp:column -->

<!-- wp:column {"verticalAlignment":"bottom","width":"50%"} -->
<div class="wp-block-column is-vertically-aligned-bottom" style="flex-basis:50%"><!-- wp:paragraph {"textColor":"mist"} -->
<p class="has-mist-color has-text-color">Targets in every client agreement of this demo firm. They describe how we work, not results or claims about real clients.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->

<!-- wp:group {"align":"wide","className":"cr-figures","style":{"spacing":{"blockGap":"var:preset|spacing|40"}},"layout":{"type":"grid","columnCount":4,"minimumColumnWidth":"13rem"}} -->
<div class="wp-block-group alignwide cr-figures"><!-- wp:group {"className":"cr-figure","style":{"spacing":{"blockGap":"0.5rem"}},"layout":{"type":"default"}} -->
<div class="wp-block-group cr-figure"><!-- wp:paragraph {"className":"cr-figure__value"} -->
<p class="cr-figure__value">24h</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>First-response target for new enquiries on working days.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group {"className":"cr-figure","style":{"spacing":{"blockGap":"0.5rem"}},"layout":{"type":"default"}} -->
<div class="wp-block-group cr-figure"><!-- wp:paragraph {"className":"cr-figure__value"} -->
<p class="cr-figure__value">6 sectors</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Where our brokers spend most of their time, from workshops to landlords.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group {"className":"cr-figure","style":{"spacing":{"blockGap":"0.5rem"}},"layout":{"type":"default"}} -->
<div class="wp-block-group cr-figure"><!-- wp:paragraph {"className":"cr-figure__value"} -->
<p class="cr-figure__value">4 stages</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>In every claim, from first call to review, worked alongside you.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group {"className":"cr-figure","style":{"spacing":{"blockGap":"0.5rem"}},"layout":{"type":"default"}} -->
<div class="wp-block-group cr-figure"><!-- wp:paragraph {"className":"cr-figure__value"} -->
<p class="cr-figure__value">6 weeks</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Before expiry, we start your renewal review and test the market.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->
