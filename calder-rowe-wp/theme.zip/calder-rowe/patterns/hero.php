<?php
/**
 * Title: Hero: contour field with call-back form
 * Slug: calder-rowe/hero
 * Categories: calder-rowe, banner
 * Keywords: hero, banner, call back, lead, form, contour, weather
 * Description: Full-height ink-navy hero. The script paints a live contour map behind it that ripples away from the cursor; the headline words slide and settle. The call-back form sits in the first screen.
 */
$cr_contact = esc_url( home_url( '/contact/' ) );
?>
<!-- wp:group {"tagName":"section","align":"full","className":"cr-hero","backgroundColor":"ink","textColor":"paper","layout":{"type":"constrained"}} -->
<section class="wp-block-group alignfull cr-hero has-paper-color has-ink-background-color has-text-color has-background"><!-- wp:columns {"verticalAlignment":"center","align":"wide","className":"cr-hero__grid"} -->
<div class="wp-block-columns alignwide are-vertically-aligned-center cr-hero__grid"><!-- wp:column {"verticalAlignment":"center","width":"60%","className":"cr-hero__copy"} -->
<div class="wp-block-column is-vertically-aligned-center cr-hero__copy" style="flex-basis:60%"><!-- wp:paragraph {"className":"cr-eyebrow"} -->
<p class="cr-eyebrow">Independent business insurance brokers · Leeds &amp; the North</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":1,"className":"is-style-kinetic cr-hero__title"} -->
<h1 class="wp-block-heading is-style-kinetic cr-hero__title">When it storms, we stay <em>calm.</em></h1>
<!-- /wp:heading -->

<!-- wp:paragraph {"className":"cr-hero__lead"} -->
<p class="cr-hero__lead">We place your cover across 34 insurers. When the worst happens, a named broker works the claim with you, from the first call to the final payment.</p>
<!-- /wp:paragraph -->

<!-- wp:buttons {"className":"cr-hero__actions"} -->
<div class="wp-block-buttons cr-hero__actions"><!-- wp:button {"className":"is-style-ghost cr-magnetic"} -->
<div class="wp-block-button is-style-ghost cr-magnetic"><a class="wp-block-button__link wp-element-button" href="#risk-check">Take the 60-second risk check</a></div>
<!-- /wp:button -->

<!-- wp:button {"className":"is-style-arrow"} -->
<div class="wp-block-button is-style-arrow"><a class="wp-block-button__link wp-element-button" href="tel:+441134960499">Claims, 24 hours: 0113 496 0499</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:column -->

<!-- wp:column {"verticalAlignment":"center","width":"40%","className":"cr-hero__form"} -->
<div class="wp-block-column is-vertically-aligned-center cr-hero__form" style="flex-basis:40%"><!-- wp:group {"anchor":"callback","className":"is-style-card cr-callback","layout":{"type":"default"}} -->
<div id="callback" class="wp-block-group is-style-card cr-callback"><!-- wp:paragraph {"className":"cr-kicker"} -->
<p class="cr-kicker">Call-back · within 4 office hours</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"className":"cr-callback__title"} -->
<h2 class="wp-block-heading cr-callback__title">Talk to a broker, not a&nbsp;form.</h2>
<!-- /wp:heading -->

<!-- wp:html -->
<form class="cr-form cr-form--callback" action="<?php echo $cr_contact; ?>" method="post" data-cr-form novalidate>
	<div class="cr-field">
		<label for="cb-name">Your name</label>
		<input id="cb-name" name="name" type="text" autocomplete="name" required aria-describedby="cb-name-err">
		<p class="cr-field__error" id="cb-name-err"></p>
	</div>
	<div class="cr-field">
		<label for="cb-phone">Phone number</label>
		<input id="cb-phone" name="phone" type="tel" autocomplete="tel" inputmode="tel" required pattern="[0-9 +]{10,}" aria-describedby="cb-phone-err">
		<p class="cr-field__error" id="cb-phone-err"></p>
	</div>
	<fieldset class="cr-chips">
		<legend>It's about</legend>
		<label><input type="radio" name="topic" value="quote" checked><span>A new quote</span></label>
		<label><input type="radio" name="topic" value="renewal"><span>My renewal</span></label>
		<label><input type="radio" name="topic" value="claim"><span>A claim</span></label>
	</fieldset>
	<button type="submit" class="cr-form__submit"><span class="cr-form__label">Call me back</span></button>
	<p class="cr-form__note">Mon to Fri, 8.30am to 5.30pm. We only use your number to call you back.</p>
	<p class="cr-form__status" role="status" aria-live="polite"></p>
</form>
<!-- /wp:html --></div>
<!-- /wp:group --></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->

<!-- wp:group {"align":"wide","className":"cr-hero__foot","layout":{"type":"flex","flexWrap":"wrap","justifyContent":"space-between"}} -->
<div class="wp-block-group alignwide cr-hero__foot"><!-- wp:paragraph -->
<p><strong>3 rings</strong> pickup target on the claims line</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p><strong>34 insurers</strong> on a panel we review every year</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p><strong>1 named broker</strong> from quote to claim</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"className":"cr-hero__readout"} -->
<p class="cr-hero__readout">53.79° N · 1.54° W</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></section>
<!-- /wp:group -->
