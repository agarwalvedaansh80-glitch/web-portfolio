<?php
/**
 * Title: Hero with call-back form
 * Slug: calder-rowe/hero
 * Categories: calder-rowe, banner
 * Keywords: hero, banner, call back, lead, form
 * Description: Headline, quote and risk-check actions, and a three-field call-back form over the animated contour map on the canal green band.
 */
?>
<!-- wp:group {"align":"full","className":"cr-hero cr-contours","style":{"spacing":{"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|60"}},"elements":{"link":{"color":{"text":"var:preset|color|paper"}}}},"backgroundColor":"canal","textColor":"paper","layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull cr-hero cr-contours has-paper-color has-canal-background-color has-text-color has-background has-link-color" style="padding-top:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--60)"><!-- wp:columns {"verticalAlignment":"center","align":"wide","style":{"spacing":{"blockGap":{"top":"var:preset|spacing|50","left":"var:preset|spacing|60"}}}} -->
<div class="wp-block-columns alignwide are-vertically-aligned-center"><!-- wp:column {"verticalAlignment":"center","width":"58%","className":"cr-hero__copy"} -->
<div class="wp-block-column is-vertically-aligned-center cr-hero__copy" style="flex-basis:58%"><!-- wp:paragraph {"className":"cr-eyebrow","textColor":"mist","fontSize":"small"} -->
<p class="cr-eyebrow has-mist-color has-text-color has-small-font-size">Independent business insurance broker, Leeds</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":1,"className":"cr-hero__title"} -->
<h1 class="wp-block-heading cr-hero__title">Business insurance with a broker beside you at claim time.</h1>
<!-- /wp:heading -->

<!-- wp:paragraph {"className":"cr-hero__lead","textColor":"mist","fontSize":"medium"} -->
<p class="cr-hero__lead has-mist-color has-text-color has-medium-font-size">Calder &amp; Rowe is an independent broker in Leeds. We compare cover from a panel of insurers, explain the wording in plain English, and work the claim with you from the first phone call.</p>
<!-- /wp:paragraph -->

<!-- wp:buttons {"style":{"spacing":{"margin":{"top":"var:preset|spacing|40"}}}} -->
<div class="wp-block-buttons" style="margin-top:var(--wp--preset--spacing--40)"><!-- wp:button {"backgroundColor":"marigold","textColor":"ink"} -->
<div class="wp-block-button"><a class="wp-block-button__link has-ink-color has-marigold-background-color has-text-color has-background wp-element-button" href="<?php echo esc_url( home_url( '/contact/' ) ); ?>">Request a quote</a></div>
<!-- /wp:button -->

<!-- wp:button {"textColor":"paper","className":"is-style-outline"} -->
<div class="wp-block-button is-style-outline"><a class="wp-block-button__link has-paper-color has-text-color wp-element-button" href="#risk-check">Take the 60-second risk check</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons -->

<!-- wp:paragraph {"className":"cr-hero__note","textColor":"mist","fontSize":"small"} -->
<p class="cr-hero__note has-mist-color has-text-color has-small-font-size">Office hours Monday to Friday, 8.30am to 5.30pm. Claims line open 24 hours.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column {"verticalAlignment":"center","width":"42%","className":"cr-hero__form"} -->
<div class="wp-block-column is-vertically-aligned-center cr-hero__form" style="flex-basis:42%"><!-- wp:group {"className":"cr-callback","style":{"spacing":{"padding":{"top":"var:preset|spacing|40","bottom":"var:preset|spacing|40","left":"var:preset|spacing|40","right":"var:preset|spacing|40"},"blockGap":"0.75rem"},"border":{"radius":"10px"},"elements":{"link":{"color":{"text":"var:preset|color|canal"}}}},"backgroundColor":"paper","textColor":"ink","layout":{"type":"default"}} -->
<div class="wp-block-group cr-callback has-ink-color has-paper-background-color has-text-color has-background has-link-color" style="border-radius:10px;padding-top:var(--wp--preset--spacing--40);padding-right:var(--wp--preset--spacing--40);padding-bottom:var(--wp--preset--spacing--40);padding-left:var(--wp--preset--spacing--40)"><!-- wp:heading {"fontSize":"x-large"} -->
<h2 class="wp-block-heading has-x-large-font-size">Prefer we call you?</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Leave a number and a broker will ring you back within four office hours.</p>
<!-- /wp:paragraph -->

<!-- wp:html -->
<form class="cr-form cr-form--compact" action="<?php echo esc_url( home_url( '/contact/' ) ); ?>" method="post" data-cr-form>
	<div class="cr-field">
		<label for="cb-name">Your name</label>
		<input id="cb-name" name="name" type="text" autocomplete="name" required>
	</div>
	<div class="cr-field">
		<label for="cb-phone">Phone number</label>
		<input id="cb-phone" name="phone" type="tel" autocomplete="tel" inputmode="tel" required>
	</div>
	<div class="cr-field">
		<label for="cb-topic">What is it about?</label>
		<select id="cb-topic" name="topic">
			<option>A new quote</option>
			<option>Reviewing my renewal</option>
			<option>A claim</option>
			<option>Something else</option>
		</select>
	</div>
	<button type="submit" class="cr-form__submit">Request a call-back</button>
	<p class="cr-form__note">We use your number only to call you back about this request.</p>
	<p class="cr-form__status" role="status" aria-live="polite"></p>
</form>
<!-- /wp:html --></div>
<!-- /wp:group --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group -->
