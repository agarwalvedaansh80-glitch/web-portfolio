<?php
/**
 * Title: Quote request form
 * Slug: calder-rowe/quote-form
 * Categories: calder-rowe, call-to-action
 * Keywords: form, quote, contact, lead, enquiry
 * Description: Accessible quote request form with live field feedback, beside a what-happens-next card and a contour map of the office. Static markup: swap the HTML block for a form plugin block in production.
 */
?>
<!-- wp:group {"tagName":"section","align":"full","className":"cr-quote","backgroundColor":"paper","textColor":"ink","layout":{"type":"constrained"}} -->
<section class="wp-block-group alignfull cr-quote has-ink-color has-paper-background-color has-text-color has-background"><!-- wp:columns {"align":"wide","className":"cr-quote__grid"} -->
<div class="wp-block-columns alignwide cr-quote__grid"><!-- wp:column {"width":"60%"} -->
<div class="wp-block-column" style="flex-basis:60%"><!-- wp:heading {"className":"is-style-kinetic","anchor":"quote"} -->
<h2 class="wp-block-heading is-style-kinetic" id="quote">Request a <em>quote</em></h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Tell us a little about the business. A broker replies within one working day, usually by phone, to ask the questions a form cannot.</p>
<!-- /wp:paragraph -->

<!-- wp:html -->
<form class="cr-form cr-form--quote" action="<?php echo esc_url( home_url( '/contact/' ) ); ?>" method="post" data-cr-form novalidate>
	<p class="cr-form__required-note">All fields are required unless marked optional.</p>
	<div class="cr-form__grid">
		<div class="cr-field">
			<label for="q-business">Business name</label>
			<input id="q-business" name="business" type="text" autocomplete="organization" required aria-describedby="q-business-err">
			<p class="cr-field__error" id="q-business-err"></p>
		</div>
		<div class="cr-field">
			<label for="q-name">Your name</label>
			<input id="q-name" name="name" type="text" autocomplete="name" required aria-describedby="q-name-err">
			<p class="cr-field__error" id="q-name-err"></p>
		</div>
		<div class="cr-field">
			<label for="q-email">Email</label>
			<input id="q-email" name="email" type="email" autocomplete="email" required aria-describedby="q-email-err">
			<p class="cr-field__error" id="q-email-err"></p>
		</div>
		<div class="cr-field">
			<label for="q-phone">Phone</label>
			<input id="q-phone" name="phone" type="tel" autocomplete="tel" inputmode="tel" required pattern="[0-9 +]{10,}" aria-describedby="q-phone-err">
			<p class="cr-field__error" id="q-phone-err"></p>
		</div>
		<div class="cr-field">
			<label for="q-sector">Sector</label>
			<select id="q-sector" name="sector" required aria-describedby="q-sector-err">
				<option value="">Choose a sector</option>
				<option>Manufacturing and engineering</option>
				<option>Construction and trades</option>
				<option>Hospitality and leisure</option>
				<option>Logistics and distribution</option>
				<option>Professional services</option>
				<option>Property owner</option>
				<option>Something else</option>
			</select>
			<p class="cr-field__error" id="q-sector-err"></p>
		</div>
		<div class="cr-field">
			<label for="q-renewal">Renewal date <span class="cr-optional">(optional)</span></label>
			<input id="q-renewal" name="renewal" type="date" aria-describedby="q-renewal-hint">
			<p class="cr-hint" id="q-renewal-hint">When your current policy ends, if you have one.</p>
		</div>
	</div>
	<fieldset class="cr-chips cr-chips--multi">
		<legend>Cover you need</legend>
		<label><input type="checkbox" name="cover[]" value="property"><span>Property &amp; interruption</span></label>
		<label><input type="checkbox" name="cover[]" value="liability"><span>Liability</span></label>
		<label><input type="checkbox" name="cover[]" value="cyber"><span>Cyber</span></label>
		<label><input type="checkbox" name="cover[]" value="fleet"><span>Fleet &amp; motor</span></label>
		<label><input type="checkbox" name="cover[]" value="unsure"><span>Not sure yet</span></label>
	</fieldset>
	<div class="cr-field">
		<label for="q-details">Anything we should know? <span class="cr-optional">(optional)</span></label>
		<textarea id="q-details" name="details" rows="4" maxlength="600" aria-describedby="q-details-hint"></textarea>
		<p class="cr-hint" id="q-details-hint">For example turnover, staff numbers, sites, or a recent claim.</p>
	</div>
	<fieldset class="cr-chips">
		<legend>How should we reply?</legend>
		<label><input type="radio" name="reply" value="phone" checked><span>Phone</span></label>
		<label><input type="radio" name="reply" value="email"><span>Email</span></label>
	</fieldset>
	<label class="cr-consent"><input type="checkbox" name="consent" required><span>I agree to Calder &amp; Rowe contacting me about this quote. We only share your details with the insurers we approach for you.</span></label>
	<button type="submit" class="cr-form__submit"><span class="cr-form__label">Send quote request</span></button>
	<p class="cr-form__status" role="status" aria-live="polite"></p>
</form>
<!-- /wp:html --></div>
<!-- /wp:column -->

<!-- wp:column {"width":"40%","className":"cr-quote__side"} -->
<div class="wp-block-column cr-quote__side" style="flex-basis:40%"><!-- wp:group {"className":"is-style-card cr-next","layout":{"type":"default"}} -->
<div class="wp-block-group is-style-card cr-next"><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">What happens next</h3>
<!-- /wp:heading -->

<!-- wp:list {"ordered":true,"className":"is-style-isobar"} -->
<ol class="wp-block-list is-style-isobar"><!-- wp:list-item -->
<li>A broker calls you within one working day.</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>We approach the insurers that suit your risk.</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>You get a written comparison and our recommendation.</li>
<!-- /wp:list-item --></ol>
<!-- /wp:list --></div>
<!-- /wp:group -->

<!-- wp:group {"className":"is-style-contour cr-office","backgroundColor":"ink","textColor":"paper","layout":{"type":"default"}} -->
<div class="wp-block-group is-style-contour cr-office has-paper-color has-ink-background-color has-text-color has-background"><!-- wp:paragraph {"className":"cr-kicker"} -->
<p class="cr-kicker">The office · 53.7954° N</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"className":"cr-office__addr"} -->
<p class="cr-office__addr">4 Granary Wharf<br>Leeds LS1 4BR</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"className":"cr-office__lines"} -->
<p class="cr-office__lines">Office <a href="tel:+441134960412">0113 496 0412</a><br>Claims, 24h <a href="tel:+441134960499">0113 496 0499</a><br><a href="mailto:hello@calderrowe.example">hello@calderrowe.example</a></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></section>
<!-- /wp:group -->
