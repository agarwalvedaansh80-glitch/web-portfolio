<?php
/**
 * Title: Quote request form
 * Slug: calder-rowe/quote-form
 * Categories: calder-rowe, call-to-action
 * Keywords: form, quote, contact, lead, enquiry
 * Description: Semantic quote request form beside a "what happens next" panel and direct contact details. Static markup: swap the HTML block for a Contact Form 7 or WPForms block in production.
 */
?>
<!-- wp:group {"align":"full","className":"cr-quote","style":{"spacing":{"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|60"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull cr-quote" style="padding-top:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--60)"><!-- wp:columns {"align":"wide","style":{"spacing":{"blockGap":{"top":"var:preset|spacing|50","left":"var:preset|spacing|60"}}}} -->
<div class="wp-block-columns alignwide"><!-- wp:column {"width":"62%"} -->
<div class="wp-block-column" style="flex-basis:62%"><!-- wp:heading {"className":"cr-anchor","anchor":"quote"} -->
<h2 class="wp-block-heading cr-anchor" id="quote">Request a quote</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Tell us a little about the business. A broker will reply within one working day, usually by phone, to ask the questions a form cannot.</p>
<!-- /wp:paragraph -->

<!-- wp:html -->
<form class="cr-form cr-form--quote" action="<?php echo esc_url( home_url( '/contact/' ) ); ?>" method="post" data-cr-form novalidate>
	<p class="cr-form__required-note">All fields are required unless marked optional.</p>
	<div class="cr-form__grid">
		<div class="cr-field">
			<label for="q-business">Business name</label>
			<input id="q-business" name="business" type="text" autocomplete="organization" required>
		</div>
		<div class="cr-field">
			<label for="q-name">Your name</label>
			<input id="q-name" name="name" type="text" autocomplete="name" required>
		</div>
		<div class="cr-field">
			<label for="q-email">Email</label>
			<input id="q-email" name="email" type="email" autocomplete="email" required>
		</div>
		<div class="cr-field">
			<label for="q-phone">Phone</label>
			<input id="q-phone" name="phone" type="tel" autocomplete="tel" inputmode="tel" required>
		</div>
		<div class="cr-field">
			<label for="q-sector">Sector</label>
			<select id="q-sector" name="sector" required>
				<option value="">Choose a sector</option>
				<option>Manufacturing and engineering</option>
				<option>Construction and trades</option>
				<option>Hospitality and leisure</option>
				<option>Logistics and distribution</option>
				<option>Professional services</option>
				<option>Property owner</option>
				<option>Something else</option>
			</select>
		</div>
		<div class="cr-field">
			<label for="q-renewal">Renewal date <span class="cr-optional">(optional)</span></label>
			<input id="q-renewal" name="renewal" type="date" aria-describedby="q-renewal-hint">
			<p class="cr-hint" id="q-renewal-hint">The date your current policy ends, if you have one.</p>
		</div>
	</div>
	<fieldset class="cr-choices">
		<legend>Cover you need</legend>
		<label><input type="checkbox" name="cover[]" value="property"> Property and business interruption</label>
		<label><input type="checkbox" name="cover[]" value="liability"> Liability</label>
		<label><input type="checkbox" name="cover[]" value="cyber"> Cyber</label>
		<label><input type="checkbox" name="cover[]" value="fleet"> Fleet and motor</label>
		<label><input type="checkbox" name="cover[]" value="unsure"> Not sure yet</label>
	</fieldset>
	<div class="cr-field">
		<label for="q-details">Anything we should know? <span class="cr-optional">(optional)</span></label>
		<textarea id="q-details" name="details" rows="4" aria-describedby="q-details-hint"></textarea>
		<p class="cr-hint" id="q-details-hint">For example turnover, number of staff, sites, or a recent claim.</p>
	</div>
	<fieldset class="cr-choices cr-choices--inline">
		<legend>How should we reply?</legend>
		<label><input type="radio" name="reply" value="phone" checked> Phone</label>
		<label><input type="radio" name="reply" value="email"> Email</label>
		<label><input type="radio" name="reply" value="whatsapp"> WhatsApp</label>
	</fieldset>
	<label class="cr-consent"><input type="checkbox" name="consent" required> I agree to Calder &amp; Rowe contacting me about this quote. We never pass your details to anyone except the insurers we approach for you.</label>
	<button type="submit" class="cr-form__submit">Send quote request</button>
	<p class="cr-form__status" role="status" aria-live="polite"></p>
</form>
<!-- /wp:html --></div>
<!-- /wp:column -->

<!-- wp:column {"width":"38%"} -->
<div class="wp-block-column" style="flex-basis:38%"><!-- wp:group {"className":"cr-panel","style":{"spacing":{"padding":{"top":"var:preset|spacing|40","bottom":"var:preset|spacing|40","left":"var:preset|spacing|40","right":"var:preset|spacing|40"},"blockGap":"var:preset|spacing|30"},"border":{"radius":"10px"}},"backgroundColor":"stone","layout":{"type":"default"}} -->
<div class="wp-block-group cr-panel has-stone-background-color has-background" style="border-radius:10px;padding-top:var(--wp--preset--spacing--40);padding-right:var(--wp--preset--spacing--40);padding-bottom:var(--wp--preset--spacing--40);padding-left:var(--wp--preset--spacing--40)"><!-- wp:heading {"level":3,"fontSize":"large"} -->
<h3 class="wp-block-heading has-large-font-size">What happens next</h3>
<!-- /wp:heading -->

<!-- wp:list {"ordered":true,"className":"cr-next-steps"} -->
<ol class="wp-block-list cr-next-steps"><!-- wp:list-item -->
<li>A broker calls you within one working day.</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>We approach the insurers that suit your risk.</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>You get a written comparison and our recommendation.</li>
<!-- /wp:list-item --></ol>
<!-- /wp:list -->

<!-- wp:separator {"className":"is-style-wide"} -->
<hr class="wp-block-separator has-alpha-channel-opacity is-style-wide"/>
<!-- /wp:separator -->

<!-- wp:heading {"level":3,"fontSize":"medium"} -->
<h3 class="wp-block-heading has-medium-font-size">Rather talk now?</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Office <a href="tel:+441134960412">0113 496 0412</a><br>Claims, 24 hours <a href="tel:+441134960499">0113 496 0499</a><br><a href="https://wa.me/447700900412">Message us on WhatsApp</a><br><a href="mailto:hello@calderrowe.example">hello@calderrowe.example</a></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group -->
