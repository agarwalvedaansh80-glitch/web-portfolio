<?php
/**
 * Title: Header
 * Slug: calder-rowe/header
 * Categories: header
 * Block Types: core/template-part/header
 * Inserter: no
 * Description: Claims-line strip, site title, navigation, phone number and quote button.
 */
?>
<!-- wp:group {"className":"cr-utility","style":{"spacing":{"padding":{"top":"0.45rem","bottom":"0.45rem"}},"elements":{"link":{"color":{"text":"var:preset|color|paper"}}}},"backgroundColor":"deep","textColor":"mist","fontSize":"small","layout":{"type":"constrained"}} -->
<div class="wp-block-group cr-utility has-mist-color has-deep-background-color has-text-color has-background has-link-color has-small-font-size" style="padding-top:0.45rem;padding-bottom:0.45rem"><!-- wp:group {"align":"wide","style":{"spacing":{"blockGap":"0.5rem 2rem"}},"layout":{"type":"flex","flexWrap":"wrap","justifyContent":"space-between"}} -->
<div class="wp-block-group alignwide"><!-- wp:paragraph -->
<p>Claims line, open 24 hours: <a href="tel:+441134960499">0113 496 0499</a></p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"className":"cr-hide-mobile"} -->
<p class="cr-hide-mobile">Office open Monday to Friday, 8.30am to 5.30pm</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->

<!-- wp:group {"className":"cr-masthead","style":{"spacing":{"padding":{"top":"1rem","bottom":"1rem"}},"border":{"bottom":{"color":"var:preset|color|stone","width":"1px"}}},"backgroundColor":"paper","layout":{"type":"constrained"}} -->
<div class="wp-block-group cr-masthead has-paper-background-color has-background" style="border-bottom-color:var(--wp--preset--color--stone);border-bottom-width:1px;padding-top:1rem;padding-bottom:1rem"><!-- wp:group {"align":"wide","style":{"spacing":{"blockGap":"var:preset|spacing|40"}},"layout":{"type":"flex","flexWrap":"nowrap","justifyContent":"space-between"}} -->
<div class="wp-block-group alignwide"><!-- wp:site-title {"level":0,"className":"cr-brand"} /-->

<!-- wp:group {"className":"cr-nav-wrap","style":{"spacing":{"blockGap":"var:preset|spacing|40"}},"layout":{"type":"flex","flexWrap":"nowrap","justifyContent":"right"}} -->
<div class="wp-block-group cr-nav-wrap"><!-- wp:navigation {"overlayMenu":"mobile","overlayBackgroundColor":"paper","overlayTextColor":"ink","className":"cr-nav","style":{"spacing":{"blockGap":"1.6rem"}},"layout":{"type":"flex","justifyContent":"right"}} /-->

<!-- wp:paragraph {"className":"cr-header-phone","style":{"typography":{"fontWeight":"600"}}} -->
<p class="cr-header-phone" style="font-weight:600"><a href="tel:+441134960412">0113 496 0412</a></p>
<!-- /wp:paragraph -->

<!-- wp:buttons {"className":"cr-header-cta"} -->
<div class="wp-block-buttons cr-header-cta"><!-- wp:button {"backgroundColor":"marigold","textColor":"ink","fontSize":"small"} -->
<div class="wp-block-button has-custom-font-size has-small-font-size"><a class="wp-block-button__link has-ink-color has-marigold-background-color has-text-color has-background wp-element-button" href="<?php echo esc_url( home_url( '/contact/' ) ); ?>">Get a quote</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->
