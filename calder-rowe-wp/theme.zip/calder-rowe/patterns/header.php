<?php
/**
 * Title: Header
 * Slug: calder-rowe/header
 * Categories: header
 * Block Types: core/template-part/header
 * Inserter: no
 * Description: Sticky ink-navy masthead: wordmark with compass mark, navigation, live office line and a magnetic call-back button.
 */
?>
<!-- wp:group {"className":"cr-header","backgroundColor":"ink","textColor":"paper","layout":{"type":"constrained"}} -->
<div class="wp-block-group cr-header has-paper-color has-ink-background-color has-text-color has-background"><!-- wp:group {"align":"wide","className":"cr-header__bar","layout":{"type":"flex","flexWrap":"nowrap","justifyContent":"space-between"}} -->
<div class="wp-block-group alignwide cr-header__bar"><!-- wp:site-title {"level":0,"className":"cr-brand"} /-->

<!-- wp:navigation {"overlayMenu":"mobile","overlayBackgroundColor":"ink","overlayTextColor":"paper","className":"cr-nav","layout":{"type":"flex","justifyContent":"center"}} /-->

<!-- wp:group {"className":"cr-header__actions","layout":{"type":"flex","flexWrap":"nowrap"}} -->
<div class="wp-block-group cr-header__actions"><!-- wp:paragraph {"className":"cr-header__line"} -->
<p class="cr-header__line"><span class="cr-live" aria-hidden="true"></span>Lines open <a href="tel:+441134960412">0113 496 0412</a></p>
<!-- /wp:paragraph -->

<!-- wp:buttons {"className":"cr-header__cta"} -->
<div class="wp-block-buttons cr-header__cta"><!-- wp:button {"className":"cr-magnetic","fontSize":"small"} -->
<div class="wp-block-button has-custom-font-size cr-magnetic has-small-font-size"><a class="wp-block-button__link wp-element-button" href="<?php echo esc_url( home_url( '/#callback' ) ); ?>">Call me back</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->
