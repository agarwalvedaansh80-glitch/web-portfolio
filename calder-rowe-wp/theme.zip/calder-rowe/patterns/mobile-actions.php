<?php
/**
 * Title: Mobile call and WhatsApp bar
 * Slug: calder-rowe/mobile-actions
 * Categories: calder-rowe, call-to-action
 * Keywords: sticky, mobile, phone, whatsapp, click to call
 * Description: Two large actions pinned to the bottom of small screens. Hidden on desktop, where the header shows the phone number.
 */
?>
<!-- wp:group {"className":"cr-actionbar","style":{"spacing":{"blockGap":"0.5rem","padding":{"top":"0.5rem","bottom":"0.5rem","left":"0.5rem","right":"0.5rem"}}},"backgroundColor":"paper","layout":{"type":"flex","flexWrap":"nowrap","justifyContent":"space-between"}} -->
<div class="wp-block-group cr-actionbar has-paper-background-color has-background" style="padding-top:0.5rem;padding-right:0.5rem;padding-bottom:0.5rem;padding-left:0.5rem"><!-- wp:buttons {"className":"cr-actionbar__buttons","layout":{"type":"flex","flexWrap":"nowrap"}} -->
<div class="wp-block-buttons cr-actionbar__buttons"><!-- wp:button {"backgroundColor":"canal","textColor":"paper","width":50,"className":"cr-act cr-act--call"} -->
<div class="wp-block-button has-custom-width wp-block-button__width-50 cr-act cr-act--call"><a class="wp-block-button__link has-paper-color has-canal-background-color has-text-color has-background wp-element-button" href="tel:+441134960412">Call us</a></div>
<!-- /wp:button -->

<!-- wp:button {"backgroundColor":"marigold","textColor":"ink","width":50,"className":"cr-act cr-act--whatsapp"} -->
<div class="wp-block-button has-custom-width wp-block-button__width-50 cr-act cr-act--whatsapp"><a class="wp-block-button__link has-ink-color has-marigold-background-color has-text-color has-background wp-element-button" href="https://wa.me/447700900412">WhatsApp</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:group -->
