<?php
/**
 * Title: Mobile click-to-call bar
 * Slug: calder-rowe/mobile-actions
 * Categories: calder-rowe, call-to-action
 * Keywords: sticky, mobile, phone, click to call, claims
 * Description: Two large tap targets pinned to the bottom of small screens: call a broker, or the 24-hour claims line. Hidden on desktop, where the header shows the number.
 */
?>
<!-- wp:group {"className":"cr-actionbar","backgroundColor":"ink","textColor":"paper","layout":{"type":"flex","flexWrap":"nowrap","justifyContent":"space-between"}} -->
<div class="wp-block-group cr-actionbar has-paper-color has-ink-background-color has-text-color has-background"><!-- wp:buttons {"className":"cr-actionbar__buttons","layout":{"type":"flex","flexWrap":"nowrap"}} -->
<div class="wp-block-buttons cr-actionbar__buttons"><!-- wp:button {"className":"cr-act cr-act--call"} -->
<div class="wp-block-button cr-act cr-act--call"><a class="wp-block-button__link wp-element-button" href="tel:+441134960412">Call a broker</a></div>
<!-- /wp:button -->

<!-- wp:button {"className":"is-style-ghost cr-act cr-act--claims"} -->
<div class="wp-block-button is-style-ghost cr-act cr-act--claims"><a class="wp-block-button__link wp-element-button" href="tel:+441134960499">Claims 24h</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:group -->
