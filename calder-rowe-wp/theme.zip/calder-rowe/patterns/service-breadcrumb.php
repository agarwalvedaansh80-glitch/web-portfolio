<?php
/**
 * Title: Service breadcrumb
 * Slug: calder-rowe/service-breadcrumb
 * Categories: calder-rowe
 * Inserter: no
 * Description: Link back to the services overview, shown above the service title.
 */
?>
<!-- wp:paragraph {"className":"cr-crumb","fontSize":"small"} -->
<p class="cr-crumb has-small-font-size"><a href="<?php echo esc_url( home_url( '/services/' ) ); ?>">Services</a></p>
<!-- /wp:paragraph -->
