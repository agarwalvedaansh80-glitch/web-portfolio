<?php
/**
 * Title: Service breadcrumb
 * Slug: calder-rowe/service-breadcrumb
 * Categories: calder-rowe
 * Inserter: no
 * Description: Link back to the lines of cover, shown above the service title.
 */
?>
<!-- wp:paragraph {"className":"cr-crumb"} -->
<p class="cr-crumb"><a href="<?php echo esc_url( home_url( '/services/' ) ); ?>">Lines of cover</a> <span aria-hidden="true">/</span></p>
<!-- /wp:paragraph -->
