<?php
/**
 * Title: Risk check: five cards and a risk barometer
 * Slug: calder-rowe/risk-check
 * Categories: calder-rowe, call-to-action
 * Keywords: risk, check, quiz, game, cards, dial, barometer, interactive
 * Description: Five yes-or-no question cards you can flick or click. A barometer-style risk dial swings as you answer, then the result recommends lines of cover and offers a call-back. Without JavaScript it is a plain form.
 */
$cr_contact = esc_url( home_url( '/contact/' ) );
$cr_qs      = array(
	array( 'staff', 'liability', 'Do you employ anyone, even part-time or seasonal?', 'Employers’ liability is a legal requirement for almost every UK employer.' ),
	array( 'public', 'liability', 'Do customers or the public visit you, or do you work on clients’ sites?', 'One trip, one dropped panel. Public liability answers the claim.' ),
	array( 'property', 'property', 'Do you own or lease premises, machinery or stock worth over £50,000?', 'Fire, flood and theft hit the building first and the cash flow second.' ),
	array( 'data', 'cyber', 'Do you hold customer data, take card payments or send invoices by email?', 'Most cyber losses at small firms start with a single email.' ),
	array( 'vehicles', 'fleet', 'Do you run vans, cars or lorries for the business?', 'Business miles need business cover, and a fleet policy is often cheaper.' ),
);
?>
<!-- wp:group {"tagName":"section","align":"full","anchor":"risk-check","className":"cr-riskcheck","backgroundColor":"storm","textColor":"paper","layout":{"type":"constrained"}} -->
<section id="risk-check" class="wp-block-group alignfull cr-riskcheck has-paper-color has-storm-background-color has-text-color has-background"><!-- wp:columns {"align":"wide","className":"cr-riskcheck__grid"} -->
<div class="wp-block-columns alignwide cr-riskcheck__grid"><!-- wp:column {"width":"36%","className":"cr-riskcheck__intro"} -->
<div class="wp-block-column cr-riskcheck__intro" style="flex-basis:36%"><!-- wp:paragraph {"className":"cr-eyebrow"} -->
<p class="cr-eyebrow">Risk check · 5 cards · 60 seconds</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"className":"is-style-kinetic"} -->
<h2 class="wp-block-heading is-style-kinetic">What’s your business <em>forecast?</em></h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Flick each card right for yes or left for no, or use the buttons and arrow keys. The barometer reads your exposure, and we suggest the lines of cover worth a conversation.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"className":"cr-demo-flag"} -->
<p class="cr-demo-flag">An illustration, not advice. Nothing you choose is stored or sent.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column {"width":"64%","className":"cr-riskcheck__app"} -->
<div class="wp-block-column cr-riskcheck__app" style="flex-basis:64%"><!-- wp:html -->
<div class="cr-rc" data-cr-riskcheck data-contact="<?php echo $cr_contact; ?>" data-property="<?php echo esc_url( home_url( '/services/property-business-interruption/' ) ); ?>" data-liability="<?php echo esc_url( home_url( '/services/liability-insurance/' ) ); ?>" data-cyber="<?php echo esc_url( home_url( '/services/cyber-insurance/' ) ); ?>" data-fleet="<?php echo esc_url( home_url( '/services/fleet-motor-insurance/' ) ); ?>">
	<form class="cr-rc__deck" action="<?php echo $cr_contact; ?>" method="get">
<?php foreach ( $cr_qs as $i => $q ) : ?>
		<fieldset class="cr-rc__card" data-line="<?php echo esc_attr( $q[1] ); ?>">
			<p class="cr-rc__n"><span><?php echo sprintf( '%02d', $i + 1 ); ?></span> / 05</p>
			<legend class="cr-rc__q"><?php echo esc_html( $q[2] ); ?></legend>
			<p class="cr-rc__hint"><?php echo esc_html( $q[3] ); ?></p>
			<div class="cr-rc__answers">
				<label class="cr-rc__ans cr-rc__ans--no"><input type="radio" name="<?php echo esc_attr( $q[0] ); ?>" value="no"><span>No</span></label>
				<label class="cr-rc__ans cr-rc__ans--yes"><input type="radio" name="<?php echo esc_attr( $q[0] ); ?>" value="yes"><span>Yes</span></label>
			</div>
		</fieldset>
<?php endforeach; ?>
		<button type="submit" class="cr-rc__submit">See my forecast</button>
	</form>
	<div class="cr-rc__gauge">
		<div class="cr-rc__dial" aria-hidden="true"></div>
		<p class="cr-rc__reading"><span class="cr-rc__word">Fair</span><span class="cr-rc__num">Exposure <b>0</b> / 100</span></p>
	</div>
	<div class="cr-rc__result" hidden tabindex="-1"></div>
	<p class="cr-rc__live screen-reader-text" aria-live="polite"></p>
</div>
<!-- /wp:html --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></section>
<!-- /wp:group -->
