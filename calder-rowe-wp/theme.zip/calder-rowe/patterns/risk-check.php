<?php
/**
 * Title: Risk check (interactive demo)
 * Slug: calder-rowe/risk-check
 * Categories: calder-rowe, call-to-action
 * Keywords: risk, check, quiz, covers, interactive, calculator
 * Description: Four quick questions (sector, staff, premises, vehicles) that list the covers a business like that usually considers. Clearly labelled as a demo, not advice, with a call-back action.
 */
$cr_contact = esc_url( home_url( '/contact/' ) );
?>
<!-- wp:group {"align":"full","anchor":"risk-check","className":"cr-riskcheck","style":{"spacing":{"padding":{"top":"var:preset|spacing|70","bottom":"var:preset|spacing|70"}}},"backgroundColor":"stone","layout":{"type":"constrained"}} -->
<div id="risk-check" class="wp-block-group alignfull cr-riskcheck has-stone-background-color has-background" style="padding-top:var(--wp--preset--spacing--70);padding-bottom:var(--wp--preset--spacing--70)"><!-- wp:columns {"align":"wide","style":{"spacing":{"blockGap":{"top":"var:preset|spacing|50","left":"var:preset|spacing|60"}}}} -->
<div class="wp-block-columns alignwide"><!-- wp:column {"width":"38%","className":"cr-riskcheck__intro"} -->
<div class="wp-block-column cr-riskcheck__intro" style="flex-basis:38%"><!-- wp:paragraph {"className":"cr-eyebrow","textColor":"moss","fontSize":"small"} -->
<p class="cr-eyebrow has-moss-color has-text-color has-small-font-size">Interactive demo, 4 questions</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading">A 60-second risk check</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Answer four quick questions and see the covers a broker usually talks through with a business of your shape, including the ones UK law requires.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"className":"cr-demo-flag","fontSize":"small"} -->
<p class="cr-demo-flag has-small-font-size"><strong>Demo, not advice.</strong> A simplified illustration built for a fictional broker. Nothing you choose is stored or sent.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column {"width":"62%"} -->
<div class="wp-block-column" style="flex-basis:62%"><!-- wp:html -->
<div class="cr-rc" data-cr-riskcheck data-cta="<?php echo $cr_contact; ?>">
	<form class="cr-rc__form" action="<?php echo $cr_contact; ?>" method="get" novalidate>
		<div class="cr-rc__head">
			<p class="cr-rc__count">Question <span data-rc-current>1</span> of 4</p>
			<div class="cr-rc__progress" aria-hidden="true"><span></span></div>
		</div>
		<fieldset class="cr-rc__step" data-rc-step="sector">
			<legend class="cr-rc__q">What does the business do?</legend>
			<div class="cr-rc__options">
				<label class="cr-rc__opt"><input type="radio" name="sector" value="manufacturing"><span>Manufacturing and engineering</span></label>
				<label class="cr-rc__opt"><input type="radio" name="sector" value="construction"><span>Construction and trades</span></label>
				<label class="cr-rc__opt"><input type="radio" name="sector" value="hospitality"><span>Hospitality and leisure</span></label>
				<label class="cr-rc__opt"><input type="radio" name="sector" value="logistics"><span>Logistics and distribution</span></label>
				<label class="cr-rc__opt"><input type="radio" name="sector" value="professional"><span>Professional services</span></label>
				<label class="cr-rc__opt"><input type="radio" name="sector" value="property"><span>Property owner or landlord</span></label>
			</div>
		</fieldset>
		<fieldset class="cr-rc__step" data-rc-step="staff">
			<legend class="cr-rc__q">How many people work for you?</legend>
			<div class="cr-rc__options">
				<label class="cr-rc__opt"><input type="radio" name="staff" value="none"><span>Just me, no employees</span></label>
				<label class="cr-rc__opt"><input type="radio" name="staff" value="small"><span>1 to 9</span></label>
				<label class="cr-rc__opt"><input type="radio" name="staff" value="mid"><span>10 to 49</span></label>
				<label class="cr-rc__opt"><input type="radio" name="staff" value="large"><span>50 or more</span></label>
			</div>
		</fieldset>
		<fieldset class="cr-rc__step" data-rc-step="premises">
			<legend class="cr-rc__q">Where do you work from?</legend>
			<div class="cr-rc__options">
				<label class="cr-rc__opt"><input type="radio" name="premises" value="home"><span>Home, or on clients' sites</span></label>
				<label class="cr-rc__opt"><input type="radio" name="premises" value="rent"><span>Premises we rent or lease</span></label>
				<label class="cr-rc__opt"><input type="radio" name="premises" value="own"><span>Premises we own</span></label>
			</div>
		</fieldset>
		<fieldset class="cr-rc__step" data-rc-step="vehicles">
			<legend class="cr-rc__q">Does the business run vehicles?</legend>
			<div class="cr-rc__options">
				<label class="cr-rc__opt"><input type="radio" name="vehicles" value="none"><span>No vehicles</span></label>
				<label class="cr-rc__opt"><input type="radio" name="vehicles" value="few"><span>One or two cars or vans</span></label>
				<label class="cr-rc__opt"><input type="radio" name="vehicles" value="fleet"><span>Three or more (a fleet)</span></label>
			</div>
		</fieldset>
		<p class="cr-rc__error" role="alert"></p>
		<div class="cr-rc__nav">
			<button type="button" class="cr-rc__back" hidden>Back</button>
			<button type="submit" class="cr-rc__next">Next question</button>
		</div>
	</form>
	<div class="cr-rc__result" hidden></div>
	<p class="cr-rc__live screen-reader-text" aria-live="polite"></p>
</div>
<!-- /wp:html --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group -->
