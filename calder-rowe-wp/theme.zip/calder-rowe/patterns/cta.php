<?php
/**
 * Title: Renewal call to action
 * Slug: calder-rowe/cta
 * Categories: calder-rowe, call-to-action
 * Keywords: cta, renewal, quote, call
 * Description: Ink band with storm isobars, a kinetic headline and a large magnetic button.
 */
?>
<!-- wp:group {"tagName":"section","align":"full","className":"is-style-contour cr-cta","backgroundColor":"ink","textColor":"paper","layout":{"type":"constrained"}} -->
<section class="wp-block-group alignfull is-style-contour cr-cta has-paper-color has-ink-background-color has-text-color has-background"><!-- wp:columns {"verticalAlignment":"center","align":"wide"} -->
<div class="wp-block-columns alignwide are-vertically-aligned-center"><!-- wp:column {"verticalAlignment":"center","width":"62%"} -->
<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:62%"><!-- wp:paragraph {"className":"cr-eyebrow"} -->
<p class="cr-eyebrow">Renewal review</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"className":"is-style-kinetic","fontSize":"hero"} -->
<h2 class="wp-block-heading is-style-kinetic has-hero-font-size">Renewal in the next <em>90 days?</em></h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"className":"cr-cta__lead"} -->
<p class="cr-cta__lead">Send us your current schedule. Within a week we will tell you what is missing, what looks overpriced and what is fine as it is, before you commit to another year.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column {"verticalAlignment":"center","width":"38%","className":"cr-cta__action"} -->
<div class="wp-block-column is-vertically-aligned-center cr-cta__action" style="flex-basis:38%"><!-- wp:buttons {"layout":{"type":"flex","orientation":"vertical","justifyContent":"center"}} -->
<div class="wp-block-buttons"><!-- wp:button {"className":"cr-magnetic cr-orb"} -->
<div class="wp-block-button cr-magnetic cr-orb"><a class="wp-block-button__link wp-element-button" href="<?php echo esc_url( home_url( '/contact/' ) ); ?>">Book a review</a></div>
<!-- /wp:button -->

<!-- wp:button {"className":"is-style-arrow"} -->
<div class="wp-block-button is-style-arrow"><a class="wp-block-button__link wp-element-button" href="tel:+441134960412">Or call 0113 496 0412</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></section>
<!-- /wp:group -->
