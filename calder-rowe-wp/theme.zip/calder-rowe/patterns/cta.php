<?php
/**
 * Title: Renewal review call to action
 * Slug: calder-rowe/cta
 * Categories: calder-rowe, call-to-action
 * Keywords: cta, call to action, renewal, quote
 * Description: Marigold band inviting a renewal review, with quote and phone actions.
 */
?>
<!-- wp:group {"align":"full","className":"cr-cta","style":{"spacing":{"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|60"}},"elements":{"link":{"color":{"text":"var:preset|color|ink"}}}},"backgroundColor":"marigold","textColor":"ink","layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull cr-cta has-ink-color has-marigold-background-color has-text-color has-background has-link-color" style="padding-top:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--60)"><!-- wp:columns {"verticalAlignment":"center","align":"wide","style":{"spacing":{"blockGap":{"top":"var:preset|spacing|40","left":"var:preset|spacing|60"}}}} -->
<div class="wp-block-columns alignwide are-vertically-aligned-center"><!-- wp:column {"verticalAlignment":"center","width":"62%"} -->
<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:62%"><!-- wp:heading -->
<h2 class="wp-block-heading">Renewal in the next three months?</h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"fontSize":"medium"} -->
<p class="has-medium-font-size">Send us your current schedule. We will tell you what is missing, what looks overpriced and what is fine as it is, before you commit to another year.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column {"verticalAlignment":"center","width":"38%"} -->
<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:38%"><!-- wp:buttons {"layout":{"type":"flex","justifyContent":"right"}} -->
<div class="wp-block-buttons"><!-- wp:button {"backgroundColor":"canal","textColor":"paper"} -->
<div class="wp-block-button"><a class="wp-block-button__link has-paper-color has-canal-background-color has-text-color has-background wp-element-button" href="<?php echo esc_url( home_url( '/contact/' ) ); ?>">Book a renewal review</a></div>
<!-- /wp:button -->

<!-- wp:button {"textColor":"ink","className":"is-style-outline"} -->
<div class="wp-block-button is-style-outline"><a class="wp-block-button__link has-ink-color has-text-color wp-element-button" href="tel:+441134960412">Call a broker</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group -->
