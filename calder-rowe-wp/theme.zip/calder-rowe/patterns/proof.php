<?php
/**
 * Title: Promise quote and service targets
 * Slug: calder-rowe/proof
 * Categories: calder-rowe, text
 * Keywords: quote, pullquote, stats, targets, numbers
 * Description: A large pull quote that lights up word by word as you scroll, above four service targets that count up into view.
 */
?>
<!-- wp:group {"tagName":"section","align":"full","className":"cr-proof","backgroundColor":"paper","textColor":"ink","layout":{"type":"constrained"}} -->
<section class="wp-block-group alignfull cr-proof has-ink-color has-paper-background-color has-text-color has-background"><!-- wp:pullquote {"align":"wide","className":"is-style-scrub"} -->
<figure class="wp-block-pullquote alignwide is-style-scrub"><blockquote><p>The worst day of your business year is the day we earn our fee. Everything before it is preparation, so that when the call comes, nobody has to panic.</p><cite>Hannah Rowe, co-founder</cite></blockquote></figure>
<!-- /wp:pullquote -->

<!-- wp:group {"align":"wide","className":"cr-targets","layout":{"type":"grid","columnCount":4}} -->
<div class="wp-block-group alignwide cr-targets"><!-- wp:group {"className":"cr-target","layout":{"type":"default"}} -->
<div class="wp-block-group cr-target"><!-- wp:paragraph {"className":"cr-target__num"} -->
<p class="cr-target__num">3</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"className":"cr-target__label"} -->
<p class="cr-target__label">Rings. Our pickup target on the 24-hour claims line.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group {"className":"cr-target","layout":{"type":"default"}} -->
<div class="wp-block-group cr-target"><!-- wp:paragraph {"className":"cr-target__num"} -->
<p class="cr-target__num">34</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"className":"cr-target__label"} -->
<p class="cr-target__label">Insurers on a panel we re-test every year.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group {"className":"cr-target","layout":{"type":"default"}} -->
<div class="wp-block-group cr-target"><!-- wp:paragraph {"className":"cr-target__num"} -->
<p class="cr-target__num">24h</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"className":"cr-target__label"} -->
<p class="cr-target__label">First response to any new enquiry on a working day.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group {"className":"cr-target","layout":{"type":"default"}} -->
<div class="wp-block-group cr-target"><!-- wp:paragraph {"className":"cr-target__num"} -->
<p class="cr-target__num">6 wks</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"className":"cr-target__label"} -->
<p class="cr-target__label">Before expiry, we start your renewal review and test the market.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></section>
<!-- /wp:group -->
