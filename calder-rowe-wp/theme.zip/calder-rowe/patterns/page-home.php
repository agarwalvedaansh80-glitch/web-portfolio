<?php
/**
 * Title: Home page layout
 * Slug: calder-rowe/page-home
 * Categories: calder-rowe-pages
 * Keywords: home, landing, front page
 * Post Types: page, wp_template
 * Description: The full home page: animated hero with call-back form, trust strip, services, risk check, service targets, sectors, how a claim works, insights, FAQ and renewal call to action.
 */
?>
<!-- wp:pattern {"slug":"calder-rowe/hero"} /-->

<!-- wp:pattern {"slug":"calder-rowe/trust-strip"} /-->

<!-- wp:pattern {"slug":"calder-rowe/services-grid"} /-->

<!-- wp:pattern {"slug":"calder-rowe/risk-check"} /-->

<!-- wp:pattern {"slug":"calder-rowe/stats-band"} /-->

<!-- wp:pattern {"slug":"calder-rowe/sectors"} /-->

<!-- wp:pattern {"slug":"calder-rowe/claim-flow"} /-->

<!-- wp:pattern {"slug":"calder-rowe/news-grid"} /-->

<!-- wp:pattern {"slug":"calder-rowe/faq"} /-->

<!-- wp:pattern {"slug":"calder-rowe/cta"} /-->
