<?php
/**
 * Title: Home page layout
 * Slug: calder-rowe/page-home
 * Categories: calder-rowe-pages
 * Keywords: home, landing, front page
 * Post Types: page, wp_template
 * Description: The full home page: contour hero with call-back form, kinetic marquee, lines of cover, risk check, the pinned claims story, promise and targets, insights and a renewal call to action.
 */
?>
<!-- wp:pattern {"slug":"calder-rowe/hero"} /-->

<!-- wp:pattern {"slug":"calder-rowe/marquee"} /-->

<!-- wp:pattern {"slug":"calder-rowe/lines-index"} /-->

<!-- wp:pattern {"slug":"calder-rowe/risk-check"} /-->

<!-- wp:pattern {"slug":"calder-rowe/claims-story"} /-->

<!-- wp:pattern {"slug":"calder-rowe/proof"} /-->

<!-- wp:pattern {"slug":"calder-rowe/news-grid"} /-->

<!-- wp:pattern {"slug":"calder-rowe/cta"} /-->
