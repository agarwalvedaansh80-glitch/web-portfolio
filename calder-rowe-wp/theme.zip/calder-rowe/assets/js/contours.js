/*
 * Calder & Rowe contour signature. Vanilla 2D canvas, no dependencies.
 *
 * A smooth height field (a few slow-moving hills plus gentle ripples) is
 * sampled on a coarse grid and traced with marching squares, so the lines read
 * as a real contour map. The pointer adds a soft hill, which makes nearby lines
 * bend towards it. Runs only while the section is on screen and the tab is
 * visible; with reduced motion the static SVG background stays instead.
 */
( function () {
	'use strict';

	var hosts = document.querySelectorAll( '.cr-contours' );
	if ( ! hosts.length || ! window.HTMLCanvasElement ) {
		return;
	}
	if ( window.matchMedia && window.matchMedia( '(prefers-reduced-motion: reduce)' ).matches ) {
		return;
	}

	function Field( host ) {
		var canvas = document.createElement( 'canvas' );
		canvas.className = 'cr-contours__canvas';
		canvas.setAttribute( 'aria-hidden', 'true' );
		host.appendChild( canvas );
		var ctx = canvas.getContext( '2d' );
		if ( ! ctx ) {
			return;
		}

		var dpr = 1, w = 0, h = 0, cols = 0, rows = 0, cell = 14, grid = null;
		var running = false, visible = false, raf = 0, last = 0, t = Math.random() * 100;
		var pointer = { x: 0.72, y: 0.4, tx: 0.72, ty: 0.4, s: 0, ts: 0 };
		var isHero = host.classList.contains( 'cr-hero' );
		// Hill centres in field units (height = 1). They drift slowly on Lissajous paths.
		var hills = [
			{ x: 1.25, y: 0.35, r: 0.42, a: 1.0, fx: 0.031, fy: 0.023 },
			{ x: 0.95, y: 0.85, r: 0.36, a: 0.8, fx: 0.019, fy: 0.037 },
			{ x: 1.75, y: 0.7, r: 0.5, a: 0.9, fx: 0.027, fy: 0.017 },
			{ x: 0.35, y: 0.2, r: 0.3, a: 0.55, fx: 0.022, fy: 0.029 }
		];
		var levels = [];
		for ( var l = 0.12; l < 1.6; l += 0.085 ) {
			levels.push( l );
		}

		function resize() {
			var r = host.getBoundingClientRect();
			dpr = Math.min( window.devicePixelRatio || 1, 2 );
			w = Math.max( 1, Math.round( r.width ) );
			h = Math.max( 1, Math.round( r.height ) );
			canvas.width = Math.round( w * dpr );
			canvas.height = Math.round( h * dpr );
			cell = w < 700 ? 12 : 14;
			cols = Math.ceil( w / cell ) + 1;
			rows = Math.ceil( h / cell ) + 1;
			grid = new Float32Array( cols * rows );
			draw();
		}

		function sample() {
			var aspect = w / h;
			var i, x, y, fx, fy, v, k, hl, dx, dy;
			var hs = hills.map( function ( q, n ) {
				return {
					x: q.x * ( aspect / 2 ) + Math.sin( t * q.fx * 6.283 + n ) * 0.18,
					y: q.y + Math.cos( t * q.fy * 6.283 + n * 2 ) * 0.14,
					r2: q.r * q.r,
					a: q.a
				};
			} );
			var px = pointer.x * aspect, py = pointer.y, ps = pointer.s * 0.55;
			for ( y = 0; y < rows; y++ ) {
				fy = ( y * cell ) / h;
				for ( x = 0; x < cols; x++ ) {
					fx = ( x * cell ) / h;
					v = 0.18 * Math.sin( fx * 2.1 + t * 0.05 ) * Math.cos( fy * 2.7 - t * 0.04 ) + 0.1 * Math.sin( ( fx + fy ) * 4.3 - t * 0.07 );
					for ( k = 0; k < hs.length; k++ ) {
						hl = hs[ k ];
						dx = fx - hl.x;
						dy = fy - hl.y;
						v += hl.a * Math.exp( -( dx * dx + dy * dy ) / hl.r2 );
					}
					if ( ps > 0.001 ) {
						dx = fx - px;
						dy = fy - py;
						v += ps * Math.exp( -( dx * dx + dy * dy ) / 0.045 );
					}
					grid[ y * cols + x ] = v;
				}
			}
		}

		// Marching squares for one level into the current path.
		function trace( level ) {
			var x, y, i, a, b, c, d, code, cx, cy, s = cell;
			for ( y = 0; y < rows - 1; y++ ) {
				for ( x = 0; x < cols - 1; x++ ) {
					i = y * cols + x;
					a = grid[ i ];
					b = grid[ i + 1 ];
					c = grid[ i + cols + 1 ];
					d = grid[ i + cols ];
					code = ( a > level ? 8 : 0 ) | ( b > level ? 4 : 0 ) | ( c > level ? 2 : 0 ) | ( d > level ? 1 : 0 );
					if ( code === 0 || code === 15 ) {
						continue;
					}
					cx = x * s;
					cy = y * s;
					// Edge crossing points, linearly interpolated.
					var top = cx + s * ( ( level - a ) / ( b - a ) );
					var right = cy + s * ( ( level - b ) / ( c - b ) );
					var bottom = cx + s * ( ( level - d ) / ( c - d ) );
					var left = cy + s * ( ( level - a ) / ( d - a ) );
					switch ( code ) {
						case 1: case 14: seg( cx, left, bottom, cy + s ); break;
						case 2: case 13: seg( bottom, cy + s, cx + s, right ); break;
						case 3: case 12: seg( cx, left, cx + s, right ); break;
						case 4: case 11: seg( top, cy, cx + s, right ); break;
						case 5: seg( cx, left, top, cy ); seg( bottom, cy + s, cx + s, right ); break;
						case 6: case 9: seg( top, cy, bottom, cy + s ); break;
						case 7: case 8: seg( cx, left, top, cy ); break;
						case 10: seg( top, cy, cx + s, right ); seg( cx, left, bottom, cy + s ); break;
					}
				}
			}
		}
		function seg( x1, y1, x2, y2 ) {
			ctx.moveTo( x1, y1 );
			ctx.lineTo( x2, y2 );
		}

		function draw() {
			if ( ! grid ) {
				return;
			}
			sample();
			ctx.setTransform( dpr, 0, 0, dpr, 0, 0 );
			ctx.clearRect( 0, 0, w, h );
			ctx.lineCap = 'round';
			ctx.lineJoin = 'round';
			for ( var n = 0; n < levels.length; n++ ) {
				var index = n % 4 === 0;
				ctx.beginPath();
				trace( levels[ n ] );
				if ( n === 9 ) {
					ctx.strokeStyle = 'rgba(235,170,60,0.55)';
					ctx.lineWidth = 1.4;
				} else {
					ctx.strokeStyle = index ? 'rgba(185,204,196,0.34)' : 'rgba(185,204,196,0.17)';
					ctx.lineWidth = index ? 1.3 : 1;
				}
				ctx.stroke();
			}
		}

		function frame( now ) {
			raf = 0;
			if ( ! running ) {
				return;
			}
			var dt = Math.min( 64, now - ( last || now ) );
			// About 30 fps is plenty for slow drift and halves the work.
			if ( now - last >= 32 ) {
				last = now;
				t += dt * 0.0011;
				pointer.x += ( pointer.tx - pointer.x ) * 0.08;
				pointer.y += ( pointer.ty - pointer.y ) * 0.08;
				pointer.s += ( pointer.ts - pointer.s ) * 0.06;
				draw();
			}
			raf = requestAnimationFrame( frame );
		}

		function start() {
			if ( running || ! visible || document.hidden ) {
				return;
			}
			running = true;
			last = 0;
			raf = requestAnimationFrame( frame );
		}
		function stop() {
			running = false;
			if ( raf ) {
				cancelAnimationFrame( raf );
				raf = 0;
			}
		}

		host.addEventListener( 'pointermove', function ( e ) {
			if ( e.pointerType === 'touch' ) {
				return;
			}
			var r = host.getBoundingClientRect();
			pointer.tx = ( e.clientX - r.left ) / r.height;
			pointer.tx = pointer.tx / ( r.width / r.height );
			pointer.ty = ( e.clientY - r.top ) / r.height;
			pointer.ts = 1;
		} );
		host.addEventListener( 'pointerleave', function () {
			pointer.ts = 0;
		} );

		new IntersectionObserver( function ( entries ) {
			visible = entries[ 0 ].isIntersecting;
			if ( visible ) {
				start();
			} else {
				stop();
			}
		} ).observe( host );
		document.addEventListener( 'visibilitychange', function () {
			if ( document.hidden ) {
				stop();
			} else {
				start();
			}
		} );
		var resizeTimer;
		new ResizeObserver( function () {
			clearTimeout( resizeTimer );
			resizeTimer = setTimeout( resize, 120 );
		} ).observe( host );

		resize();
		host.classList.add( 'has-live-contours' );
		if ( isHero ) {
			host.classList.add( 'is-hero-contours' );
		}
	}

	Array.prototype.forEach.call( hosts, function ( host ) {
		new Field( host );
	} );
} )();
