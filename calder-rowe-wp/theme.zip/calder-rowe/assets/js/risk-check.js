/*
 * Calder & Rowe risk check (demo). Vanilla JS, no dependencies.
 * The markup is a plain form that works without this file (it submits to the
 * contact page). This script turns it into a four-step check and lists the
 * covers a business of that shape usually considers. It is an illustration,
 * not advice, and nothing is stored or sent.
 */
( function () {
	'use strict';

	var SECTORS = {
		manufacturing: 'manufacturing',
		construction: 'construction',
		hospitality: 'hospitality',
		logistics: 'logistics',
		professional: 'professional services',
		property: 'property'
	};
	var LABELS = {
		staff: { none: 'no employees', small: '1 to 9 staff', mid: '10 to 49 staff', large: '50+ staff' },
		premises: { home: 'no business premises', rent: 'rented premises', own: 'owned premises' },
		vehicles: { none: 'no vehicles', few: '1 or 2 vehicles', fleet: 'a fleet' }
	};
	var LAW = 'Legal requirement';

	// Each rule: [title, why, tag, test(answers)]. Order = order shown.
	var RULES = [
		[ 'Employers’ liability', 'Required by law for most UK employers, with a limit of at least £5 million. It pays claims from staff injured or made ill through work, including part-time and temporary staff.', LAW,
			function ( a ) { return a.staff !== 'none'; } ],
		[ 'Motor fleet insurance', 'Every vehicle used on public roads needs at least third-party cover by law. With three or more, one fleet policy is usually simpler to run than separate policies.', LAW,
			function ( a ) { return a.vehicles === 'fleet'; } ],
		[ 'Commercial vehicle insurance', 'Vehicles used on public roads need at least third-party cover by law, and the policy must include business use.', LAW,
			function ( a ) { return a.vehicles === 'few'; } ],
		[ 'Public liability', 'Pays compensation and legal costs if a customer or member of the public is injured, or their property damaged, because of your work.', 'Often required by contracts',
			function ( a ) { return a.sector === 'construction'; } ],
		[ 'Public and products liability', 'Covers injury or damage to other people caused by your work, premises or the products you make, supply or repair.', 'Usually considered',
			function ( a ) { return a.sector === 'manufacturing' || a.sector === 'logistics'; } ],
		[ 'Public liability', 'Pays compensation and legal costs if a customer or member of the public is injured, or their property damaged, because of your business.', 'Usually considered',
			function ( a ) { return a.sector === 'hospitality' || a.sector === 'professional'; } ],
		[ 'Property owners’ liability', 'Covers your liability as owner or landlord if a tenant, visitor or passer-by is hurt because of the building’s condition.', 'Usually considered',
			function ( a ) { return a.sector === 'property'; } ],
		[ 'Professional indemnity', 'Covers claims that your advice, design or service caused a client a financial loss. Many clients and professional bodies ask for it.', 'Often required by clients',
			function ( a ) { return a.sector === 'professional'; } ],
		[ 'Professional indemnity', 'Worth checking if you design, specify or sign off work, not only build it. Main contractors often ask for it.', 'Worth asking about',
			function ( a ) { return a.sector === 'construction'; } ],
		[ 'Contract works and plant', 'Covers the work in progress, materials on site and the plant and tools you own or hire in.', 'Usually considered',
			function ( a ) { return a.sector === 'construction'; } ],
		[ 'Goods in transit', 'Covers stock and goods while they are being moved, by your own vehicles or by a carrier.', 'Usually considered',
			function ( a ) { return a.sector === 'logistics' || a.sector === 'manufacturing'; } ],
		[ 'Carriers’ liability', 'Covers the liability you accept for customers’ goods under your terms of carriage.', 'Usually considered',
			function ( a ) { return a.sector === 'logistics'; } ],
		[ 'Engineering inspection and breakdown', 'Lifting equipment and pressure systems need regular thorough examinations by law. Insurers often provide the inspections alongside breakdown cover.', 'Linked to legal inspections',
			function ( a ) { return a.sector === 'manufacturing'; } ],
		[ 'Buildings at full rebuild cost', 'Covers the structure you own against fire, flood, storm and damage. Lenders usually insist on it, and it should be set at rebuild cost, not market value.', 'Often required by lenders',
			function ( a ) { return a.premises === 'own' || a.sector === 'property'; } ],
		[ 'Contents, stock and equipment', 'Covers machinery, fit-out, computers and stock at your premises. Leases often make tenants responsible for some of these.', 'Usually considered',
			function ( a ) { return a.premises === 'rent' || ( a.premises === 'own' && a.sector !== 'property' ); } ],
		[ 'Business equipment', 'Covers laptops, tools and portable kit. Home insurance often excludes items used for business.', 'Usually considered',
			function ( a ) { return a.premises === 'home' && a.sector !== 'property'; } ],
		[ 'Stock deterioration and licence cover', 'Pays for food or drink spoiled by a freezer or power failure, and protects the value of a premises licence.', 'Usually considered',
			function ( a ) { return a.sector === 'hospitality'; } ],
		[ 'Loss of rent', 'Replaces rent you lose while a damaged building cannot be let.', 'Usually considered',
			function ( a ) { return a.sector === 'property'; } ],
		[ 'Business interruption', 'Pays the profit you lose and the extra costs of trading while the business recovers from damage.', 'Usually considered',
			function ( a ) { return a.sector !== 'property' && ( a.premises !== 'home' || a.sector === 'manufacturing' || a.sector === 'hospitality' ); } ],
		[ 'Cyber', 'Pays specialists to contain an attack and restore systems, and covers lost income. Most incidents at smaller firms start with an email.', 'Usually considered',
			function () { return true; } ],
		[ 'Management liability', 'Protects directors and the company against claims about how the business is run, including employment disputes.', 'Worth asking about',
			function ( a ) { return a.staff === 'mid' || a.staff === 'large'; } ],
		[ 'Employers’ liability, when you hire', 'Not usually needed with no employees. It becomes a legal requirement as soon as you take anyone on, even part-time or temporary.', 'Keep in mind',
			function ( a ) { return a.staff === 'none'; } ]
	];

	var reduce = window.matchMedia && window.matchMedia( '(prefers-reduced-motion: reduce)' ).matches;

	function esc( s ) {
		return String( s ).replace( /[&<>"]/g, function ( c ) {
			return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[ c ];
		} );
	}

	function init( root ) {
		if ( root.dataset.rcReady ) {
			return;
		}
		root.dataset.rcReady = '1';
		root.classList.add( 'is-enhanced' );

		var form = root.querySelector( '.cr-rc__form' );
		var steps = Array.prototype.slice.call( root.querySelectorAll( '.cr-rc__step' ) );
		var back = root.querySelector( '.cr-rc__back' );
		var next = root.querySelector( '.cr-rc__next' );
		var error = root.querySelector( '.cr-rc__error' );
		var current = root.querySelector( '[data-rc-current]' );
		var bar = root.querySelector( '.cr-rc__progress span' );
		var result = root.querySelector( '.cr-rc__result' );
		var live = root.querySelector( '.cr-rc__live' );
		var index = 0;

		function value( name ) {
			var el = form.querySelector( 'input[name="' + name + '"]:checked' );
			return el ? el.value : '';
		}

		function show( i, focus ) {
			index = i;
			steps.forEach( function ( step, n ) {
				step.classList.toggle( 'is-current', n === i );
				step.hidden = n !== i;
			} );
			back.hidden = i === 0;
			next.textContent = i === steps.length - 1 ? 'See my covers' : 'Next question';
			current.textContent = String( i + 1 );
			bar.style.transform = 'scaleX(' + ( ( i + 1 ) / steps.length ) + ')';
			error.textContent = '';
			if ( focus ) {
				var target = steps[ i ].querySelector( 'input:checked' ) || steps[ i ].querySelector( 'input' );
				target.focus( { preventScroll: true } );
			}
		}

		function render() {
			var a = { sector: value( 'sector' ), staff: value( 'staff' ), premises: value( 'premises' ), vehicles: value( 'vehicles' ) };
			var seen = {};
			var items = RULES.filter( function ( r ) {
				if ( ! r[ 3 ]( a ) || seen[ r[ 0 ] ] ) {
					return false;
				}
				seen[ r[ 0 ] ] = true;
				return true;
			} );
			var legal = items.filter( function ( r ) { return r[ 2 ] === LAW; } ).length;
			var counted = items.filter( function ( r ) { return r[ 2 ] !== 'Keep in mind'; } ).length;
			var summary = [ LABELS.staff[ a.staff ], LABELS.premises[ a.premises ], LABELS.vehicles[ a.vehicles ] ].join( ', ' );
			var html = '<div class="cr-rc__res-head">' +
				'<p class="cr-rc__res-kicker">Your result</p>' +
				'<h3 class="cr-rc__res-title" tabindex="-1"><span class="cr-rc__res-num">' + counted + '</span> covers a ' + esc( SECTORS[ a.sector ] ) + ' business like yours usually considers</h3>' +
				'<p class="cr-rc__res-meta">Based on ' + esc( summary ) + '.' + ( legal ? ' <strong>' + legal + ( legal === 1 ? ' is' : ' are' ) + ' required by UK law.</strong>' : '' ) + '</p></div>' +
				'<ol class="cr-rc__list">' + items.map( function ( r, i ) {
					var law = r[ 2 ] === LAW;
					return '<li class="cr-rc__item' + ( law ? ' is-law' : '' ) + '" style="--i:' + i + '">' +
						'<span class="cr-rc__tag">' + esc( r[ 2 ] ) + '</span>' +
						'<strong class="cr-rc__item-title">' + esc( r[ 0 ] ) + '</strong>' +
						'<span class="cr-rc__item-text">' + esc( r[ 1 ] ) + '</span></li>';
				} ).join( '' ) + '</ol>' +
				'<p class="cr-rc__note"><strong>This is a demo, not advice.</strong> It is a simplified illustration for a fictional broker. Real cover depends on your activities, contracts and claims history, so speak to a regulated broker before you buy.</p>' +
				'<div class="cr-rc__actions">' +
				'<a class="cr-rc__cta" href="' + esc( root.dataset.cta || '#' ) + '">Request a call-back about these covers</a>' +
				'<button type="button" class="cr-rc__restart">Start again</button></div>';

			result.innerHTML = html;
			form.hidden = true;
			result.hidden = false;
			root.classList.add( 'has-result' );
			// Two frames so the list starts from its hidden state and animates in.
			requestAnimationFrame( function () {
				requestAnimationFrame( function () {
					result.classList.add( 'is-in' );
				} );
			} );
			live.textContent = counted + ' covers listed.' + ( legal ? ' ' + legal + ' required by UK law.' : '' ) + ' This is a demo, not advice.';
			result.querySelector( '.cr-rc__res-title' ).focus( { preventScroll: true } );
			var top = root.getBoundingClientRect().top;
			if ( top < 0 || top > window.innerHeight * 0.5 ) {
				scrollToEl( root );
			}

			result.querySelector( '.cr-rc__restart' ).addEventListener( 'click', function () {
				result.classList.remove( 'is-in' );
				result.hidden = true;
				result.innerHTML = '';
				form.hidden = false;
				root.classList.remove( 'has-result' );
				form.reset();
				live.textContent = '';
				show( 0, true );
			} );

			// If the page has the hero call-back form, take the visitor there.
			var cta = result.querySelector( '.cr-rc__cta' );
			var callback = document.getElementById( 'cb-name' );
			if ( callback ) {
				cta.addEventListener( 'click', function ( e ) {
					e.preventDefault();
					var topic = document.getElementById( 'cb-topic' );
					if ( topic ) {
						topic.selectedIndex = 0;
					}
					scrollToEl( callback.closest( '.cr-callback' ) || callback );
					setTimeout( function () { callback.focus( { preventScroll: true } ); }, reduce ? 0 : 700 );
				} );
			}
		}

		form.addEventListener( 'submit', function ( e ) {
			e.preventDefault();
			var name = steps[ index ].getAttribute( 'data-rc-step' );
			if ( ! value( name ) ) {
				error.textContent = 'Choose one option to continue.';
				steps[ index ].querySelector( 'input' ).focus();
				return;
			}
			if ( index < steps.length - 1 ) {
				show( index + 1, true );
			} else {
				render();
			}
		} );
		back.addEventListener( 'click', function () {
			show( Math.max( 0, index - 1 ), true );
		} );
		form.addEventListener( 'change', function () {
			error.textContent = '';
		} );

		preset( root );
		show( 0, false );
	}

	function scrollToEl( el ) {
		var y = el.getBoundingClientRect().top + window.pageYOffset - 24;
		if ( window.crLenis ) {
			window.crLenis.scrollTo( y, { duration: reduce ? 0 : 1.1 } );
		} else {
			window.scrollTo( { top: y, behavior: reduce ? 'auto' : 'smooth' } );
		}
	}

	function preset( root, sector ) {
		sector = sector || new URLSearchParams( window.location.search ).get( 'sector' );
		if ( sector && SECTORS[ sector ] ) {
			var input = root.querySelector( 'input[name="sector"][value="' + sector + '"]' );
			if ( input ) {
				input.checked = true;
			}
		}
	}

	var roots = document.querySelectorAll( '[data-cr-riskcheck]' );
	if ( ! roots.length ) {
		return;
	}

	// Sector tiles link to "?sector=x#risk-check". On the same page, preselect and scroll instead of reloading.
	document.addEventListener( 'click', function ( e ) {
		var link = e.target.closest && e.target.closest( 'a[href*="#risk-check"]' );
		if ( ! link ) {
			return;
		}
		var url = new URL( link.href, window.location.href );
		if ( url.pathname !== window.location.pathname ) {
			return;
		}
		e.preventDefault();
		var root = roots[ 0 ];
		init( root );
		preset( root, url.searchParams.get( 'sector' ) );
		scrollToEl( root.closest( '.cr-riskcheck' ) || root );
		var first = root.querySelector( '.cr-rc__step:not([hidden]) input:checked' ) || root.querySelector( '.cr-rc__step:not([hidden]) input' );
		if ( first ) {
			setTimeout( function () { first.focus( { preventScroll: true } ); }, reduce ? 0 : 900 );
		}
	} );

	// Lazy initialisation: bind the widget only when it comes near the viewport.
	if ( 'IntersectionObserver' in window ) {
		var io = new IntersectionObserver( function ( entries ) {
			entries.forEach( function ( entry ) {
				if ( entry.isIntersecting ) {
					io.unobserve( entry.target );
					init( entry.target );
				}
			} );
		}, { rootMargin: '600px 0px' } );
		Array.prototype.forEach.call( roots, function ( r ) { io.observe( r ); } );
	} else {
		Array.prototype.forEach.call( roots, init );
	}
} )();
