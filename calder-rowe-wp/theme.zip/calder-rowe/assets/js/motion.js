/*
 * Calder & Rowe motion layer: Lenis smooth scrolling, the hero load sequence,
 * one reveal per section heading, the pinned "How a claim works" scene, the
 * counting service figures and magnetic primary buttons.
 *
 * Uses GSAP + ScrollTrigger + Lenis (enqueued only on pages that need them).
 * With prefers-reduced-motion everything is shown in its final state, the
 * claim steps are a plain list and native scrolling is untouched.
 */
( function () {
	'use strict';

	var doc = document.documentElement;
	var gsap = window.gsap;
	var ST = window.ScrollTrigger;
	var reduce = window.matchMedia( '(prefers-reduced-motion: reduce)' ).matches;
	var finePointer = window.matchMedia( '(hover: hover) and (pointer: fine)' ).matches;

	if ( ! gsap || ! ST || reduce ) {
		doc.classList.remove( 'cr-intro' );
		document.querySelectorAll( '.cr-claimflow' ).forEach( function ( el ) {
			el.style.setProperty( '--p', '1' );
			el.querySelectorAll( '.cr-cstep' ).forEach( function ( s ) { s.classList.add( 'is-active' ); } );
		} );
		return;
	}
	gsap.registerPlugin( ST );

	/* ---------- Smooth scrolling ---------- */

	if ( window.Lenis ) {
		var lenis = new window.Lenis( { duration: 1.1, anchors: true, autoRaf: false } );
		window.crLenis = lenis;
		lenis.on( 'scroll', ST.update );
		gsap.ticker.add( function ( time ) {
			lenis.raf( time * 1000 );
		} );
		gsap.ticker.lagSmoothing( 0 );
		// Hand control back to the browser while the mobile menu overlay is open.
		new MutationObserver( function () {
			if ( doc.classList.contains( 'has-modal-open' ) ) {
				lenis.stop();
			} else {
				lenis.start();
			}
		} ).observe( doc, { attributes: true, attributeFilter: [ 'class' ] } );
	}

	/* ---------- Hero load sequence ---------- */

	// Wrap each rendered line of a heading so the lines can rise in one by one.
	// The original markup is restored afterwards so resizing re-flows normally.
	function splitLines( el ) {
		var original = el.innerHTML;
		var words = el.textContent.trim().split( /\s+/ );
		el.innerHTML = words.map( function ( w ) { return '<span class="cr-w">' + w + '</span>'; } ).join( ' ' );
		var lines = [];
		var lastTop = null;
		el.querySelectorAll( '.cr-w' ).forEach( function ( w ) {
			var top = w.offsetTop;
			if ( lastTop === null || Math.abs( top - lastTop ) > 4 ) {
				lines.push( [] );
				lastTop = top;
			}
			lines[ lines.length - 1 ].push( w.textContent );
		} );
		el.setAttribute( 'aria-label', words.join( ' ' ) );
		el.innerHTML = lines.map( function ( l ) {
			return '<span class="cr-line" aria-hidden="true"><span class="cr-line__in">' + l.join( ' ' ) + '</span></span>';
		} ).join( ' ' );
		return function () {
			el.innerHTML = original;
			el.removeAttribute( 'aria-label' );
		};
	}

	var hero = document.querySelector( '.cr-hero' );
	if ( hero ) {
		var title = hero.querySelector( 'h1' );
		var restore = title ? splitLines( title ) : null;
		var tl = gsap.timeline( {
			defaults: { ease: 'power3.out' },
			onComplete: function () {
				if ( restore ) {
					restore();
				}
			}
		} );
		var copy = hero.querySelectorAll( '.cr-eyebrow, .cr-hero__lead, .cr-hero .wp-block-buttons, .cr-hero__note' );
		var card = hero.querySelector( '.cr-callback' );
		gsap.set( copy, { autoAlpha: 0, y: 18 } );
		if ( card ) {
			gsap.set( card, { autoAlpha: 0, x: 60 } );
		}
		if ( title ) {
			gsap.set( title.querySelectorAll( '.cr-line__in' ), { yPercent: 110 } );
		}
		doc.classList.remove( 'cr-intro' );
		tl.to( hero.querySelector( '.cr-eyebrow' ), { autoAlpha: 1, y: 0, duration: 0.6 }, 0.1 );
		if ( title ) {
			tl.to( title.querySelectorAll( '.cr-line__in' ), { yPercent: 0, duration: 1, stagger: 0.12 }, 0.2 );
		}
		tl.to( hero.querySelectorAll( '.cr-hero__lead, .cr-hero .wp-block-buttons, .cr-hero__note' ), { autoAlpha: 1, y: 0, duration: 0.8, stagger: 0.1 }, 0.65 );
		if ( card ) {
			tl.to( card, { autoAlpha: 1, x: 0, duration: 1.1, ease: 'expo.out', clearProps: 'transform' }, 0.55 );
		}
		var canvas = hero.querySelector( '.cr-contours__canvas' );
		if ( canvas ) {
			tl.fromTo( canvas, { opacity: 0 }, { opacity: 1, duration: 1.6, ease: 'power1.out' }, 0 );
		}
	} else {
		doc.classList.remove( 'cr-intro' );
	}

	/* ---------- One restrained reveal per section heading ---------- */

	gsap.utils.toArray( '.cr-main > .alignfull:not(.cr-hero) h2:first-of-type, .cr-service-body h2' ).forEach( function ( h ) {
		// Only the first h2 of each section, to keep motion restrained.
		var section = h.closest( '.alignfull' );
		if ( section && section.dataset.crRevealed && ! h.closest( '.cr-service-body' ) ) {
			return;
		}
		if ( section ) {
			section.dataset.crRevealed = '1';
		}
		gsap.from( h, {
			y: 28,
			autoAlpha: 0,
			duration: 0.9,
			ease: 'power3.out',
			scrollTrigger: { trigger: h, start: 'top 88%', once: true }
		} );
	} );

	/* ---------- Service figures count up once in view ---------- */

	document.querySelectorAll( '.cr-figure__value' ).forEach( function ( el ) {
		var text = el.textContent.trim();
		var m = text.match( /^(\D*)(\d+(?:\.\d+)?)(.*)$/ );
		if ( ! m ) {
			return;
		}
		var target = parseFloat( m[ 2 ] );
		var decimals = ( m[ 2 ].split( '.' )[ 1 ] || '' ).length;
		// Reserve the final width so counting never shifts the layout.
		el.style.minWidth = el.getBoundingClientRect().width + 'px';
		var counter = { v: 0 };
		var paint = function () {
			el.textContent = m[ 1 ] + counter.v.toFixed( decimals ) + m[ 3 ];
		};
		var r = el.getBoundingClientRect();
		if ( r.top < window.innerHeight && r.bottom > 0 ) {
			counter.v = target;
			paint();
			return;
		}
		paint();
		ST.create( {
			trigger: el,
			start: 'top 90%',
			once: true,
			onEnter: function () {
				gsap.to( counter, { v: target, duration: 1.6, ease: 'power2.out', onUpdate: paint } );
			}
		} );
	} );

	/* ---------- How a claim works: pinned scene with a drawing progress line ---------- */

	document.querySelectorAll( '.cr-claimflow' ).forEach( function ( scene ) {
		var track = scene.querySelector( '.cr-claimflow__steps' );
		if ( ! track ) {
			return;
		}
		var steps = scene.querySelectorAll( '.cr-cstep' );
		var line = document.createElement( 'div' );
		line.className = 'cr-claimflow__line';
		line.setAttribute( 'aria-hidden', 'true' );
		line.innerHTML = '<span></span>';
		track.insertBefore( line, track.firstChild );
		scene.classList.add( 'is-live' );

		var setProgress = function ( p ) {
			scene.style.setProperty( '--p', p.toFixed( 4 ) );
			steps.forEach( function ( s, i ) {
				var at = steps.length > 1 ? i / ( steps.length - 1 ) : 0;
				s.classList.toggle( 'is-active', p >= at * 0.94 - 0.001 );
			} );
		};
		setProgress( 0 );

		var mm = gsap.matchMedia();
		mm.add( '(min-width: 960px) and (min-height: 620px)', function () {
			ST.create( {
				trigger: scene,
				start: 'top top',
				end: '+=' + Math.round( window.innerHeight * 1.6 ),
				pin: true,
				scrub: 0.6,
				anticipatePin: 1,
				onUpdate: function ( self ) { setProgress( self.progress ); }
			} );
		} );
		mm.add( '(max-width: 959px), (max-height: 619px)', function () {
			ST.create( {
				trigger: track,
				start: 'top 70%',
				end: 'bottom 60%',
				scrub: 0.4,
				onUpdate: function ( self ) { setProgress( self.progress ); }
			} );
		} );
	} );

	/* ---------- Magnetic primary buttons ---------- */

	if ( finePointer ) {
		document.querySelectorAll( '.cr-hero .wp-block-button:not(.is-style-outline) .wp-block-button__link, .cr-cta .wp-block-button:not(.is-style-outline) .wp-block-button__link, .cr-header-cta .wp-block-button__link, .cr-aside .wp-block-button:not(.is-style-outline) .wp-block-button__link, .cr-form__submit, .cr-rc__next' ).forEach( function ( btn ) {
			var xTo = gsap.quickTo( btn, 'x', { duration: 0.5, ease: 'power3.out' } );
			var yTo = gsap.quickTo( btn, 'y', { duration: 0.5, ease: 'power3.out' } );
			btn.classList.add( 'is-magnetic' );
			btn.addEventListener( 'pointermove', function ( e ) {
				var r = btn.getBoundingClientRect();
				xTo( ( e.clientX - ( r.left + r.width / 2 ) ) * 0.3 );
				yTo( ( e.clientY - ( r.top + r.height / 2 ) ) * 0.4 );
			} );
			btn.addEventListener( 'pointerleave', function () {
				xTo( 0 );
				yTo( 0 );
			} );
		} );
	}

	// Fonts can change heading heights; recalculate trigger positions once loaded.
	if ( document.fonts && document.fonts.ready ) {
		document.fonts.ready.then( function () { ST.refresh(); } );
	}
	window.addEventListener( 'load', function () { ST.refresh(); } );
} )();
