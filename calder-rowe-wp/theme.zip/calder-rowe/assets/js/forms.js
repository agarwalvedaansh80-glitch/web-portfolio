/*
 * Calder & Rowe demo forms. Progressive enhancement only: the forms are plain
 * HTML and work without this file. In production, replace the HTML block with
 * a Contact Form 7 or WPForms block and remove this script.
 */
( function () {
	var forms = document.querySelectorAll( 'form[data-cr-form]' );
	Array.prototype.forEach.call( forms, function ( form ) {
		var status = form.querySelector( '.cr-form__status' );
		form.addEventListener( 'submit', function ( event ) {
			event.preventDefault();
			var invalid = form.querySelector( ':invalid' );
			if ( invalid ) {
				invalid.focus();
				if ( status ) {
					status.textContent = 'Please complete the highlighted field: ' + ( form.querySelector( 'label[for="' + invalid.id + '"]' ) || { textContent: 'required field' } ).textContent.trim() + '.';
				}
				form.classList.add( 'cr-form--checked' );
				return;
			}
			if ( status ) {
				status.textContent = 'Thanks. This is a demo form, so nothing was sent. On a live site this request goes to the broker team and the CRM.';
			}
			form.reset();
		} );
	} );
} )();
