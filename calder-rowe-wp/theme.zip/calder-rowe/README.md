# Calder & Rowe (block theme) 3.0

An editorial, kinetic WordPress block theme for a fictional independent business insurance broker in Leeds. Its identity is "calm in a storm": ink navy and paper, one safety-amber accent, Fraunces display type and a living topographic contour field.

## What is in the box

- `theme.json`: palette, three self-hosted font families (Fraunces, Albert Sans, IBM Plex Mono), fluid type and spacing scales, element and block styles.
- `templates/`: front page, page, **page-service** (one reusable template for every insurance line), page-wide, blog index, archive, search, single and 404.
- `parts/`: header, footer and the service call-back card.
- `patterns/`: every section of the site (hero, marquee, lines of cover, risk check, claims story, promise and targets, insights, CTA, sectors, process, FAQ, quote form, claims page, about page, service page body).
- Block styles registered in `functions.php`: Kinetic words (Heading), Ghost line and Arrow link (Button), Contour texture and Paper card (Group), Cover comparison (Table), Numbered isobar list (List), Scroll-lit quote (Pullquote), Ruled fold (Details).
- `assets/js/`: progressive enhancement only. `core.js` (smooth scroll, kinetic headings, compass cursor, magnetic buttons, field micro-interactions, marquee, line previews, comparison tables, scroll-lit quotes, count-ups, service parallax), `contours.js` (WebGL contour field), `risk-check.js` (five flickable cards and the barometer dial), `claims-story.js` (pinned storm-to-calm story).
- `assets/vendor/`: GSAP 3.13 + ScrollTrigger and Lenis 1.3.4, self-hosted. No third-party requests.

Scripts load only on pages that render the blocks that need them. Everything respects `prefers-reduced-motion`, and every page reads and works without JavaScript.

## Editing

All content is core blocks. The forms, the risk check and the call-back card are Custom HTML blocks so the demo needs no plugins; in production, swap them for your form plugin's block. Comparison tables are ordinary Table blocks with the "Cover comparison" style: type ✓ for included and — for not included.

## Demo content

The WordPress Playground blueprint (`wp-blueprint.json`) installs the theme and creates the pages, the four service pages (all using the Service page template), three guides and the navigation menu.

Calder & Rowe is a fictional brand. Phone numbers use Ofcom's drama ranges.
