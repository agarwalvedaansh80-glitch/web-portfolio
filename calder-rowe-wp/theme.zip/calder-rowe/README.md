# Calder & Rowe: block theme for a business insurance broker

A WordPress block theme (Full Site Editing) built as a portfolio sample.
Calder & Rowe is a **fictional** independent insurance and risk broker in Leeds.
It is not a real firm and does not sell insurance; the footer says so on every page.

## What it shows

- **Lead generation first:** hero with a three-field call-back form, "Get a quote" in the header,
  a full quote request form, renewal-review call to action, and a claims line on every page.
- **Interaction layer (v2):**
  - *Contour signature*: the hero and service title bands draw a live contour map on a 2D canvas
    (marching squares over a slowly drifting height field); the pointer adds a soft hill so nearby
    lines bend towards it. About 3 KB gzipped, runs at ~30 fps only while on screen and the tab is visible.
  - *Load sequence*: eyebrow, heading lines rising in one by one, lead and buttons, then the
    call-back card sliding in, as one GSAP timeline.
  - *Risk check* (`patterns/risk-check.php`): four questions (sector, staff, premises, vehicles)
    list the covers a business of that shape usually considers, flagging the ones UK law requires
    (employers' liability with staff, motor cover for vehicles). Keyboard-first, focus managed,
    results announced through an `aria-live` region, clearly labelled "a demo, not advice".
    Sector tiles link into it with the sector preselected.
  - *How a claim works* (`patterns/claim-flow.php`): report, assess, settle, review. On wide
    screens the section pins and a marigold line draws across the steps as you scroll; on phones
    the line draws down a vertical timeline.
  - Service targets that count up once in view, sector tiles that fill and reveal on hover or
    focus, service rows with a sliding underline and arrow nudge, magnetic primary buttons,
    Lenis smooth scrolling and a single reveal per section heading.
- **One reusable service template:** the *Service page* template (`templates/page-service.html`)
  plus the *Service page* pattern (`patterns/service-page.php`, offered when you create a new page).
  The three demo service pages are all built from that one structure.
- **Click-to-call and WhatsApp:** a sticky two-button bar on screens under 782px
  (`patterns/mobile-actions.php`); the header shows the phone number on desktop.
- **Sector tiles, service standards band, FAQ (core Details block), insights grid, claims timeline.**
- **Editable without code:** colours, fonts and sizes live in `theme.json`; header, footer and
  every section are template parts or patterns, so all of it can be changed in
  Appearance > Editor. The home page is the *Front Page* template in the Site Editor.

## Structure

| Path | Purpose |
| --- | --- |
| `theme.json` | Palette (8 colours), type scale, spacing scale, self-hosted fonts via `fontFace` |
| `templates/` | front-page, home (Insights), index, page, page-service, page-wide, single, archive, search, 404 |
| `parts/` | header, footer, service-aside |
| `patterns/` | hero, trust strip, services index, service standards, sectors, process, quote form, FAQ, news grid, CTA, mobile actions, page layouts |
| `assets/css/theme.css` | Focus styles, form styles, small layout details theme.json cannot express |
| `assets/js/forms.js` | 1 KB progressive enhancement for the demo forms (no jQuery) |
| `assets/js/contours.js` | Canvas contour signature (vanilla, no library) |
| `assets/js/risk-check.js` | Risk check widget (vanilla, binds when scrolled near) |
| `assets/js/motion.js` | Lenis, load sequence, heading reveals, pinned claim scene, counters, magnetic buttons |
| `assets/vendor/` | GSAP 3.13 + ScrollTrigger, Lenis 1.3.4 (licences in `assets/vendor/README.txt`) |

## Forms

The call-back and quote forms are static, semantic HTML in a Custom HTML block: real labels,
`autocomplete` hints, fieldsets for choices, a live status region and required-field handling.
In production, replace each HTML block with a **Contact Form 7** or **WPForms** block that uses the
same fields, and send submissions to **HubSpot** (WPForms HubSpot add-on, or the HubSpot plugin's
non-HubSpot-form capture for CF7). Then remove `assets/js/forms.js`.

## Performance and accessibility

- Two variable WOFF2 fonts (Besley, Instrument Sans, latin subset, about 66 KB together), self-hosted
  and preloaded, `font-display: swap`. No Google Fonts request.
- No jQuery. Every script is deferred and printed in the footer. `functions.php` watches the blocks
  as the template renders and enqueues the canvas, risk check and motion scripts only on pages that
  contain those sections (GSAP, ScrollTrigger and Lenis come to about 50 KB gzipped together).
  Emoji script removed.
- `prefers-reduced-motion`: no canvas (the static contour SVG stays), no smooth scrolling, no pin,
  counters and claim steps shown in their final state. Without JavaScript every section is
  readable and the risk check is a plain form that submits to the contact page.
- No layout shift: the canvas is absolutely positioned, counters reserve their final width, the
  risk check renders as a stepper from first paint (a one-line inline script sets `cr-js`).
- Images use WordPress core lazy loading (`loading="lazy"`, `decoding="async"`, responsive `srcset`),
  and core skips lazy loading for the first content image so it is not delayed.
- Skip link (added by core for block themes), visible focus rings sized for 3:1 contrast on light
  and dark sections, `prefers-reduced-motion` respected, colour pairs checked for WCAG AA.

## Fonts and licences

Besley and Instrument Sans are under the SIL Open Font License (files from the `@fontsource-variable`
npm packages; licences in `assets/fonts/`). Icons and contour artwork are original to this theme.
Theme code is GPL-2.0-or-later. Bundled libraries: GSAP (GreenSock standard no-charge licence)
and Lenis (MIT); see `assets/vendor/README.txt`.

## Demo content

Phone numbers use Ofcom's drama ranges (0113 496 0xxx and 07700 900xxx) and the email domain is
`.example`, so nothing reaches a real person. Every phone, WhatsApp and email link carries a visible
"Demo" tag (one CSS rule in `theme.css`). The service figures are targets of a fictional firm, not
results. There are no testimonials, ratings, client logos or awards.
