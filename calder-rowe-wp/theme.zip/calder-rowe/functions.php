<?php
/**
 * Calder & Rowe theme functions.
 *
 * Kept deliberately small: everything visual lives in theme.json, templates,
 * parts and patterns so it can be changed in the Site Editor.
 *
 * @package calder-rowe
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'CALDER_ROWE_VERSION', wp_get_theme( get_template() )->get( 'Version' ) );

/**
 * Theme supports and editor styles.
 */
function calder_rowe_setup() {
	add_theme_support( 'wp-block-styles' );
	add_theme_support( 'editor-styles' );
	add_editor_style( 'assets/css/theme.css' );
	// Pages get an excerpt field, shown as the intro under the page title.
	add_post_type_support( 'page', 'excerpt' );
}
add_action( 'after_setup_theme', 'calder_rowe_setup' );

/**
 * Which interactive features the current page actually renders.
 *
 * Block themes render the whole template before wp_head() runs, so by the time
 * wp_enqueue_scripts fires this filter has seen every block on the page. Scripts
 * are then enqueued only where a section that needs them is present.
 *
 * @param string|null $feature Feature key to flag, or null to read.
 * @return array<string,bool>
 */
function calder_rowe_features( $feature = null ) {
	static $features = array();
	if ( $feature ) {
		$features[ $feature ] = true;
	}
	return $features;
}

/**
 * Flag features by the class names editors see in the Site Editor.
 *
 * @param string $html  Rendered block.
 * @param array  $block Parsed block.
 * @return string
 */
function calder_rowe_detect_features( $html, $block ) {
	$class = isset( $block['attrs']['className'] ) ? $block['attrs']['className'] : '';
	if ( '' === $class ) {
		return $html;
	}
	$map = array(
		'cr-contours'  => 'contours',
		'cr-hero'      => 'motion',
		'cr-claimflow' => 'motion',
		'cr-stats'     => 'motion',
		'cr-titleband--service' => 'motion',
		'cr-riskcheck' => 'riskcheck',
	);
	foreach ( $map as $needle => $feature ) {
		if ( preg_match( '/(^|\s)' . preg_quote( $needle, '/' ) . '(\s|$|--)/', $class ) ) {
			calder_rowe_features( $feature );
		}
	}
	if ( preg_match( '/(^|\s)cr-hero(\s|$)/', $class ) ) {
		calder_rowe_features( 'intro' );
	}
	return $html;
}
add_filter( 'render_block', 'calder_rowe_detect_features', 10, 2 );

/**
 * Front-end styles and scripts. Every script is deferred and printed in the
 * footer; no jQuery. Heavier libraries load only on pages that use them.
 */
function calder_rowe_assets() {
	$deferred = array(
		'in_footer' => true,
		'strategy'  => 'defer',
	);
	$uri      = static function ( $path ) {
		return get_theme_file_uri( $path );
	};
	$features = calder_rowe_features();

	wp_enqueue_style( 'calder-rowe', $uri( 'assets/css/theme.css' ), array(), CALDER_ROWE_VERSION );
	wp_enqueue_script( 'calder-rowe-forms', $uri( 'assets/js/forms.js' ), array(), CALDER_ROWE_VERSION, $deferred );

	// Animated contour signature (vanilla canvas, about 3 KB, no library).
	if ( ! empty( $features['contours'] ) ) {
		wp_enqueue_script( 'calder-rowe-contours', $uri( 'assets/js/contours.js' ), array(), CALDER_ROWE_VERSION, $deferred );
	}

	// Risk check widget (vanilla, initialises when scrolled near).
	if ( ! empty( $features['riskcheck'] ) ) {
		wp_enqueue_script( 'calder-rowe-riskcheck', $uri( 'assets/js/risk-check.js' ), array(), CALDER_ROWE_VERSION, $deferred );
	}

	// Motion layer: GSAP + ScrollTrigger + Lenis, only where a section uses them.
	if ( ! empty( $features['motion'] ) ) {
		wp_register_script( 'gsap', $uri( 'assets/vendor/gsap.min.js' ), array(), '3.13.0', $deferred );
		wp_register_script( 'gsap-scrolltrigger', $uri( 'assets/vendor/ScrollTrigger.min.js' ), array( 'gsap' ), '3.13.0', $deferred );
		wp_register_script( 'lenis', $uri( 'assets/vendor/lenis.min.js' ), array(), '1.3.4', $deferred );
		wp_enqueue_script( 'calder-rowe-motion', $uri( 'assets/js/motion.js' ), array( 'gsap', 'gsap-scrolltrigger', 'lenis' ), CALDER_ROWE_VERSION, $deferred );
	}
}
add_action( 'wp_enqueue_scripts', 'calder_rowe_assets' );

/**
 * Mark the document as scripted (so enhanced widgets render in their final
 * shape on first paint, without layout shift) and, on pages with the hero,
 * hide the hero copy for the first paint only when the visitor accepts
 * motion, so the load sequence can play without a flash. A timer reveals
 * everything if the motion script never arrives.
 */
function calder_rowe_intro_flag() {
	$features = calder_rowe_features();
	$script   = "document.documentElement.classList.add('cr-js');";
	if ( ! empty( $features['intro'] ) && ! empty( $features['motion'] ) ) {
		$script .= "(function(d){if(!window.matchMedia||matchMedia('(prefers-reduced-motion: reduce)').matches)return;" .
			"d.classList.add('cr-intro');setTimeout(function(){d.classList.remove('cr-intro')},3000)})(document.documentElement);";
	}
	wp_print_inline_script_tag( $script );
}
add_action( 'wp_head', 'calder_rowe_intro_flag', 2 );

/**
 * Preload the two upright font files used above the fold.
 */
function calder_rowe_preload_fonts() {
	foreach ( array( 'besley-latin-wght-normal', 'instrument-sans-latin-wght-normal' ) as $file ) {
		printf(
			'<link rel="preload" href="%s" as="font" type="font/woff2" crossorigin>' . "\n",
			esc_url( get_theme_file_uri( 'assets/fonts/' . $file . '.woff2' ) )
		);
	}
}
add_action( 'wp_head', 'calder_rowe_preload_fonts', 1 );

/**
 * Pattern categories.
 */
function calder_rowe_pattern_categories() {
	register_block_pattern_category( 'calder-rowe', array( 'label' => __( 'Calder & Rowe sections', 'calder-rowe' ) ) );
	register_block_pattern_category( 'calder-rowe-pages', array( 'label' => __( 'Calder & Rowe pages', 'calder-rowe' ) ) );
	register_block_pattern_category( 'services', array( 'label' => __( 'Services', 'calder-rowe' ) ) );
}
add_action( 'init', 'calder_rowe_pattern_categories' );

/**
 * Trim front-end weight: no emoji detection script or styles.
 */
remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
remove_action( 'wp_print_styles', 'print_emoji_styles' );
