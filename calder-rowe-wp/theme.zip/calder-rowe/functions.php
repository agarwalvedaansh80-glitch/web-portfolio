<?php
/**
 * Calder & Rowe theme functions.
 *
 * Everything visual lives in theme.json, templates, parts, patterns and block
 * styles, so it can be changed in the Site Editor. This file only registers
 * block styles and enqueues the progressive-enhancement scripts that bring
 * core blocks to life. Every page still renders and works without JavaScript.
 *
 * @package calder-rowe
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'CALDER_ROWE_VERSION', wp_get_theme( get_template() )->get( 'Version' ) );

/**
 * Theme supports and editor styles.
 */
function calder_rowe_setup() {
	add_theme_support( 'wp-block-styles' );
	add_theme_support( 'editor-styles' );
	add_editor_style( 'assets/css/theme.css' );
	add_post_type_support( 'page', 'excerpt' );
}
add_action( 'after_setup_theme', 'calder_rowe_setup' );

/**
 * Block styles. Each one is plain CSS in theme.css; some are also picked up by
 * the front-end scripts and enhanced (kinetic words, animated tables, and so on).
 */
function calder_rowe_block_styles() {
	$styles = array(
		'core/heading'   => array( 'kinetic' => __( 'Kinetic words', 'calder-rowe' ) ),
		'core/button'    => array(
			'ghost' => __( 'Ghost line', 'calder-rowe' ),
			'arrow' => __( 'Arrow link', 'calder-rowe' ),
		),
		'core/group'     => array(
			'contour' => __( 'Contour texture', 'calder-rowe' ),
			'card'    => __( 'Paper card', 'calder-rowe' ),
		),
		'core/table'     => array( 'compare' => __( 'Cover comparison (animated)', 'calder-rowe' ) ),
		'core/list'      => array( 'isobar' => __( 'Numbered isobar list', 'calder-rowe' ) ),
		'core/pullquote' => array( 'scrub' => __( 'Scroll-lit quote', 'calder-rowe' ) ),
		'core/details'   => array( 'fold' => __( 'Ruled fold', 'calder-rowe' ) ),
	);
	foreach ( $styles as $block => $variants ) {
		foreach ( $variants as $name => $label ) {
			register_block_style( $block, array( 'name' => $name, 'label' => $label ) );
		}
	}
}
add_action( 'init', 'calder_rowe_block_styles' );

/**
 * Which interactive features the current page renders.
 *
 * Block themes render the whole template before wp_head() runs, so by the time
 * wp_enqueue_scripts fires this has seen every block on the page.
 *
 * @param string|null $feature Feature key to flag, or null to read.
 * @return array<string,bool>
 */
function calder_rowe_features( $feature = null ) {
	static $features = array();
	if ( $feature ) {
		$features[ $feature ] = true;
	}
	return $features;
}

/**
 * Flag features by the class names editors see in the Site Editor.
 *
 * @param string $html  Rendered block.
 * @param array  $block Parsed block.
 * @return string
 */
function calder_rowe_detect_features( $html, $block ) {
	$class = isset( $block['attrs']['className'] ) ? $block['attrs']['className'] : '';
	if ( '' === $class ) {
		return $html;
	}
	$map = array(
		'cr-hero'         => array( 'contours', 'intro' ),
		'cr-livefield'    => array( 'contours' ),
		'cr-svc-hero'     => array( 'contours' ),
		'cr-riskcheck'    => array( 'riskcheck' ),
		'cr-claims-story' => array( 'storm' ),
	);
	foreach ( $map as $needle => $flags ) {
		if ( preg_match( '/(^|\s)' . preg_quote( $needle, '/' ) . '(\s|$)/', $class ) ) {
			foreach ( $flags as $flag ) {
				calder_rowe_features( $flag );
			}
		}
	}
	return $html;
}
add_filter( 'render_block', 'calder_rowe_detect_features', 10, 2 );

/**
 * Front-end styles and scripts. All scripts are deferred, in the footer, and
 * self-hosted. No jQuery, no third-party hosts.
 */
function calder_rowe_assets() {
	$deferred = array(
		'in_footer' => true,
		'strategy'  => 'defer',
	);
	$uri      = static function ( $path ) {
		return get_theme_file_uri( $path );
	};
	$features = calder_rowe_features();

	wp_enqueue_style( 'calder-rowe', $uri( 'assets/css/theme.css' ), array(), CALDER_ROWE_VERSION );

	// Motion stack used on every page: GSAP + ScrollTrigger + Lenis.
	wp_register_script( 'gsap', $uri( 'assets/vendor/gsap.min.js' ), array(), '3.13.0', $deferred );
	wp_register_script( 'gsap-scrolltrigger', $uri( 'assets/vendor/ScrollTrigger.min.js' ), array( 'gsap' ), '3.13.0', $deferred );
	wp_register_script( 'lenis', $uri( 'assets/vendor/lenis.min.js' ), array(), '1.3.4', $deferred );
	wp_enqueue_script( 'calder-rowe-core', $uri( 'assets/js/core.js' ), array( 'gsap', 'gsap-scrolltrigger', 'lenis' ), CALDER_ROWE_VERSION, $deferred );

	if ( ! empty( $features['contours'] ) ) {
		wp_enqueue_script( 'calder-rowe-contours', $uri( 'assets/js/contours.js' ), array( 'calder-rowe-core' ), CALDER_ROWE_VERSION, $deferred );
	}
	if ( ! empty( $features['riskcheck'] ) ) {
		wp_enqueue_script( 'calder-rowe-riskcheck', $uri( 'assets/js/risk-check.js' ), array( 'calder-rowe-core' ), CALDER_ROWE_VERSION, $deferred );
	}
	if ( ! empty( $features['storm'] ) ) {
		wp_enqueue_script( 'calder-rowe-storm', $uri( 'assets/js/claims-story.js' ), array( 'calder-rowe-core' ), CALDER_ROWE_VERSION, $deferred );
	}
}
add_action( 'wp_enqueue_scripts', 'calder_rowe_assets' );

/**
 * Early inline flags: `cr-js` so enhanced widgets paint in their final shape,
 * `cr-capture` for frame-stepped recordings (?capture=1), and `cr-intro` to hold
 * the hero copy for its load sequence when the visitor accepts motion. A timer
 * releases the hero if the motion script never arrives.
 */
function calder_rowe_head_flags() {
	$features = calder_rowe_features();
	$script   = "(function(d){d.classList.add('cr-js');if(/[?&]capture=1/.test(location.search))d.classList.add('cr-capture');";
	if ( ! empty( $features['intro'] ) ) {
		$script .= "if(window.matchMedia&&!matchMedia('(prefers-reduced-motion: reduce)').matches){d.classList.add('cr-intro');setTimeout(function(){d.classList.remove('cr-intro')},4000)}";
	}
	$script .= '})(document.documentElement);';
	wp_print_inline_script_tag( $script );
}
add_action( 'wp_head', 'calder_rowe_head_flags', 2 );

/**
 * Preload the display and body fonts used above the fold.
 */
function calder_rowe_preload_fonts() {
	foreach ( array( 'fraunces-full-normal', 'albert-sans-normal' ) as $file ) {
		printf(
			'<link rel="preload" href="%s" as="font" type="font/woff2" crossorigin>' . "\n",
			esc_url( get_theme_file_uri( 'assets/fonts/' . $file . '.woff2' ) )
		);
	}
}
add_action( 'wp_head', 'calder_rowe_preload_fonts', 1 );

/**
 * A compass favicon, unless the site owner has set a Site Icon.
 */
function calder_rowe_favicon() {
	if ( ! has_site_icon() ) {
		printf( '<link rel="icon" href="%s" type="image/svg+xml">' . "\n", esc_url( get_theme_file_uri( 'assets/images/favicon.svg' ) ) );
	}
}
add_action( 'wp_head', 'calder_rowe_favicon', 3 );

/**
 * Pattern categories.
 */
function calder_rowe_pattern_categories() {
	register_block_pattern_category( 'calder-rowe', array( 'label' => __( 'Calder & Rowe sections', 'calder-rowe' ) ) );
	register_block_pattern_category( 'calder-rowe-pages', array( 'label' => __( 'Calder & Rowe pages', 'calder-rowe' ) ) );
	register_block_pattern_category( 'services', array( 'label' => __( 'Services', 'calder-rowe' ) ) );
}
add_action( 'init', 'calder_rowe_pattern_categories' );

/**
 * Trim front-end weight: no emoji detection script or styles.
 */
remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
remove_action( 'wp_print_styles', 'print_emoji_styles' );
